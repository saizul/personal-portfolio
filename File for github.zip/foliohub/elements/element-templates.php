<?php
use Elementor\Embed;
if (!function_exists('foliohub_get_post_grid')) {
    function foliohub_get_post_grid($posts = [], $settings = [])
    {
        if (empty($posts) || !is_array($posts) || empty($settings) || !is_array($settings)) {
            return false;
        }
        switch ($settings['layout']) {
            case 'post-1':
                foliohub_get_post_grid_layout1($posts, $settings);
                break;

            case 'portfolio-1':
                foliohub_get_portfolio_grid_layout1($posts, $settings);
                break;

            case 'portfolio-2':
                foliohub_get_portfolio_grid_layout2($posts, $settings);
                break;

            case 'portfolio-3':
                foliohub_get_portfolio_grid_layout3($posts, $settings);
                break;

            case 'portfolio-4':
                foliohub_get_portfolio_grid_layout4($posts, $settings);
                break;

            case 'portfolio-5':
                foliohub_get_portfolio_grid_layout5($posts, $settings);
                break;

            case 'portfolio-6':
                foliohub_get_portfolio_grid_layout6($posts, $settings);
                break;

            case 'portfolio-7':
                foliohub_get_portfolio_grid_layout7($posts, $settings);
                break;

            case 'portfolio-8':
                foliohub_get_portfolio_grid_layout8($posts, $settings);
                break;

            case 'service-1':
                foliohub_get_service_grid_layout1($posts, $settings);
                break;

            case 'industries-1':
                foliohub_get_industries_grid_layout1($posts, $settings);
                break;

            default:
                return false;
                break;
        }
    }
}
function foliohub_get_post_list($posts = [], $settings = [])
{
    if (empty($posts) || !is_array($posts) || empty($settings) || !is_array($settings)) {
        return;
    }
    extract($settings);

    switch ($settings['layout']) {
        case 'service-list-1':
            foliohub_get_service_list_layout1($posts, $settings);
            break;

        case 'service-list-2':
            foliohub_get_service_list_layout2($posts, $settings);
            break;

        case 'service-list-3':
            foliohub_get_service_list_layout3($posts, $settings);
            break;

        case 'service-list-4':
            foliohub_get_service_list_layout4($posts, $settings);
            break;

        case 'portfolio-list-1':
            foliohub_get_portfolio_list_layout1($posts, $settings);
            break;

        default:
            return false;
            break;
    }
}
// Start Post Grid
//--------------------------------------------------
function foliohub_get_post_grid_layout1($posts = [], $settings = [])
{
    extract($settings);

    $image_size = !empty($img_size) ? $img_size : '1048x676';

    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $item_class = "pxl-grid-item col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col_xs}";
            if (isset($grid_masonry) && !empty($grid_masonry[$key]) && (count($grid_masonry) > 1)) {
                if ($grid_masonry[$key]['col_xl_m'] == 'col-66') {
                    $col_xl_m = '66-pxl';
                } else {
                    $col_xl_m = 12 / $grid_masonry[$key]['col_xl_m'];
                }
                if ($grid_masonry[$key]['col_lg_m'] == 'col-66') {
                    $col_lg_m = '66-pxl';
                } else {
                    $col_lg_m = 12 / $grid_masonry[$key]['col_lg_m'];
                }
                $col_md_m = 12 / $grid_masonry[$key]['col_md_m'];
                $col_sm_m = 12 / $grid_masonry[$key]['col_sm_m'];
                $col_xs_m = 12 / $grid_masonry[$key]['col_xs_m'];
                $item_class = "pxl-grid-item col-xl-{$col_xl_m} col-lg-{$col_lg_m} col-md-{$col_md_m} col-sm-{$col_sm_m} col-{$col_xs_m}";

                $img_size_m = $grid_masonry[$key]['img_size_m'];
                if (!empty($img_size_m)) {
                    $images_size = $img_size_m;
                }
            } elseif (!empty($img_size)) {
                $images_size = $img_size;
            }
            $author_id = $post->post_author;
            $author = get_user_by('id', $author_id);
            if (!empty($tax))
                $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
            else
                $filter_class = ''; ?>
            <div class="<?php echo esc_attr($item_class . ' ' . $filter_class); ?>">
                <div class="pxl-post--inner <?php echo esc_attr($pxl_animate); ?> wow" data-wow-duration="1.2s">
                    <?php if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)):
                        $img_id = get_post_thumbnail_id($post->ID);
                        $img = pxl_get_image_by_size(array(
                            'attach_id' => $img_id,
                            'thumb_size' => $image_size,
                        ));
                        $thumbnail = $img['thumbnail'];
                        ?>
                        <div class="pxl-post--featured hover-imge-effect2">
                            <a href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                <?php echo wp_kses_post($thumbnail); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                    <div class="pxl-post--container">
                        <div class="pxl-post--meta pxl-flex-middle">
                            <?php if ($show_category == 'true'): ?>
                                <div class="pxl-post--category d-flex">
                                    <?php the_terms($post->ID, 'category', '', ''); ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($show_date == 'true'): ?>
                                <span class="post-date">
                                    <?php echo get_the_date('M d, Y', $post->ID) ?>
                                </span>
                            <?php endif; ?>
                        </div>
                        <h5 class="pxl-post--title ">
                            <a href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                <?php echo pxl_print_html(get_the_title($post->ID)); ?>
                            </a>
                        </h5>
                    </div>
                    <?php if ($show_button == 'true'): ?>
                        <div class="pxl-post--button">
                            <a class="btn--readmore" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                <span><?php if (!empty($button_text)) {
                                    echo pxl_print_html($button_text);
                                } else {
                                    echo esc_html__('Read More', 'foliohub');
                                } ?></span>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php
        endforeach;
    endif;
}

// End Post Grid
//--------------------------------------------------

// Start industries Grid
//--------------------------------------------------
function foliohub_get_industries_grid_layout1($posts = [], $settings = [])
{
    extract($settings);

    $images_size = !empty($img_size) ? $img_size : 'full';

    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $item_class = "pxl-grid-item col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col_xs}";
            if (isset($grid_masonry) && !empty($grid_masonry[$key]) && (count($grid_masonry) > 1)) {
                if ($grid_masonry[$key]['col_xl_m'] == 'col-66') {
                    $col_xl_m = '66-pxl';
                } else {
                    $col_xl_m = 12 / $grid_masonry[$key]['col_xl_m'];
                }
                if ($grid_masonry[$key]['col_lg_m'] == 'col-66') {
                    $col_lg_m = '66-pxl';
                } else {
                    $col_lg_m = 12 / $grid_masonry[$key]['col_lg_m'];
                }
                $col_md_m = 12 / $grid_masonry[$key]['col_md_m'];
                $col_sm_m = 12 / $grid_masonry[$key]['col_sm_m'];
                $col_xs_m = 12 / $grid_masonry[$key]['col_xs_m'];
                $item_class = "pxl-grid-item col-xl-{$col_xl_m} col-lg-{$col_lg_m} col-md-{$col_md_m} col-sm-{$col_sm_m} col-{$col_xs_m}";

                $img_size_m = $grid_masonry[$key]['img_size_m'];
                if (!empty($img_size_m)) {
                    $images_size = $img_size_m;
                }
            } elseif (!empty($img_size)) {
                $images_size = $img_size;
            }
            $author_id = $post->post_author;
            $author = get_user_by('id', $author_id);
            $industries_icon_type = get_post_meta($post->ID, 'industries_icon_type', true);
            $industries_icon_font = get_post_meta($post->ID, 'industries_icon_font', true);
            $industries_icon_img = get_post_meta($post->ID, 'industries_icon_img', true);
            if (!empty($tax))
                $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
            else
                $filter_class = ''; ?>
            <div class="<?php echo esc_attr($item_class . ' ' . $filter_class); ?>">
                <div class="pxl-post--inner <?php echo esc_attr($pxl_animate); ?>" data-wow-duration="1.2s">
                    <?php if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)):
                        $img_id = get_post_thumbnail_id($post->ID);
                        $img = pxl_get_image_by_size(array(
                            'attach_id' => $img_id,
                            'thumb_size' => $images_size
                        ));
                        $thumbnail = $img['thumbnail'];
                        $thumbnail_url = $img['url'];
                        ?>
                    <?php endif; ?>
                    <div class="pxl-post-content-hide">
                        <?php if ($industries_icon_type == 'icon' && !empty($industries_icon_font)): ?>
                            <div class="pxl-post-icon-wrap">
                                <div class="pxl-post--icon">
                                    <i class="<?php echo esc_attr($industries_icon_font); ?>"></i>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if ($industries_icon_type == 'image' && !empty($industries_icon_img)):
                            $icon_img = pxl_get_image_by_size(array(
                                'attach_id' => $industries_icon_img['id'],
                                'thumb_size' => 'full',
                            ));
                            $icon_thumbnail = $icon_img['thumbnail'];
                            ?>
                            <div class="pxl-post-icon-wrap">
                                <div class="pxl-post--icon">
                                    <?php echo wp_kses_post($icon_thumbnail); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        <h4 class="pxl-post--title title-hover-line"><a
                                href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?></a>
                        </h4>
                        <?php if ($show_excerpt == 'true'): ?>
                            <div class="pxl-post--content">
                                <p>
                                    <?php echo wp_trim_words($post->post_excerpt, $num_words, null); ?>
                                </p>
                            </div>
                        <?php endif; ?>
                        <?php if ($show_button == 'true'): ?>
                            <div class="pxl-post--button">
                                <a class="btn--readmore" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                    <span class="btn--text">
                                        <?php if (!empty($button_text)) {
                                            echo esc_attr($button_text);
                                        } else {
                                            echo esc_html__('Learn More', 'foliohub');
                                        } ?>
                                    </span>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="6" viewBox="0 0 20 6" fill="none">
                                        <path
                                            d="M17.7721 5.477L19.8245 3.42458C19.9369 3.31189 20 3.15921 20 3.00003C20 2.84085 19.9369 2.68817 19.8245 2.57548L17.7721 0.523097C17.68 0.433323 17.5562 0.383455 17.4275 0.384288C17.2989 0.385121 17.1757 0.436588 17.0848 0.527548C16.9938 0.618508 16.9423 0.741639 16.9414 0.870284C16.9406 0.998928 16.9904 1.12273 17.0802 1.21489L18.376 2.51071H0.489219C0.35947 2.51071 0.235035 2.56226 0.143289 2.654C0.0515425 2.74575 0 2.87018 0 2.99993C0 3.12968 0.0515425 3.25412 0.143289 3.34586C0.235035 3.43761 0.35947 3.48915 0.489219 3.48915H18.3759L17.0802 4.78521C16.9896 4.8772 16.939 5.00126 16.9395 5.13037C16.94 5.25948 16.9915 5.38315 17.0828 5.47445C17.1741 5.56574 17.2978 5.61725 17.4269 5.61775C17.556 5.61825 17.6801 5.5677 17.7721 5.47712V5.477Z"
                                            fill="white" />
                                    </svg>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div style="background-image: url(<?php echo esc_attr($thumbnail_url); ?>);" class="pxl-item--overlay bg-image">
                        <?php if ($industries_icon_type == 'icon' && !empty($industries_icon_font)): ?>
                            <div class="pxl-post--icon">
                                <i class="<?php echo esc_attr($industries_icon_font); ?>"></i>
                            </div>
                        <?php endif; ?>
                        <?php if ($industries_icon_type == 'image' && !empty($industries_icon_img)):
                            $icon_img = pxl_get_image_by_size(array(
                                'attach_id' => $industries_icon_img['id'],
                                'thumb_size' => 'full',
                            ));
                            $icon_thumbnail = $icon_img['thumbnail'];
                            ?>
                            <div class="pxl-post--icon">
                                <?php echo wp_kses_post($icon_thumbnail); ?>
                            </div>
                        <?php endif; ?>
                        <h4 class="pxl-post--title title-hover-line"><a
                                href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?></a>
                        </h4>
                        <?php if ($show_excerpt == 'true'): ?>
                            <div class="pxl-post--content">
                                <?php echo wp_trim_words($post->post_excerpt, $num_words, null); ?>
                            </div>
                        <?php endif; ?>
                        <?php if ($show_button == 'true'): ?>
                            <div class="pxl-post--button">
                                <a class="btn--readmore" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                    <span class="btn--text">
                                        <?php if (!empty($button_text)) {
                                            echo esc_attr($button_text);
                                        } else {
                                            echo esc_html__('Learn More', 'foliohub');
                                        } ?>
                                    </span>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="6" viewBox="0 0 20 6" fill="none">
                                        <path
                                            d="M17.7721 5.477L19.8245 3.42458C19.9369 3.31189 20 3.15921 20 3.00003C20 2.84085 19.9369 2.68817 19.8245 2.57548L17.7721 0.523097C17.68 0.433323 17.5562 0.383455 17.4275 0.384288C17.2989 0.385121 17.1757 0.436588 17.0848 0.527548C16.9938 0.618508 16.9423 0.741639 16.9414 0.870284C16.9406 0.998928 16.9904 1.12273 17.0802 1.21489L18.376 2.51071H0.489219C0.35947 2.51071 0.235035 2.56226 0.143289 2.654C0.0515425 2.74575 0 2.87018 0 2.99993C0 3.12968 0.0515425 3.25412 0.143289 3.34586C0.235035 3.43761 0.35947 3.48915 0.489219 3.48915H18.3759L17.0802 4.78521C16.9896 4.8772 16.939 5.00126 16.9395 5.13037C16.94 5.25948 16.9915 5.38315 17.0828 5.47445C17.1741 5.56574 17.2978 5.61725 17.4269 5.61775C17.556 5.61825 17.6801 5.5677 17.7721 5.47712V5.477Z"
                                            fill="white" />
                                    </svg>
                                </a>
                            </div>
                        <?php endif; ?>
                        <a class="pxl-item--link" href="<?php echo esc_url(get_permalink($post->ID)); ?>"></a>
                    </div>
                </div>
            </div>
            <?php
        endforeach;
    endif;
}

// End industries Grid
//--------------------------------------------------

// Start Portfolio Grid
//--------------------------------------------------

function foliohub_get_portfolio_grid_layout1($posts = [], $settings = [])
{
    extract($settings);

    $images_size = !empty($img_size) ? $img_size : '1300x900';

    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $item_class = "pxl-grid-item col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col_xs}";
            if (isset($grid_masonry) && !empty($grid_masonry[$key]) && (count($grid_masonry) > 1)) {
                if ($grid_masonry[$key]['col_xl_m'] == 'col-66') {
                    $col_xl_m = '66-pxl';
                } else {
                    $col_xl_m = 12 / $grid_masonry[$key]['col_xl_m'];
                }
                if ($grid_masonry[$key]['col_lg_m'] == 'col-66') {
                    $col_lg_m = '66-pxl';
                } else {
                    $col_lg_m = 12 / $grid_masonry[$key]['col_lg_m'];
                }
                $col_md_m = 12 / $grid_masonry[$key]['col_md_m'];
                $col_sm_m = 12 / $grid_masonry[$key]['col_sm_m'];
                $col_xs_m = 12 / $grid_masonry[$key]['col_xs_m'];
                $item_class = "pxl-grid-item col-xl-{$col_xl_m} col-lg-{$col_lg_m} col-md-{$col_md_m} col-sm-{$col_sm_m} col-{$col_xs_m}";

                $img_size_m = $grid_masonry[$key]['img_size_m'];
                if (!empty($img_size_m)) {
                    $images_size = $img_size_m;
                }
            } elseif (!empty($img_size)) {
                $images_size = $img_size;
            }

            if (!empty($tax))
                $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
            else
                $filter_class = '';

            $img_id = get_post_thumbnail_id($post->ID);
            if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)):
                if ($img_id) {
                    $img = pxl_get_image_by_size(array(
                        'attach_id' => $img_id,
                        'thumb_size' => $images_size,
                        'class' => 'no-lazyload',
                    ));
                    $thumbnail = $img['thumbnail'];
                } else {
                    $thumbnail = get_the_post_thumbnail($post->ID, $images_size);
                }
                $tag_project = get_post_meta($post->ID, 'tag_project', true);
                $project_icon_type = get_post_meta($post->ID, 'project_icon_type', true);
                $project_icon_font = get_post_meta($post->ID, 'project_icon_font', true);
                $project_icon_img = get_post_meta($post->ID, 'project_icon_img', true);
                ?>
                <div class="<?php echo esc_attr($item_class . ' ' . $filter_class); ?>">
                    <div class="pxl-post--inner <?php echo esc_attr($pxl_animate); ?>" data-wow-duration="1.2s">
                        <div class="pxl-post--featured ">
                            <?php if ($project_icon_type == 'icon' && !empty($project_icon_font)): ?>
                                <div class="pxl-post--icon">
                                    <i class="<?php echo esc_attr($project_icon_font); ?>"></i>
                                </div>
                            <?php endif; ?>
                            <?php if ($project_icon_type == 'image' && !empty($project_icon_img)):
                                $icon_img = pxl_get_image_by_size(array(
                                    'attach_id' => $project_icon_img['id'],
                                    'thumb_size' => 'full',
                                ));
                                $icon_thumbnail = $icon_img['thumbnail'];
                                ?>
                                <div class="pxl-post--icon">
                                    <?php echo wp_kses_post($icon_thumbnail); ?>
                                </div>
                            <?php endif; ?>
                            <a href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                <?php echo wp_kses_post($thumbnail); ?>
                            </a>
                        </div>
                        <div class="pxl-post--holder">
                            <h4 class="pxl-post--title">
                                <a
                                    href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?></a>
                            </h4>
                            <?php if ($show_excerpt == 'true'): ?>
                                <div class="pxl-post--content">
                                    <?php if ($show_excerpt == 'true'): ?>
                                        <?php
                                        echo wp_trim_words($post->post_excerpt, $num_words, null);
                                        ?>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            <div class="pxl-post--tag">
                                <?php
                                if (is_array($tag_project)) {
                                    echo '<div class="tag-list">';
                                    foreach ($tag_project as $tag) {
                                        echo '<span>' . esc_html($tag) . '</span>';
                                    }
                                    echo '</div>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach;
    endif;
}
function foliohub_get_portfolio_grid_layout2($posts = [], $settings = [])
{
    extract($settings);

    $images_size = !empty($img_size) ? $img_size : '1220x1000';

    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $item_class = "pxl-grid-item col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col_xs}";
            if (isset($grid_masonry) && !empty($grid_masonry[$key]) && (count($grid_masonry) > 1)) {
                if ($grid_masonry[$key]['col_xl_m'] == 'col-66') {
                    $col_xl_m = '66-pxl';
                } else {
                    $col_xl_m = 12 / $grid_masonry[$key]['col_xl_m'];
                }
                if ($grid_masonry[$key]['col_lg_m'] == 'col-66') {
                    $col_lg_m = '66-pxl';
                } else {
                    $col_lg_m = 12 / $grid_masonry[$key]['col_lg_m'];
                }
                $col_md_m = 12 / $grid_masonry[$key]['col_md_m'];
                $col_sm_m = 12 / $grid_masonry[$key]['col_sm_m'];
                $col_xs_m = 12 / $grid_masonry[$key]['col_xs_m'];
                $item_class = "pxl-grid-item col-xl-{$col_xl_m} col-lg-{$col_lg_m} col-md-{$col_md_m} col-sm-{$col_sm_m} col-{$col_xs_m}";

                $img_size_m = $grid_masonry[$key]['img_size_m'];
                if (!empty($img_size_m)) {
                    $images_size = $img_size_m;
                }
            } elseif (!empty($img_size)) {
                $images_size = $img_size;
            }

            if (!empty($tax))
                $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
            else
                $filter_class = '';

            $img_id = get_post_thumbnail_id($post->ID);
            if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)):
                if ($img_id) {
                    $img = pxl_get_image_by_size(array(
                        'attach_id' => $img_id,
                        'thumb_size' => $images_size,
                        'class' => 'no-lazyload',
                    ));
                    $thumbnail = $img['thumbnail'];
                } else {
                    $thumbnail = get_the_post_thumbnail($post->ID, $images_size);
                }
                $project_icon_type = get_post_meta($post->ID, 'project_icon_type', true);
                $project_icon_font = get_post_meta($post->ID, 'project_icon_font', true);
                $project_icon_img = get_post_meta($post->ID, 'project_icon_img', true);
                ?>
                <div class="<?php echo esc_attr($item_class . ' ' . $filter_class); ?>">
                    <div class="pxl-post--inner <?php echo esc_attr($pxl_animate); ?>" data-wow-duration="1.2s">
                        <div class="pxl-post--holder">
                            <h5 class="pxl-post--title title-hover-line">
                                <a class=""
                                    href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?>
                                </a>
                            </h5>
                            <?php if ($show_excerpt == 'true'): ?>
                                <div class="pxl-post--content">
                                    <?php if ($show_excerpt == 'true'): ?>
                                        <?php
                                        echo wp_trim_words($post->post_excerpt, $num_words, null);
                                        ?>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($show_category == 'true'): ?>
                                <div class="pxl-post--category d-flex">
                                    <?php the_terms($post->ID, 'portfolio-category', '', ''); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="pxl-post--featured">
                            <?php if ($project_icon_type == 'icon' && !empty($project_icon_font)): ?>
                                <div class="pxl-post--icon">
                                    <i class="<?php echo esc_attr($project_icon_font); ?>"></i>
                                </div>
                            <?php endif; ?>
                            <?php if ($project_icon_type == 'image' && !empty($project_icon_img)):
                                $icon_img = pxl_get_image_by_size(array(
                                    'attach_id' => $project_icon_img['id'],
                                    'thumb_size' => 'full',
                                ));
                                $icon_thumbnail = $icon_img['thumbnail'];
                                ?>
                                <div class="pxl-post--icon">
                                    <?php echo wp_kses_post($icon_thumbnail); ?>
                                </div>
                            <?php endif; ?>
                            <a class="hover-imge-effect2" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                <?php echo wp_kses_post($thumbnail); ?>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach;
    endif;
}
function foliohub_get_portfolio_grid_layout3($posts = [], $settings = [])
{
    extract($settings);

    $images_size = !empty($img_size) ? $img_size : '1260x650';

    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $item_class = "pxl-grid-item col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col_xs}";
            if (isset($grid_masonry) && !empty($grid_masonry[$key]) && (count($grid_masonry) > 1)) {
                if ($grid_masonry[$key]['col_xl_m'] == 'col-66') {
                    $col_xl_m = '66-pxl';
                } else {
                    $col_xl_m = 12 / $grid_masonry[$key]['col_xl_m'];
                }
                if ($grid_masonry[$key]['col_lg_m'] == 'col-66') {
                    $col_lg_m = '66-pxl';
                } else {
                    $col_lg_m = 12 / $grid_masonry[$key]['col_lg_m'];
                }
                $col_md_m = 12 / $grid_masonry[$key]['col_md_m'];
                $col_sm_m = 12 / $grid_masonry[$key]['col_sm_m'];
                $col_xs_m = 12 / $grid_masonry[$key]['col_xs_m'];
                $item_class = "pxl-grid-item col-xl-{$col_xl_m} col-lg-{$col_lg_m} col-md-{$col_md_m} col-sm-{$col_sm_m} col-{$col_xs_m}";

                $img_size_m = $grid_masonry[$key]['img_size_m'];
                if (!empty($img_size_m)) {
                    $images_size = $img_size_m;
                }
            } elseif (!empty($img_size)) {
                $images_size = $img_size;
            }

            if (!empty($tax))
                $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
            else
                $filter_class = '';

            $img_id = get_post_thumbnail_id($post->ID);
            if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)):
                if ($img_id) {
                    $img = pxl_get_image_by_size(array(
                        'attach_id' => $img_id,
                        'thumb_size' => $images_size,
                        'class' => 'no-lazyload',
                    ));
                    $thumbnail = $img['thumbnail'];
                } else {
                    $thumbnail = get_the_post_thumbnail($post->ID, $images_size);
                }
                ?>
                <div class="<?php echo esc_attr($item_class . ' ' . $filter_class); ?>">
                    <div class="pxl-post--inner <?php echo esc_attr($pxl_animate); ?>" data-wow-duration="1.2s">
                        <div class="pxl-post--holder">
                            <h5 class="pxl-post--title">
                                <a class="title-hover-line"
                                    href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?>
                                </a>
                            </h5>
                            <?php if ($show_category == 'true'): ?>
                                <div class="pxl-post--category d-flex">
                                    <?php the_terms($post->ID, 'portfolio-category', '', ''); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="pxl-post--featured hover-imge-effect2">
                            <a class="" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                <?php echo wp_kses_post($thumbnail); ?>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach;
    endif;
}
function foliohub_get_portfolio_grid_layout4($posts = [], $settings = [])
{
    extract($settings);

    $images_size = !empty($img_size) ? $img_size : '1200x800';

    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $item_class = "pxl-grid-item col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col_xs}";
            if (isset($grid_masonry) && !empty($grid_masonry[$key]) && (count($grid_masonry) > 1)) {
                if ($grid_masonry[$key]['col_xl_m'] == 'col-66') {
                    $col_xl_m = '66-pxl';
                } else {
                    $col_xl_m = 12 / $grid_masonry[$key]['col_xl_m'];
                }
                if ($grid_masonry[$key]['col_lg_m'] == 'col-66') {
                    $col_lg_m = '66-pxl';
                } else {
                    $col_lg_m = 12 / $grid_masonry[$key]['col_lg_m'];
                }
                $col_md_m = 12 / $grid_masonry[$key]['col_md_m'];
                $col_sm_m = 12 / $grid_masonry[$key]['col_sm_m'];
                $col_xs_m = 12 / $grid_masonry[$key]['col_xs_m'];
                $item_class = "pxl-grid-item col-xl-{$col_xl_m} col-lg-{$col_lg_m} col-md-{$col_md_m} col-sm-{$col_sm_m} col-{$col_xs_m}";

                $img_size_m = $grid_masonry[$key]['img_size_m'];
                if (!empty($img_size_m)) {
                    $images_size = $img_size_m;
                }
            } elseif (!empty($img_size)) {
                $images_size = $img_size;
            }

            if (!empty($tax))
                $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
            else
                $filter_class = '';

            $img_id = get_post_thumbnail_id($post->ID);
            if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)):
                if ($img_id) {
                    $img = pxl_get_image_by_size(array(
                        'attach_id' => $img_id,
                        'thumb_size' => $images_size,
                        'class' => 'no-lazyload',
                    ));
                    $thumbnail = $img['thumbnail'];
                } else {
                    $thumbnail = get_the_post_thumbnail($post->ID, $images_size);
                }
                $project_icon_type = get_post_meta($post->ID, 'project_icon_type', true);
                $project_icon_font = get_post_meta($post->ID, 'project_icon_font', true);
                $project_icon_img = get_post_meta($post->ID, 'project_icon_img', true);
                ?>
                <div class="<?php echo esc_attr($item_class . ' ' . $filter_class); ?>">
                    <div class="pxl-post--inner <?php echo esc_attr($pxl_animate); ?>" data-wow-duration="1.2s">
                        <div class="pxl-post--holder">
                            <div class="pxl-item-title">
                                <div class="pxl-post--title">
                                    <a class="title-hover-line"
                                        href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?>
                                    </a>
                                </div>
                                <?php if ($show_category == 'true'): ?>
                                    <div class="pxl-post--category d-flex">
                                        <?php the_terms($post->ID, 'portfolio-category', '', ''); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <span class="post-date">
                                <?php echo get_the_date('Y', $post->ID) ?>
                            </span>
                        </div>
                        <div class="pxl-post--featured">
                            <?php if ($project_icon_type == 'icon' && !empty($project_icon_font)): ?>
                                <div class="pxl-post--icon">
                                    <i class="<?php echo esc_attr($project_icon_font); ?>"></i>
                                </div>
                            <?php endif; ?>
                            <?php if ($project_icon_type == 'image' && !empty($project_icon_img)):
                                $icon_img = pxl_get_image_by_size(array(
                                    'attach_id' => $project_icon_img['id'],
                                    'thumb_size' => 'full',
                                ));
                                $icon_thumbnail = $icon_img['thumbnail'];
                                ?>
                                <div class="pxl-post--icon">
                                    <?php echo wp_kses_post($icon_thumbnail); ?>
                                </div>
                            <?php endif; ?>
                            <a class="hover-imge-effect2" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                <?php echo wp_kses_post($thumbnail); ?>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach;
    endif;
}
function foliohub_get_portfolio_grid_layout5($posts = [], $settings = [])
{
    extract($settings);

    $images_size = !empty($img_size) ? $img_size : '1200x800';

    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $item_class = "pxl-grid-item col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col_xs}";
            if (isset($grid_masonry) && !empty($grid_masonry[$key]) && (count($grid_masonry) > 1)) {
                if ($grid_masonry[$key]['col_xl_m'] == 'col-66') {
                    $col_xl_m = '66-pxl';
                } else {
                    $col_xl_m = 12 / $grid_masonry[$key]['col_xl_m'];
                }
                if ($grid_masonry[$key]['col_lg_m'] == 'col-66') {
                    $col_lg_m = '66-pxl';
                } else {
                    $col_lg_m = 12 / $grid_masonry[$key]['col_lg_m'];
                }
                $col_md_m = 12 / $grid_masonry[$key]['col_md_m'];
                $col_sm_m = 12 / $grid_masonry[$key]['col_sm_m'];
                $col_xs_m = 12 / $grid_masonry[$key]['col_xs_m'];
                $item_class = "pxl-grid-item col-xl-{$col_xl_m} col-lg-{$col_lg_m} col-md-{$col_md_m} col-sm-{$col_sm_m} col-{$col_xs_m}";

                $img_size_m = $grid_masonry[$key]['img_size_m'];
                if (!empty($img_size_m)) {
                    $images_size = $img_size_m;
                }
            } elseif (!empty($img_size)) {
                $images_size = $img_size;
            }

            if (!empty($tax))
                $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
            else
                $filter_class = '';

            $img_id = get_post_thumbnail_id($post->ID);
            if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)):
                if ($img_id) {
                    $img = pxl_get_image_by_size(array(
                        'attach_id' => $img_id,
                        'thumb_size' => $images_size,
                        'class' => 'no-lazyload',
                    ));
                    $thumbnail = $img['thumbnail'];
                } else {
                    $thumbnail = get_the_post_thumbnail($post->ID, $images_size);
                }
                $project_icon_type = get_post_meta($post->ID, 'project_icon_type', true);
                $project_icon_font = get_post_meta($post->ID, 'project_icon_font', true);
                $project_icon_img = get_post_meta($post->ID, 'project_icon_img', true);
                ?>
                <div class="<?php echo esc_attr($item_class . ' ' . $filter_class); ?>">
                    <div class="pxl-post--inner <?php echo esc_attr($pxl_animate); ?>" data-wow-duration="1.2s">
                        <div class="pxl-post--featured">
                            <div class="pxl-holder">
                                <?php if ($project_icon_type == 'icon' && !empty($project_icon_font)): ?>
                                    <div class="pxl-post--icon">
                                        <i class="<?php echo esc_attr($project_icon_font); ?>"></i>
                                    </div>
                                <?php endif; ?>
                                <?php if ($project_icon_type == 'image' && !empty($project_icon_img)):
                                    $icon_img = pxl_get_image_by_size(array(
                                        'attach_id' => $project_icon_img['id'],
                                        'thumb_size' => 'full',
                                    ));
                                    $icon_thumbnail = $icon_img['thumbnail'];
                                    ?>
                                    <div class="pxl-post--icon">
                                        <?php echo wp_kses_post($icon_thumbnail); ?>
                                    </div>
                                <?php endif; ?>
                                <div class="pxl-post--holder">
                                    <span class="post-date">
                                        <?php echo get_the_date('Y', $post->ID) ?>
                                    </span>
                                    <div class="pxl-item-title">
                                        <?php if ($show_category == 'true'): ?>
                                            <div class="pxl-post--category d-flex">
                                                <?php the_terms($post->ID, 'portfolio-category', '', ''); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <a class="hover-imge-effect2" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                <?php echo wp_kses_post($thumbnail); ?>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach;
    endif;
}
function foliohub_get_portfolio_grid_layout6($posts = [], $settings = [])
{
    extract($settings);

    $images_size = !empty($img_size) ? $img_size : '1260x720';

    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $item_class = "pxl-grid-item col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col_xs}";
            if (isset($grid_masonry) && !empty($grid_masonry[$key]) && (count($grid_masonry) > 1)) {
                if ($grid_masonry[$key]['col_xl_m'] == 'col-66') {
                    $col_xl_m = '66-pxl';
                } else {
                    $col_xl_m = 12 / $grid_masonry[$key]['col_xl_m'];
                }
                if ($grid_masonry[$key]['col_lg_m'] == 'col-66') {
                    $col_lg_m = '66-pxl';
                } else {
                    $col_lg_m = 12 / $grid_masonry[$key]['col_lg_m'];
                }
                $col_md_m = 12 / $grid_masonry[$key]['col_md_m'];
                $col_sm_m = 12 / $grid_masonry[$key]['col_sm_m'];
                $col_xs_m = 12 / $grid_masonry[$key]['col_xs_m'];
                $item_class = "pxl-grid-item col-xl-{$col_xl_m} col-lg-{$col_lg_m} col-md-{$col_md_m} col-sm-{$col_sm_m} col-{$col_xs_m}";

                $img_size_m = $grid_masonry[$key]['img_size_m'];
                if (!empty($img_size_m)) {
                    $images_size = $img_size_m;
                }
            } elseif (!empty($img_size)) {
                $images_size = $img_size;
            }

            if (!empty($tax))
                $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
            else
                $filter_class = '';

            $img_id = get_post_thumbnail_id($post->ID);
            if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)):
                if ($img_id) {
                    $img = pxl_get_image_by_size(array(
                        'attach_id' => $img_id,
                        'thumb_size' => $images_size,
                        'class' => 'no-lazyload',
                    ));
                    $thumbnail = $img['thumbnail'];
                } else {
                    $thumbnail = get_the_post_thumbnail($post->ID, $images_size);
                }
                $project_icon_type = get_post_meta($post->ID, 'project_icon_type', true);
                $project_icon_font = get_post_meta($post->ID, 'project_icon_font', true);
                $project_icon_img = get_post_meta($post->ID, 'project_icon_img', true);
                $tag_project = get_post_meta($post->ID, 'tag_project', true);
                ?>
                <div class="<?php echo esc_attr($item_class . ' ' . $filter_class); ?>">
                    <div class="pxl-post--inner <?php echo esc_attr($pxl_animate); ?>" data-wow-duration="1.2s">
                        <div class="pxl-post--featured">
                            <?php if ($project_icon_type == 'icon' && !empty($project_icon_font)): ?>
                                <div class="pxl-post--icon">
                                    <i class="<?php echo esc_attr($project_icon_font); ?>"></i>
                                </div>
                            <?php endif; ?>
                            <?php if ($project_icon_type == 'image' && !empty($project_icon_img)):
                                $icon_img = pxl_get_image_by_size(array(
                                    'attach_id' => $project_icon_img['id'],
                                    'thumb_size' => 'full',
                                ));
                                $icon_thumbnail = $icon_img['thumbnail'];
                                ?>
                                <div class="pxl-post--icon">
                                    <?php echo wp_kses_post($icon_thumbnail); ?>
                                </div>
                            <?php endif; ?>
                            <a class="hover-imge-effect2" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                <?php echo wp_kses_post($thumbnail); ?>
                            </a>
                        </div>
                        <div class="pxl-post--holder">
                            <div class="pxl-item1">
                                <h5 class="pxl-post--title">
                                    <a class="title-hover-line"
                                        href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?>
                                    </a>
                                </h5>
                                <div class="pxl-post--tag">
                                    <?php
                                    if (is_array($tag_project)) {
                                        echo '<div class="tag-list">';
                                        foreach ($tag_project as $tag) {
                                            echo '<span>' . esc_html($tag) . '</span>';
                                        }
                                        echo '</div>';
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php if ($show_category == 'true'): ?>
                                <div class="pxl-post--category d-flex">
                                    <?php the_terms($post->ID, 'portfolio-category', '', ''); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach;
    endif;
}
function foliohub_get_portfolio_grid_layout7($posts = [], $settings = [])
{
    extract($settings);

    $images_size = !empty($img_size) ? $img_size : '828x936';

    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $item_class = "pxl-grid-item col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col_xs}";
            if (isset($grid_masonry) && !empty($grid_masonry[$key]) && (count($grid_masonry) > 1)) {
                if ($grid_masonry[$key]['col_xl_m'] == 'col-66') {
                    $col_xl_m = '66-pxl';
                } else {
                    $col_xl_m = 12 / $grid_masonry[$key]['col_xl_m'];
                }
                if ($grid_masonry[$key]['col_lg_m'] == 'col-66') {
                    $col_lg_m = '66-pxl';
                } else {
                    $col_lg_m = 12 / $grid_masonry[$key]['col_lg_m'];
                }
                $col_md_m = 12 / $grid_masonry[$key]['col_md_m'];
                $col_sm_m = 12 / $grid_masonry[$key]['col_sm_m'];
                $col_xs_m = 12 / $grid_masonry[$key]['col_xs_m'];
                $item_class = "pxl-grid-item col-xl-{$col_xl_m} col-lg-{$col_lg_m} col-md-{$col_md_m} col-sm-{$col_sm_m} col-{$col_xs_m}";

                $img_size_m = $grid_masonry[$key]['img_size_m'];
                if (!empty($img_size_m)) {
                    $images_size = $img_size_m;
                }
            } elseif (!empty($img_size)) {
                $images_size = $img_size;
            }

            if (!empty($tax))
                $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
            else
                $filter_class = '';

            $img_id = get_post_thumbnail_id($post->ID);
            if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)):
                if ($img_id) {
                    $img = pxl_get_image_by_size(array(
                        'attach_id' => $img_id,
                        'thumb_size' => $images_size,
                        'class' => 'no-lazyload',
                    ));
                    $thumbnail = $img['thumbnail'];
                } else {
                    $thumbnail = get_the_post_thumbnail($post->ID, $images_size);
                }
                ?>
                <div class="<?php echo esc_attr($item_class . ' ' . $filter_class); ?>">
                    <div class="pxl-post--inner <?php echo esc_attr($pxl_animate); ?>" data-wow-duration="1.2s">
                        <div class="pxl-post--featured hover-imge-effect2">
                            <a class="" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                <?php echo wp_kses_post($thumbnail); ?>
                            </a>
                        </div>
                        <div class="pxl-post--holder">
                            <div class="pxl-item-title">
                                <h5 class="pxl-post--title">
                                    <a class="title-hover-line"
                                        href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?>
                                    </a>
                                </h5>
                                <?php if ($show_category == 'true'): ?>
                                    <div class="pxl-post--category d-flex">
                                        <?php the_terms($post->ID, 'portfolio-category', '', ''); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <h6 class="post-date">
                                <?php echo get_the_date('Y', $post->ID) ?>
                            </h6>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach;
    endif;
}
function foliohub_get_portfolio_grid_layout8($posts = [], $settings = [])
{
    extract($settings);

    $images_size = !empty($img_size) ? $img_size : '860x600';

    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $item_class = "pxl-grid-item col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col_xs}";
            if (isset($grid_masonry) && !empty($grid_masonry[$key]) && (count($grid_masonry) > 1)) {
                if ($grid_masonry[$key]['col_xl_m'] == 'col-66') {
                    $col_xl_m = '66-pxl';
                } else {
                    $col_xl_m = 12 / $grid_masonry[$key]['col_xl_m'];
                }
                if ($grid_masonry[$key]['col_lg_m'] == 'col-66') {
                    $col_lg_m = '66-pxl';
                } else {
                    $col_lg_m = 12 / $grid_masonry[$key]['col_lg_m'];
                }
                $col_md_m = 12 / $grid_masonry[$key]['col_md_m'];
                $col_sm_m = 12 / $grid_masonry[$key]['col_sm_m'];
                $col_xs_m = 12 / $grid_masonry[$key]['col_xs_m'];
                $item_class = "pxl-grid-item col-xl-{$col_xl_m} col-lg-{$col_lg_m} col-md-{$col_md_m} col-sm-{$col_sm_m} col-{$col_xs_m}";

                $img_size_m = $grid_masonry[$key]['img_size_m'];
                if (!empty($img_size_m)) {
                    $images_size = $img_size_m;
                }
            } elseif (!empty($img_size)) {
                $images_size = $img_size;
            }

            if (!empty($tax))
                $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
            else
                $filter_class = '';

            $img_id = get_post_thumbnail_id($post->ID);
            if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)):
                if ($img_id) {
                    $img = pxl_get_image_by_size(array(
                        'attach_id' => $img_id,
                        'thumb_size' => $images_size,
                        'class' => 'no-lazyload',
                    ));
                    $thumbnail = $img['thumbnail'];
                } else {
                    $thumbnail = get_the_post_thumbnail($post->ID, $images_size);
                }
                $project_icon_type = get_post_meta($post->ID, 'project_icon_type', true);
                $project_icon_font = get_post_meta($post->ID, 'project_icon_font', true);
                $project_icon_img = get_post_meta($post->ID, 'project_icon_img', true);
                ?>
                <div class="<?php echo esc_attr($item_class . ' ' . $filter_class); ?>">
                    <div class="pxl-post--inner <?php echo esc_attr($pxl_animate); ?>" data-wow-duration="1.2s">
                        <div class="pxl-icon-number pxl-icon-number-<?php echo esc_html(str_pad($key + 1, STR_PAD_LEFT)); ?>">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="pxl-post--featured ">
                            <?php if ($project_icon_type == 'icon' && !empty($project_icon_font)): ?>
                                <div class="pxl-post--icon">
                                    <i class="<?php echo esc_attr($project_icon_font); ?>"></i>
                                </div>
                            <?php endif; ?>
                            <?php if ($project_icon_type == 'image' && !empty($project_icon_img)):
                                $icon_img = pxl_get_image_by_size(array(
                                    'attach_id' => $project_icon_img['id'],
                                    'thumb_size' => 'full',
                                ));
                                $icon_thumbnail = $icon_img['thumbnail'];
                                ?>
                                <div class="pxl-post--icon">
                                    <?php echo wp_kses_post($icon_thumbnail); ?>
                                </div>
                            <?php endif; ?>
                            <a class="hover-imge-effect2" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                <?php echo wp_kses_post($thumbnail); ?>
                            </a>
                        </div>
                        <div class="pxl-post--holder">
                            <h6 class="pxl-post--title">
                                <a class="title-hover-line"
                                    href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?></a>
                            </h6>
                            <?php if ($show_excerpt == 'true'): ?>
                                <div class="pxl-post--content">
                                    <?php if ($show_excerpt == 'true'): ?>
                                        <?php
                                        echo wp_trim_words($post->post_excerpt, $num_words, null);
                                        ?>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($show_category == 'true'): ?>
                                <div class="pxl-post--category d-flex">
                                    <?php $terms = get_the_terms($post->ID, 'portfolio-category');
                                        if (!empty($terms) && !is_wp_error($terms)) {
                                            foreach ($terms as $term) {
                                                echo '<a href="' . esc_url(get_term_link($term)) . '" class="pxl-anm-border">';
                                                echo esc_html($term->name);
                                                echo '</a>';
                                            }
                                        }
                                    ?>
                                </div>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach;
    endif;
}
// End Portfolio Grid
//--------------------------------------------------

// Start Service Grid
//--------------------------------------------------
function foliohub_get_service_grid_layout1($posts = [], $settings = [])
{
    extract($settings);
    $images_size = !empty($img_size) ? $img_size : 'full';
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $item_class = "pxl-grid-item col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col_xs}";
            if (isset($grid_masonry) && !empty($grid_masonry[$key]) && (count($grid_masonry) > 1)) {
                if ($grid_masonry[$key]['col_xl_m'] == 'col-66') {
                    $col_xl_m = '66-pxl';
                } else {
                    $col_xl_m = 12 / $grid_masonry[$key]['col_xl_m'];
                }
                if ($grid_masonry[$key]['col_lg_m'] == 'col-66') {
                    $col_lg_m = '66-pxl';
                } else {
                    $col_lg_m = 12 / $grid_masonry[$key]['col_lg_m'];
                }
                $col_md_m = 12 / $grid_masonry[$key]['col_md_m'];
                $col_sm_m = 12 / $grid_masonry[$key]['col_sm_m'];
                $col_xs_m = 12 / $grid_masonry[$key]['col_xs_m'];
                $item_class = "pxl-grid-item col-xl-{$col_xl_m} col-lg-{$col_lg_m} col-md-{$col_md_m} col-sm-{$col_sm_m} col-{$col_xs_m}";

                $img_size_m = $grid_masonry[$key]['img_size_m'];
                if (!empty($img_size_m)) {
                    $images_size = $img_size_m;
                }
            } elseif (!empty($img_size)) {
                $images_size = $img_size;
            }

            if (!empty($tax))
                $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
            else
                $filter_class = '';
            $img_id = get_post_thumbnail_id($post->ID);
            if ($img_id) {
                $img = pxl_get_image_by_size(array(
                    'attach_id' => $img_id,
                    'thumb_size' => $images_size,
                    'class' => 'no-lazyload',
                ));
                $thumbnail = $img['thumbnail'];
            } else {
                $thumbnail = get_the_post_thumbnail($post->ID, $images_size);
            } ?>
            <div class="<?php echo esc_attr($item_class . ' ' . $filter_class); ?>">
                <div class="pxl-post--inner <?php echo esc_attr($pxl_animate); ?>" data-wow-duration="1.2s">
                    <div class="pxl-post-content-hide">
                        <h4 class="pxl-post--title">
                            <a class="title-hover-line"
                                href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?></a>
                        </h4>
                        <?php if ($show_excerpt == 'true'): ?>
                            <div class="pxl-post--content">
                                <?php echo wp_trim_words($post->post_excerpt, $num_words, null); ?>
                            </div>
                        <?php endif; ?>
                        <?php if ($show_button == 'true'): ?>
                            <div class="pxl-post--button">
                                <a class="btn--readmore btn" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                    <span class="btn--text">
                                        <?php if (!empty($button_text)) {
                                            echo esc_attr($button_text);
                                        } else {
                                            echo esc_html__('Explore Now', 'foliohub');
                                        } ?>
                                    </span>
                                    <span class="pxl-btn-icon">
                                        <i aria-hidden="true" class="bootstrap-icons bi-arrow-right"></i>
                                    </span>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach;
    endif;
}
// End Service Grid
//-------------------------------------------------
// Start Portfolio List
//--------------------------------------------------
function foliohub_get_portfolio_list_layout1($posts = [], $settings = [])
{
    extract($settings);

    $images_size = !empty($img_size) ? $img_size : '1300x750';

    if (is_array($posts)):
        foreach ($posts as $key => $post):
            if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)):
                $img_id = get_post_thumbnail_id($post->ID);
                if ($img_id) {
                    $img = pxl_get_image_by_size(array(
                        'attach_id' => $img_id,
                        'thumb_size' => $images_size,
                        'class' => 'no-lazyload',
                    ));
                    $thumbnail = $img['thumbnail'];
                } else {
                    $thumbnail = get_the_post_thumbnail($post->ID, $images_size);
                }
                $project_icon_type = get_post_meta($post->ID, 'project_icon_type', true);
                $project_icon_font = get_post_meta($post->ID, 'project_icon_font', true);
                $project_icon_img = get_post_meta($post->ID, 'project_icon_img', true);
                ?>
                <div class="pxl-post--inner">
                    <div class="pxl-post--featured">
                        <div class="pxl-item--holder">
                            <h4 class="pxl-post--title">
                                <?php if ($show_date == 'true'): ?>
                                    <span class="post-date">
                                        <?php echo get_the_date('Y', $post->ID) ?>
                                    </span>
                                <?php endif; ?>
                                <a class="title-hover-line"
                                    href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?>
                                </a>
                                <div class="pxl-post--category d-flex">
                                    <?php the_terms($post->ID, 'portfolio-category', '', ''); ?>
                                </div>
                            </h4>
                        </div>
                        <?php if ($project_icon_type == 'icon' && !empty($project_icon_font)): ?>
                            <div class="pxl-post--icon">
                                <i class="<?php echo esc_attr($project_icon_font); ?>"></i>
                            </div>
                        <?php endif; ?>
                        <?php if ($project_icon_type == 'image' && !empty($project_icon_img)):
                            $icon_img = pxl_get_image_by_size(array(
                                'attach_id' => $project_icon_img['id'],
                                'thumb_size' => 'full',
                            ));
                            $icon_thumbnail = $icon_img['thumbnail'];
                            ?>
                            <div class="pxl-post--icon">
                                <?php echo wp_kses_post($icon_thumbnail); ?>
                            </div>
                        <?php endif; ?>
                        <a class="hover-imge-effect2" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                            <?php echo wp_kses_post($thumbnail); ?>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach;
    endif;
}
// End Service List
// Start Service List
//--------------------------------------------------
function foliohub_get_service_list_layout1($posts = [], $settings = [])
{
    extract($settings);
    foreach ($posts as $key => $post):

        if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)) {
            $img_id = get_post_thumbnail_id($post->ID);
            if ($img_id) {
                $img = pxl_get_image_by_size(array(
                    'attach_id' => $img_id,
                    'thumb_size' => $img_size,
                    'class' => 'no-lazyload',
                ));
                $thumbnail = $img['thumbnail'];
            } else {
                $thumbnail = get_the_post_thumbnail($post->ID, $img_size);
            }
        } else {
            $thumbnail = '';
        }

        if (!empty($tax))
            $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
        else
            $filter_class = '';
        $img_id = get_post_thumbnail_id($post->ID);
        $service_icon_type = get_post_meta($post->ID, 'service_icon_type', true);
        $service_icon_font = get_post_meta($post->ID, 'service_icon_font', true);
        $service_icon_imgs = get_post_meta($post->ID, 'service_icon_img', true);
        ?>
        <div class="list-item-inner item-inner-wrap">
            <div class="pxl-item--top">
                <h3 class="pxl-item-number">
                    <?php echo esc_html(str_pad($key + 1, 2, '0', STR_PAD_LEFT)); ?>
                </h3>
                <h3 class="pxl-post--title">
                    <a class="title-hover-line"
                        href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?></a>
                </h3>
            </div>
            <div class="pxl-item--bottom">
                <h3 class="pxl-item-number">
                    <?php echo esc_html(str_pad($key + 1, 2, '0', STR_PAD_LEFT)); ?>
                </h3>
                <div class="pxl-item-content">
                    <h3 class="pxl-post--title">
                        <a class="title-hover-line"
                            href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?></a>
                    </h3>
                    <?php if ($show_excerpt == 'true'): ?>
                        <div class="pxl-post--content">
                            <?php echo wp_trim_words($post->post_excerpt, $num_words, null); ?>
                        </div>
                    <?php endif; ?>
                    <div class="pxl-post--button">
                        <a class="btn--readmore btn" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                            <span class="btn--text">
                                <?php if (!empty($button_text)) {
                                    echo esc_attr($button_text);
                                } else {
                                    echo esc_html__('Service Details', 'foliohub');
                                } ?>
                            </span>
                            <span class="pxl-btn-icon">
                                <i aria-hidden="true" class="bootstrap-icons bi-arrow-right"></i>
                            </span>
                        </a>
                    </div>
                </div>
                <div class="pxl-item-icon">
                    <?php if ($service_icon_type == 'icon' && !empty($service_icon_font)): ?>
                        <div class="pxl-post-icon-wrap">
                            <div class="pxl-post--icon">
                                <i class="<?php echo esc_attr($service_icon_font); ?>"></i>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if ($service_icon_type == 'image' && !empty($service_icon_imgs)):
                        $img_ids = array_map('trim', explode(',', $service_icon_imgs));
                        if (!empty($img_ids)): ?>
                            <div class="pxl-post-icon-wrap multi-icons">
                                <?php foreach ($img_ids as $img_id):
                                    $img_url = wp_get_attachment_image_url($img_id, 'full');
                                    $img_alt = '';
                                    if (!empty($img_id)) {
                                        $img_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);

                                        if (empty($img_alt)) {
                                            $img_alt = get_the_title($img_id);
                                        }
                                    }
                                    if ($img_url): ?>
                                        <div class="pxl-post--icon">
                                            <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($img_alt); ?>">
                                            <a href="<?php echo esc_url($img_url); ?>" class="lightbox">
                                                <i aria-hidden="true" class="bootstrap-icons bi-eye-fill"></i>
                                            </a>
                                        </div>
                                    <?php endif;
                                endforeach; ?>
                            </div>
                        <?php endif;
                    endif; ?>
                </div>
            </div>
        </div>
        <?php
    endforeach;
}
function foliohub_get_service_list_layout2($posts = [], $settings = [])
{
    extract($settings);
    $image_size = !empty($img_size) ? $img_size : '600x360';
    foreach ($posts as $key => $post):

        if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)) {
            $img_id = get_post_thumbnail_id($post->ID);
            if ($img_id) {
                $img = pxl_get_image_by_size(array(
                    'attach_id' => $img_id,
                    'thumb_size' => $image_size,
                    'class' => 'no-lazyload',
                ));
                $thumbnail = $img['thumbnail'];
            } else {
                $thumbnail = get_the_post_thumbnail($post->ID, $image_size);
            }
        } else {
            $thumbnail = '';
        }

        if (!empty($tax))
            $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
        else
            $filter_class = '';
        $img_id = get_post_thumbnail_id($post->ID);
        $multi_text_country_ser = get_post_meta($post->ID, 'multi_text_country_ser', true);

        ?>
        <div class="list-item-inner item-inner-wrap pxl-anm-border">
            <div class="pxl-item--bottom">
                <div class="pxl-item-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="#E4D969">
                        <path
                            d="M15.0937 26.7997C18.0957 24.918 21.9059 24.9196 24.9113 26.7997L40.0033 40L26.803 24.9096C24.923 21.9076 24.923 18.0924 26.803 15.092L40.0033 0L24.9113 13.1986C21.9059 15.0804 18.0957 15.0787 15.0937 13.197L0.00167129 0L13.197 15.0937C15.0787 18.0941 15.0787 21.9076 13.1986 24.908L0 40L15.092 26.7997H15.0937Z" />
                    </svg>
                </div>
                <h4 class="pxl-post--title">
                    <a class="title-hover-line"
                        href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?></a>
                </h4>
                <?php if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)):
                    $img_id = get_post_thumbnail_id($post->ID);
                    $img = pxl_get_image_by_size(array(
                        'attach_id' => $img_id,
                        'thumb_size' => $image_size,
                    ));
                    $thumbnail = $img['thumbnail'];
                    ?>
                    <div class="pxl-post--featured hover-imge-effect2">
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                            <?php echo wp_kses_post($thumbnail); ?>
                        </a>
                    </div>
                <?php endif; ?>
                <div class="pxl-item-content">
                    <?php if ($show_excerpt == 'true'): ?>
                        <div class="pxl-post--content">
                            <?php echo wp_trim_words($post->post_excerpt, $num_words, null); ?>
                        </div>
                    <?php endif; ?>
                    <?php
                    if (!empty($multi_text_country_ser) && is_array($multi_text_country_ser)) {
                        echo '<div class="tags-list">';
                        foreach ($multi_text_country_ser as $item) {
                            echo '<span>' . esc_html($item) . '</span>';
                        }
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
    endforeach;
}

function foliohub_get_service_list_layout3($posts = [], $settings = [])
{
    extract($settings);
    $image_size = !empty($img_size) ? $img_size : '600x360';
    foreach ($posts as $key => $post):

        if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)) {
            $img_id = get_post_thumbnail_id($post->ID);
            if ($img_id) {
                $img = pxl_get_image_by_size(array(
                    'attach_id' => $img_id,
                    'thumb_size' => $image_size,
                    'class' => 'no-lazyload',
                ));
                $thumbnail = $img['thumbnail'];
            } else {
                $thumbnail = get_the_post_thumbnail($post->ID, $image_size);
            }
        } else {
            $thumbnail = '';
        }

        if (!empty($tax))
            $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
        else
            $filter_class = '';
        $img_id = get_post_thumbnail_id($post->ID);
        $service_icon_imgs = get_post_meta($post->ID, 'service_icon_img', true);
        $multi_text_list_ser = get_post_meta($post->ID, 'multi_text_list_ser', true);
        $service_icon_type = get_post_meta($post->ID, 'service_icon_type', true);
        ?>
        <div class="list-item-inner item-inner-wrap">
            <div class="pxl-item--inner">
                <div class="pxl-icon-number pxl-icon-number-<?php echo esc_html(str_pad($key + 1, STR_PAD_LEFT)); ?>">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="pxl-item-content">
                    <h4 class="pxl-post--title">
                        <a class="title-hover-line"
                            href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?></a>
                    </h4>
                    <?php if ($show_excerpt == 'true'): ?>
                        <div class="pxl-post--content">
                            <?php echo wp_trim_words($post->post_excerpt, $num_words, null); ?>
                        </div>
                    <?php endif; ?>
                    <div class="pxl-footer-item">
                        <div class="pxl-item-icon">
                            <?php if ($service_icon_type == 'icon' && !empty($service_icon_font)): ?>
                                <div class="pxl-post-icon-wrap">
                                    <div class="pxl-post--icon">
                                        <i class="<?php echo esc_attr($service_icon_font); ?>"></i>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if ($service_icon_type == 'image' && !empty($service_icon_imgs)):
                                $img_ids = array_map('trim', explode(',', $service_icon_imgs));
                                if (!empty($img_ids)): ?>
                                    <div class="pxl-post-icon-wrap multi-icons">
                                        <?php foreach ($img_ids as $img_id):
                                            $img_url = wp_get_attachment_image_url($img_id, 'full');
                                            $img_alt = '';

                                            if (!empty($img_id)) {
                                                $img_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);

                                                if (empty($img_alt)) {
                                                    $img_alt = get_the_title($img_id);
                                                }
                                            }
                                            if ($img_url): ?>
                                                <div class="pxl-post--icon">
                                                    <img src="<?php echo esc_url( $img_url ); ?>" alt="<?php echo esc_attr( $img_alt ); ?>">
                                                    <a href="<?php echo esc_url($img_url); ?>" class="lightbox">
                                                        <i aria-hidden="true" class="bootstrap-icons bi-eye-fill"></i>
                                                    </a>
                                                </div>
                                            <?php endif;
                                        endforeach; ?>
                                    </div>
                                <?php endif;
                            endif; ?>
                        </div>
                        <div class="pxl-list">
                            <?php if (!empty($multi_text_list_ser) && is_array($multi_text_list_ser)) {
                                echo '<div class="pxl-list">';
                                foreach ($multi_text_list_ser as $item) {
                                    echo '<span><i class="bi-plus" aria-hidden="true"></i> ' . esc_html($item) . '</span>';
                                }
                                echo '</div>';
                            } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    endforeach;
}
function foliohub_get_service_list_layout4($posts = [], $settings = [])
{
    extract($settings);
    $image_size = !empty($img_size) ? $img_size : '520x296';
    foreach ($posts as $key => $post):

        if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)) {
            $img_id = get_post_thumbnail_id($post->ID);
            if ($img_id) {
                $img = pxl_get_image_by_size(array(
                    'attach_id' => $img_id,
                    'thumb_size' => $image_size,
                    'class' => 'no-lazyload',
                ));
                $thumbnail = $img['thumbnail'];
            } else {
                $thumbnail = get_the_post_thumbnail($post->ID, $image_size);
            }
        } else {
            $thumbnail = '';
        }

        if (!empty($tax))
            $filter_class = pxl_get_term_of_post_to_class($post->ID, array_unique($tax));
        else
            $filter_class = '';
        $img_id = get_post_thumbnail_id($post->ID);
        $custom_yoga_lever = get_post_meta($post->ID, 'custom_yoga_lever', true);
        $custom_yoga_duration = get_post_meta($post->ID, 'custom_yoga_duration', true);
        $multi_text_country_ser = get_post_meta($post->ID, 'multi_text_country_ser', true);
        ?>
        <div class="list-item-inner item-inner-wrap">
            <div class="pxl-item--inner pxl-flex">
                <div class="pxl-item-content">
                    <div class="pxl-item--tag">
                        <?php
                        if (!empty($multi_text_country_ser) && is_array($multi_text_country_ser)) {
                            echo '<div class="tags-list">';
                            foreach ($multi_text_country_ser as $item) {
                                echo '<span>' . esc_html($item) . '</span>';
                            }
                            echo '</div>';
                        }
                        ?>
                    </div>
                    <h4 class="pxl-post--title">
                        <a class="title-hover-line"
                            href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo pxl_print_html(get_the_title($post->ID)); ?></a>
                    </h4>
                    <?php if ($show_excerpt == 'true'): ?>
                        <div class="pxl-post--content">
                            <?php echo wp_trim_words($post->post_excerpt, $num_words, null); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="pxl-item--desc">
                    <div class="pxl-yg-lever">
                        <?php echo esc_html__('Yoga level:', 'foliohub'); ?>
                        <h5 class="pxl-item-title">
                            <?php echo pxl_print_html($custom_yoga_lever) ?>
                        </h5>
                    </div>
                    <div class="pxl-yg-duration">
                        <?php echo esc_html__('Duration:', 'foliohub'); ?>
                        <h5 class="pxl-item-title">
                            <?php echo pxl_print_html($custom_yoga_duration) ?>
                        </h5>
                    </div>
                </div>
                <div class="pxl-footer-item">
                    <div class="pxl-item-icon">
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                            <?php echo wp_kses_post($thumbnail); ?>
                        </a>
                    </div>

                </div>
            </div>
        </div>
        <?php
    endforeach;
}
// End Service List
add_action('wp_ajax_foliohub_load_more_post_grid', 'foliohub_load_more_post_grid');
add_action('wp_ajax_nopriv_foliohub_load_more_post_grid', 'foliohub_load_more_post_grid');
function foliohub_load_more_post_grid()
{
    try {
        if (!isset($_POST['settings'])) {
            throw new Exception(__('Something went wrong while requesting. Please try again!', 'foliohub'));
        }

        $settings = isset($_POST['settings']) ? $_POST['settings'] : null;

        $source = isset($settings['source']) ? $settings['source'] : '';
        $term_slug = isset($settings['term_slug']) ? $settings['term_slug'] : '';
        if (!empty($term_slug) && $term_slug != '*') {
            $term_slug = str_replace('.', '', $term_slug);
            $source = [$term_slug . '|' . $settings['tax'][0]];
        }
        if (isset($_POST['handler_click']) && sanitize_text_field(wp_unslash($_POST['handler_click'])) == 'filter') {
            set_query_var('paged', 1);
            $settings['paged'] = 1;
        } elseif (isset($_POST['handler_click']) && sanitize_text_field(wp_unslash($_POST['handler_click'])) == 'select_orderby') {
            set_query_var('paged', 1);
            $settings['paged'] = 1;
        } else {
            set_query_var('paged', (int) $settings['paged']);
        }

        extract(pxl_get_posts_of_grid(
            $settings['post_type'],
            [
                'source' => $source,
                'orderby' => isset($settings['orderby']) ? $settings['orderby'] : 'date',
                'order' => isset($settings['order']) ? ($settings['orderby'] == 'title' ? 'asc' : sanitize_text_field($settings['order'])) : 'desc',
                'limit' => isset($settings['limit']) ? $settings['limit'] : '6',
                'post_ids' => isset($settings['post_ids']) ? $settings['post_ids'] : [],
                'post_not_in' => isset($settings['post_not_in']) ? $settings['post_not_in'] : [],
            ],
            $settings['tax']
        ));

        ob_start();
        if (isset($settings['wg_type']) && $settings['wg_type'] == 'post-list') {
            foliohub_get_post_list($posts, $settings);
        } else {
            foliohub_get_post_grid($posts, $settings);
        }
        $html = ob_get_clean();

        $pagin_html = '';
        if (isset($settings['pagination_type']) && $settings['pagination_type'] == 'pagination') {
            ob_start();
            foliohub()->page->get_pagination($query, true);
            $pagin_html = ob_get_clean();
        }

        $result_count = '';
        if (isset($settings['show_toolbar']) && $settings['show_toolbar'] == 'show') {
            ob_start();
            if ((int) $settings['paged'] == 0) {
                $limit_start = 1;
                $limit_end = ((int) $settings['limit'] >= $total) ? $total : (int) $settings['limit'];
            } else {
                $limit_start = (((int) $settings['paged'] - 1) * (int) $settings['limit']) + 1;
                $limit_end = (int) $settings['paged'] * (int) $settings['limit'];
                $limit_end = ($limit_end >= $total) ? $total : $limit_end;
            }
            if (isset($settings['pagination_type']) && $settings['pagination_type'] == 'loadmore') {
                printf(
                    '<span class="result-count">%1$s %2$s %3$s %4$s %5$s</span>',
                    esc_html__('Showing', 'foliohub'),
                    '1-' . $limit_end,
                    esc_html__('of', 'foliohub'),
                    $total,
                    esc_html__('results', 'foliohub')
                );
            } else {
                printf(
                    '<span class="result-count">%1$s %2$s %3$s %4$s %5$s</span>',
                    esc_html__('Showing', 'foliohub'),
                    $limit_start . '-' . $limit_end,
                    esc_html__('of', 'foliohub'),
                    $total,
                    esc_html__('results', 'foliohub')
                );
            }

            $result_count = ob_get_clean();
        }

        wp_send_json(
            array(
                'status' => true,
                'message' => esc_attr__('Load Successfully!', 'foliohub'),
                'data' => array(
                    'html' => $html,
                    'pagin_html' => $pagin_html,
                    'paged' => $settings['paged'],
                    'posts' => $posts,
                    'max' => $max,
                    'result_count' => $result_count,
                ),
            )
        );
    } catch (Exception $e) {
        wp_send_json(array('status' => false, 'message' => $e->getMessage()));
    }
    die;
}


//background column section
add_action('elementor/frontend/container/before_render', 'foliohub_add_bg_columns_prepare');
add_action('elementor/frontend/section/before_render', 'foliohub_add_bg_columns_prepare');

add_action('elementor/frontend/container/after_render', 'foliohub_add_bg_columns_render');
add_action('elementor/frontend/section/after_render', 'foliohub_add_bg_columns_render');

function foliohub_add_bg_columns_prepare($element)
{
    $settings = $element->get_settings_for_display();

    if (!empty($settings['col_bg_col']) && $settings['col_bg_col'] === 'column') {
        $element->add_render_attribute('_wrapper', 'data-has-bg-col', 'true');
    }
}

function foliohub_add_bg_columns_render($element)
{
    $settings = $element->get_settings_for_display();

    if (empty($settings['col_bg_col']) || $settings['col_bg_col'] === 'none') {
        return;
    }

    // Double column background
    if ($settings['col_bg_col'] === 'column') {
        $count = !empty($settings['col_bg_count']) ? intval($settings['col_bg_count']) : 3;

        echo '<div class="pxl-bg-col type-column">';
        for ($i = 0; $i < $count; $i++) {
            echo '<span class="pxl-anm-border"></span>';
        }
        echo '</div>';
    }

    // Single column background
    if ($settings['col_bg_col'] === 'single') {
        $count = !empty($settings['col_bg_count']) ? intval($settings['col_bg_count']) : 3;
        echo '<div class="pxl-bg-col type-single">';
        for ($i = 0; $i < $count; $i++) {
            echo '<span class="pxl-anm-border"></span>';
        }
        echo '</div>';
    }
}


