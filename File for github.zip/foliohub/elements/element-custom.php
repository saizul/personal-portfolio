<?php

use Elementor\Element_Base;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Schemes\Color;
use Elementor\Schemes\Typography;
use Elementor\Utils;
use Elementor\Control_Media;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Repeater;
use Elementor\Includes\Elements\PXL_Container;

defined('ABSPATH') || die();

class Hub_Elementor_Custom_Controls
{

    public static $pxl_el_container_bg = array();

    public static function init()
    {

        add_action('elementor/frontend/before_render', [__CLASS__, 'before_section_render'], 1);

        //pxl sticky layout
        add_action('elementor/element/after_section_end', function ($element, $section_id) {

            if ($element->get_name() === 'container' && 'section_layout_additional_options' === $section_id) {

                $elementor_doc_selector = '.elementor';

                $element->start_controls_section(
                    'pxl_sticky_container_layout_section',
                    [
                        'label' => __('Pxl Option <span style="font-size: 1.5em; vertical-align:middle; margin-inline-start:0.35em;">📌<span>', 'foliohub'),
                        'tab' => Controls_Manager::TAB_LAYOUT,
                    ]
                );

                $element->add_control(
                    'pxl_section_bg_col',
                    [
                        'label' => esc_html__('Background Column', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'no' => esc_html__('No', 'foliohub'),
                        'yes' => esc_html__('Yes', 'foliohub'),
                        'return_value' => 'yes',
                        'default' => 'no',
                        'separator' => 'after',
                    ]
                );
                $element->add_control(
                    'col_bg_col',
                    [
                        'label' => esc_html__('Column', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'options' => [
                            'none' => esc_html__('No', 'foliohub'),
                            'column' => esc_html__('Double', 'foliohub'),
                            'single' => esc_html__('Single', 'foliohub'),
                        ],
                        'default' => 'none',
                        'prefix_class' => 'pxl-bg-',
                        'separator' => 'after',
                        'condition' => [
                            'pxl_section_bg_col' => 'yes',
                        ],
                    ]
                );
                $element->add_control(
                    'col_bg_count',
                    [
                        'label' => esc_html__('Number of Columns', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::NUMBER,
                        'min' => 1,
                        'max' => 10,
                        'step' => 1,
                        'default' => 3,
                        'condition' => [
                            'pxl_section_bg_col' => 'yes',
                        ],
                        'separator' => 'after',
                    ]
                );


                $element->add_control(
                    'pxl_section_border_animated',
                    [
                        'label' => esc_html__('Border Animated', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'label_on' => esc_html__('Yes', 'foliohub'),
                        'label_off' => esc_html__('No', 'foliohub'),
                        'return_value' => 'yes',
                        'default' => 'no',
                        'separator' => 'after',
                    ]
                );

                $element->add_control(
                    'col_fixed',
                    [
                        'label' => esc_html__('Column Fixed', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'description' => esc_html__('Only applies to the original container.', 'foliohub'),
                        'options' => array(
                            'none' => esc_html__('No', 'foliohub'),
                            'fixed' => esc_html__('Yes', 'foliohub'),
                        ),
                        'default' => 'none',
                        'prefix_class' => 'pxl-row-scroll-'
                    ]
                );

                $element->add_control(
                    'col_sticky',
                    [
                        'label' => esc_html__('Column Sticky', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'options' => array(
                            'none' => esc_html__('No', 'foliohub'),
                            'sticky' => esc_html__('Yes', 'foliohub'),
                        ),
                        'default' => 'none',
                        'prefix_class' => 'pxl-column-'
                    ]
                );

                $element->add_control(
                    'col_animation',
                    [
                        'label' => esc_html__('Scroll Animation', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'options' => array(
                            '' => esc_html__('No', 'foliohub'),
                            'scale' => esc_html__('Scale', 'foliohub'),
                            'opacity' => esc_html__('Opacity', 'foliohub'),
                        ),
                        'default' => '',
                        'prefix_class' => 'pxl-column-',
                    ]
                );

                $element->add_control(
                    'col_effect_flower',
                    [
                        'label' => esc_html__('Ripple Effect', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'options' => array(
                            'none' => esc_html__('No', 'foliohub'),
                            'hover-imge-ripple ripples' => esc_html__('Yes', 'foliohub'),
                        ),
                        'default' => 'none',
                        'prefix_class' => ''
                    ]
                );

                $element->add_control(
                    'col_scale_value',
                    [
                        'label' => esc_html__('Scale Value', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => '0.9',
                        'description' => esc_html__('Enter scale (e.g. 0.9 = 90%)', 'foliohub'),
                        'selectors' => [
                            '{{WRAPPER}}.pxl-column-scale' => '--scale-value: {{VALUE}};',
                        ],
                        'condition' => [
                            'col_animation' => 'scale'
                        ]
                    ]
                );


                $element->add_control(
                    'col_sticky_offset_top',
                    [
                        'label' => esc_html__('Sticky Offset Top', 'foliohub'),
                        'type' => 'text',
                        'description' => esc_html__('Enter number.', 'foliohub'),
                        'default' => '30',
                        'selectors' => [
                            '{{WRAPPER}}.pxl-column-sticky' => 'top: {{VALUE}}' . 'px',
                        ],
                        'condition' => [
                            'col_sticky' => 'sticky'
                        ]
                    ]
                );

                $element->add_control(
                    'full_content_with_space',
                    [
                        'label' => esc_html__('Full Content with space from?', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'prefix_class' => 'pxl-full-content-with-space-',
                        'options' => array(
                            'none' => esc_html__('None', 'foliohub'),
                            'start' => esc_html__('Start', 'foliohub'),
                            'end' => esc_html__('End', 'foliohub'),
                        ),
                        'default' => 'none',
                    ]
                );

                $element->add_control(
                    'pxl_container_width',
                    [
                        'label' => esc_html__('Container Width', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::NUMBER,
                        'default' => 1200,
                        'condition' => [
                            'full_content_with_space!' => 'none'
                        ]
                    ]
                );

                $element->end_controls_section();
            }

        }, 10, 2);

        // pxl dark layout
        add_action('elementor/element/after_section_end', function ($element, $section_id) {

            if ($element->get_name() === 'container' && 'section_layout_additional_options' === $section_id) {

                $elementor_doc_selector = '.elementor';

                $element->start_controls_section(
                    'pxl_dark_container_layout_section',
                    [
                        'label' => __('Background <span style="font-size: 1.5em; vertical-align:middle; margin-inline-start:0.35em;">🖼️<span>', 'foliohub'),
                        'tab' => Controls_Manager::TAB_LAYOUT,
                    ]
                );

                $element->add_control(
                    'pxl_parallax_bg_img',
                    [
                        'label' => esc_html__('Parallax Background Image', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'selectors' => [
                            '{{WRAPPER}} .pxl-section-bg-parallax' => 'background-image: url( {{URL}} );',
                        ],
                    ]
                );

                $element->add_responsive_control(
                    'pxl_parallax_bg_position',
                    [
                        'label' => esc_html__('Background Position', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'hide_in_inner' => true,
                        'options' => array(
                            '' => esc_html__('Default', 'foliohub'),
                            'center center' => esc_html__('Center Center', 'foliohub'),
                            'center left' => esc_html__('Center Left', 'foliohub'),
                            'center right' => esc_html__('Center Right', 'foliohub'),
                            'top center' => esc_html__('Top Center', 'foliohub'),
                            'top left' => esc_html__('Top Left', 'foliohub'),
                            'top right' => esc_html__('Top Right', 'foliohub'),
                            'bottom center' => esc_html__('Bottom Center', 'foliohub'),
                            'bottom left' => esc_html__('Bottom Left', 'foliohub'),
                            'bottom right' => esc_html__('Bottom Right', 'foliohub'),
                            'initial' => esc_html__('Custom', 'foliohub'),
                        ),
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}} .pxl-section-bg-parallax' => 'background-position: {{VALUE}};',
                        ],
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );

                $element->add_responsive_control(
                    'pxl_parallax_bg_pos_custom_x',
                    [
                        'label' => esc_html__('X Position', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SLIDER,
                        'hide_in_inner' => true,
                        'size_units' => ['px', 'em', '%', 'vw'],
                        'default' => [
                            'unit' => 'px',
                            'size' => 0,
                        ],
                        'range' => [
                            'px' => [
                                'min' => -800,
                                'max' => 800,
                            ],
                            'em' => [
                                'min' => -100,
                                'max' => 100,
                            ],
                            '%' => [
                                'min' => -100,
                                'max' => 100,
                            ],
                            'vw' => [
                                'min' => -100,
                                'max' => 100,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .pxl-section-bg-parallax' => 'background-position: {{SIZE}}{{UNIT}} {{pxl_parallax_bg_pos_custom_y.SIZE}}{{pxl_parallax_bg_pos_custom_y.UNIT}}',
                        ],
                        'condition' => [
                            'pxl_parallax_bg_position' => ['initial'],
                            'pxl_parallax_bg_img[url]!' => '',
                        ],
                    ]
                );
                $element->add_responsive_control(
                    'pxl_parallax_bg_pos_custom_y',
                    [
                        'label' => esc_html__('Y Position', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SLIDER,
                        'hide_in_inner' => true,
                        'size_units' => ['px', 'em', '%', 'vw'],
                        'default' => [
                            'unit' => 'px',
                            'size' => 0,
                        ],
                        'range' => [
                            'px' => [
                                'min' => -800,
                                'max' => 800,
                            ],
                            'em' => [
                                'min' => -100,
                                'max' => 100,
                            ],
                            '%' => [
                                'min' => -100,
                                'max' => 100,
                            ],
                            'vw' => [
                                'min' => -100,
                                'max' => 100,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .pxl-section-bg-parallax' => 'background-position: {{pxl_parallax_bg_pos_custom_x.SIZE}}{{pxl_parallax_bg_pos_custom_x.UNIT}} {{SIZE}}{{UNIT}}',
                        ],

                        'condition' => [
                            'pxl_parallax_bg_position' => ['initial'],
                            'pxl_parallax_bg_img[url]!' => '',
                        ],
                    ]
                );
                $element->add_responsive_control(
                    'pxl_parallax_bg_size',
                    [
                        'label' => esc_html__('Background Size', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'hide_in_inner' => true,
                        'options' => array(
                            '' => esc_html__('Default', 'foliohub'),
                            'auto' => esc_html__('Auto', 'foliohub'),
                            'cover' => esc_html__('Cover', 'foliohub'),
                            'contain' => esc_html__('Contain', 'foliohub'),
                            'initial' => esc_html__('Custom', 'foliohub'),
                        ),
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}} .pxl-section-bg-parallax' => 'background-size: {{VALUE}};',
                        ],
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_responsive_control(
                    'pxl_parallax_bg_size_custom',
                    [
                        'label' => esc_html__('Background Width', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SLIDER,
                        'hide_in_inner' => true,
                        'size_units' => ['px', 'em', '%', 'vw'],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 1000,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                            'vw' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                        'default' => [
                            'size' => 100,
                            'unit' => '%',
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .pxl-section-bg-parallax' => 'background-size: {{SIZE}}{{UNIT}} auto',
                        ],
                        'condition' => [
                            'pxl_parallax_bg_size' => ['initial'],
                            'pxl_parallax_bg_img[url]!' => '',
                        ],
                    ]
                );
                $element->add_control(
                    'pxl_parallax_pos_popover_toggle',
                    [
                        'label' => esc_html__('Parallax Background Position', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                        'label_off' => esc_html__('Default', 'foliohub'),
                        'label_on' => esc_html__('Custom', 'foliohub'),
                        'return_value' => 'yes',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->start_popover();
                $element->add_responsive_control(
                    'pxl_parallax_pos_left',
                    [
                        'label' => esc_html__('Left', 'foliohub') . ' (50px) px,%,vw,auto',
                        'type' => 'text',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}} .pxl-section-bg-parallax' => 'left: {{VALUE}}',
                        ],
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_responsive_control(
                    'pxl_parallax_pos_top',
                    [
                        'label' => esc_html__('Top', 'foliohub') . ' (50px) px,%,vw,auto',
                        'type' => 'text',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}} .pxl-section-bg-parallax' => 'top: {{VALUE}}',
                        ],
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_responsive_control(
                    'pxl_parallax_pos_right',
                    [
                        'label' => esc_html__('Right', 'foliohub') . ' (50px) px,%,vw,auto',
                        'type' => 'text',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}} .pxl-section-bg-parallax' => 'right: {{VALUE}}',
                        ],
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_responsive_control(
                    'pxl_parallax_pos_bottom',
                    [
                        'label' => esc_html__('Bottom', 'foliohub') . ' (50px) px,%,vw,auto',
                        'type' => 'text',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}} .pxl-section-bg-parallax' => 'bottom: {{VALUE}}',
                        ],
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->end_popover();

                $element->add_control(
                    'pxl_parallax_effect_popover_toggle',
                    [
                        'label' => esc_html__('Parallax Background Effect', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                        'label_off' => esc_html__('Default', 'foliohub'),
                        'label_on' => esc_html__('Custom', 'foliohub'),
                        'return_value' => 'yes',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->start_popover();
                $element->add_control(
                    'pxl_parallax_bg_img_effect_x',
                    [
                        'label' => esc_html__('TranslateX', 'foliohub') . ' (-80)',
                        'type' => 'text',
                        'default' => '',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_control(
                    'pxl_parallax_bg_img_effect_y',
                    [
                        'label' => esc_html__('TranslateY', 'foliohub') . ' (-80)',
                        'type' => 'text',
                        'default' => '',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_control(
                    'pxl_parallax_bg_img_effect_z',
                    [
                        'label' => esc_html__('TranslateZ', 'foliohub') . ' (-80)',
                        'type' => 'text',
                        'default' => '',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_control(
                    'pxl_parallax_bg_img_effect_rotate_x',
                    [
                        'label' => esc_html__('Rotate X', 'foliohub') . ' (30)',
                        'type' => 'text',
                        'default' => '',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_control(
                    'pxl_parallax_bg_img_effect_rotate_y',
                    [
                        'label' => esc_html__('Rotate Y', 'foliohub') . ' (30)',
                        'type' => 'text',
                        'default' => '',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_control(
                    'pxl_parallax_bg_img_effect_rotate_z',
                    [
                        'label' => esc_html__('Rotate Z', 'foliohub') . ' (30)',
                        'type' => 'text',
                        'default' => '',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_control(
                    'pxl_parallax_bg_img_effect_scale_x',
                    [
                        'label' => esc_html__('Scale X', 'foliohub') . ' (1.2)',
                        'type' => 'text',
                        'default' => '',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_control(
                    'pxl_parallax_bg_img_effect_scale_y',
                    [
                        'label' => esc_html__('Scale Y', 'foliohub') . ' (1.2)',
                        'type' => 'text',
                        'default' => '',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_control(
                    'pxl_parallax_bg_img_effect_scale_z',
                    [
                        'label' => esc_html__('Scale Z', 'foliohub') . ' (1.2)',
                        'type' => 'text',
                        'default' => '',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_control(
                    'pxl_parallax_bg_img_effect_scale',
                    [
                        'label' => esc_html__('Scale', 'foliohub') . ' (1.2)',
                        'type' => 'text',
                        'default' => '',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_control(
                    'pxl_parallax_bg_from_scroll_custom',
                    [
                        'label' => esc_html__('Scroll From (px)', 'foliohub') . ' (350) from offset top',
                        'type' => 'text',
                        'default' => '',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->end_popover();
                $element->add_control(
                    'pxl_parallax_bg_effect_other',
                    [
                        'label' => esc_html__('Background Effect Other', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'label_block' => true,
                        'options' => array(
                            '' => esc_html__('Default', 'foliohub'),
                            'none' => esc_html__('None', 'foliohub'),
                            'pinned-zoom-clipped' => esc_html__('Pinned Zoom Clipped', 'foliohub'),
                            'pinned-circle-zoom-clipped' => esc_html__('Pinned Circle Zoom Clipped', 'foliohub'),
                            'mask-parallax' => esc_html__('Mask Parallax ', 'foliohub'),
                            'mask-parallax light-content' => esc_html__('Mask Parallax - Light Content', 'foliohub'),
                        ),
                        'default' => '',
                        'frontend_available' => true,
                        'prefix_class' => 'pxl-bg-prx-effect-',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_control(
                    'pxl_parallax_bg_circle_zoom_bg_color',
                    [
                        'label' => esc_html__('Circle Zoom Clipped Mask Background Color', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'label_block' => true,
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .circle-zoom-mask-svg .mask-bg' => 'fill: {{VALUE}};'
                        ],
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => '',
                            'pxl_parallax_bg_effect_other' => 'pinned-circle-zoom-clipped'
                        ]
                    ]
                );
                $element->add_control(
                    'pxl_parallax_bg_circle_zoom_inner_bg_color',
                    [
                        'label' => esc_html__('Circle Zoom Inner Background Color', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'label_block' => true,
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .circle-zoom-mask-svg .circle-inner-layer' => 'fill: {{VALUE}};'
                        ],
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => '',
                            'pxl_parallax_bg_effect_other' => 'pinned-circle-zoom-clipped'
                        ]
                    ]
                );
                $element->add_group_control(
                    \Elementor\Group_Control_Css_Filter::get_type(),
                    [
                        'name' => 'pxl_section_parallax_img_css_filter',
                        'selector' => '{{WRAPPER}} .pxl-section-bg-parallax',
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );
                $element->add_responsive_control(
                    'pxl_section_parallax_opacity',
                    [
                        'label' => esc_html__('Parallax Opacity (0 - 100)', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SLIDER,
                        'size_units' => ['%'],
                        'range' => [
                            '%' => [
                                'min' => 1,
                                'max' => 100,
                            ]
                        ],
                        'default' => [
                            'unit' => '%'
                        ],
                        'laptop_default' => [
                            'unit' => '%',
                        ],
                        'tablet_extra_default' => [
                            'unit' => '%',
                        ],
                        'tablet_default' => [
                            'unit' => '%',
                        ],
                        'mobile_extra_default' => [
                            'unit' => '%',
                        ],
                        'mobile_default' => [
                            'unit' => '%',
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .pxl-section-bg-parallax' => 'opacity: {{SIZE}}{{UNIT}};',
                        ],
                        'condition' => [
                            'pxl_parallax_bg_img[url]!' => ''
                        ]
                    ]
                );

                $element->end_controls_section();
            }

        }, 10, 2);

        add_action('elementor/element/after_section_end', function ($element, $section_id) {

            if (
                $section_id === 'section_layout' ||
                $section_id === 'section_advanced' ||
                $section_id === '_section_style'
            ) {

                if ($element->get_controls('pxl_effect_container_layout_section')) {
                    return;
                }

                $element->start_controls_section(
                    'pxl_effect_container_layout_section',
                    [
                        'label' => __('Effect Images 🖊', 'foliohub'),
                        'tab' => Controls_Manager::TAB_ADVANCED,
                    ]
                );

                $element->add_control(
                    'pxl_widget_el_pos_popover_toggle',
                    [
                        'label' => esc_html__('Position', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                        'label_off' => esc_html__('Default', 'foliohub'),
                        'label_on' => esc_html__('Custom', 'foliohub'),
                        'return_value' => 'yes',
                    ]
                );
                $element->start_popover();
                $element->add_responsive_control(
                    'pxl_widget_el_position',
                    [
                        'label' => esc_html__('Position', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'options' => array(
                            '' => esc_html__('Default', 'foliohub'),
                            'absolute' => esc_html__('Absolute', 'foliohub'),
                            'relative' => esc_html__('Relative', 'foliohub'),
                            'fixed' => esc_html__('Fixed', 'foliohub'),
                        ),
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}}' => 'position: {{VALUE}};',
                        ],
                    ]
                );
                $element->add_responsive_control(
                    'pxl_widget_el_pos_left',
                    [
                        'label' => esc_html__('Left', 'foliohub') . ' (50px) px,%,vw,auto',
                        'type' => 'text',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}}' => 'left: {{VALUE}}',
                        ],
                        'condition' => [
                            'pxl_widget_el_position!' => ''
                        ]
                    ]
                );
                $element->add_responsive_control(
                    'pxl_widget_el_pos_top',
                    [
                        'label' => esc_html__('Top', 'foliohub') . ' (50px) px,%,vw,auto',
                        'type' => 'text',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}}' => 'top: {{VALUE}}',
                        ],
                        'condition' => [
                            'pxl_widget_el_position!' => ''
                        ]
                    ]
                );
                $element->add_responsive_control(
                    'pxl_widget_el_pos_right',
                    [
                        'label' => esc_html__('Right', 'foliohub') . ' (50px) px,%,vw,auto',
                        'type' => 'text',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}}' => 'right: {{VALUE}}',
                        ],
                        'condition' => [
                            'pxl_widget_el_position!' => ''
                        ]
                    ]
                );
                $element->add_responsive_control(
                    'pxl_widget_el_pos_bottom',
                    [
                        'label' => esc_html__('Bottom', 'foliohub') . ' (50px) px,%,vw,auto',
                        'type' => 'text',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}}' => 'bottom: {{VALUE}}',
                        ],
                        'condition' => [
                            'pxl_widget_el_position!' => ''
                        ]
                    ]
                );
                $element->end_popover();

                $element->add_control(
                    'pxl_widget_el_parallax_effect',
                    [
                        'label' => esc_html__('Pxl Parallax Effect', 'foliohub'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'options' => [
                            '' => esc_html__('None', 'foliohub'),
                            'wow PXLfadeInUp' => esc_html__('PXLfadeInUp', 'foliohub'),
                            'wow PXLZoom2' => esc_html__('PXLZoom', 'foliohub'),
                            'wow PXLfadeInUp2' => esc_html__('Mouse Move Scope Class (mouse-move-scope)', 'foliohub'),
                        ],
                        'label_block' => true,
                        'default' => '',
                        'prefix_class' => ''
                    ]
                );
                $element->end_controls_section();
            }
        }, 10, 2);

        add_action('elementor/element/after_add_attributes', 'foliohub_custom_el_attributes', 10, 1);

        add_filter('pxl_element_container/before-render', function ($html, $settings) {
            if (isset($settings['pxl_section_border_animated']) && $settings['pxl_section_border_animated'] == 'yes') {
                $breakpoints = ['laptop', 'tablet_extra', 'tablet', 'mobile_extra', 'mobile'];

                $unit = $settings['border_width']['unit'];
                $border_num = 0;

                $bt_width = $settings['border_width']['top'];
                $br_width = $settings['border_width']['right'];
                $bb_width = $settings['border_width']['bottom'];
                $bl_width = $settings['border_width']['left'];

                foreach ($breakpoints as $v) {
                    if (isset($settings['border_width_' . $v]['top']) && (int) $settings['border_width_' . $v]['top'] > 0)
                        $bt_width = $settings['border_width_' . $v]['top'];
                    if (isset($settings['border_width_' . $v]['right']) && (int) $settings['border_width_' . $v]['right'] > 0)
                        $br_width = $settings['border_width_' . $v]['right'];
                    if (isset($settings['border_width_' . $v]['bottom']) && (int) $settings['border_width_' . $v]['bottom'] > 0)
                        $bb_width = $settings['border_width_' . $v]['bottom'];
                    if (isset($settings['border_width_' . $v]['left']) && (int) $settings['border_width_' . $v]['left'] > 0)
                        $bl_width = $settings['border_width_' . $v]['left'];
                }

                $bd_top_style = 'style="--bd-width: ' . $bt_width . $unit . ' 0 0 0; border-style: ' . $settings['border_border'] . '; border-color: ' . $settings['border_color'] . ';"';
                $bd_right_style = 'style="--bd-width: 0 ' . $br_width . $unit . ' 0 0; border-style: ' . $settings['border_border'] . '; border-color: ' . $settings['border_color'] . ';"';
                $bd_bottom_style = 'style="--bd-width: 0 0 ' . $bb_width . $unit . ' 0; border-style: ' . $settings['border_border'] . '; border-color: ' . $settings['border_color'] . ';"';
                $bd_left_style = 'style="--bd-width: 0 0 0 ' . $bl_width . $unit . '; border-style: ' . $settings['border_border'] . '; border-color: ' . $settings['border_color'] . ';"';

                $bd_top_w = $bd_right_w = $bd_bottom_w = $bd_left_w = '';

                foreach (['top', 'right', 'bottom', 'left'] as $side) {
                    $var_name = 'bd_' . $side . '_w';
                    if (isset($settings['border_width'][$side])) {
                        if ($settings['border_width'][$side] == '0') {
                            $$var_name .= ' bw-no';
                        } elseif ((int) $settings['border_width'][$side] > 0) {
                            $$var_name .= ' bw-yes';
                        }
                    }
                }

                foreach ($breakpoints as $v) {
                    foreach (['top', 'right', 'bottom', 'left'] as $side) {
                        $var_name = 'bd_' . $side . '_w';
                        if (isset($settings['border_width_' . $v][$side])) {
                            if ($settings['border_width_' . $v][$side] == '0') {
                                $$var_name .= ' bw-' . $v . '-no';
                            } elseif ((int) $settings['border_width_' . $v][$side] > 0) {
                                $$var_name .= ' bw-' . $v . '-yes';
                            }
                        }
                    }
                }

                if ((int) $settings['border_width']['top'] > 0)
                    $border_num++;
                if ((int) $settings['border_width']['right'] > 0)
                    $border_num++;
                if ((int) $settings['border_width']['bottom'] > 0)
                    $border_num++;
                if ((int) $settings['border_width']['left'] > 0)
                    $border_num++;

                $html .= '<div class="pxl-border-animated num-' . $border_num . '">
        <div class="pxl-border-anm bt w-100 ' . $bd_top_w . '" ' . $bd_top_style . '></div>
        <div class="pxl-border-anm br h-100 ' . $bd_right_w . '" ' . $bd_right_style . '></div>
        <div class="pxl-border-anm bb w-100 ' . $bd_bottom_w . '" ' . $bd_bottom_style . '></div>
        <div class="pxl-border-anm bl h-100 ' . $bd_left_w . '" ' . $bd_left_style . '></div>
        </div>';
            }

            return $html;
        }, 10, 2);

        add_filter('pxl_element_container/before-render', function ($html, $settings) {
            if (!empty($settings['pxl_parallax_bg_img']['url'])) {
                $effects = [];
                if (!empty($settings['pxl_parallax_bg_img_effect_x'])) {
                    $effects['x'] = (int) $settings['pxl_parallax_bg_img_effect_x'];
                }
                if (!empty($settings['pxl_parallax_bg_img_effect_y'])) {
                    $effects['y'] = (int) $settings['pxl_parallax_bg_img_effect_y'];
                }
                if (!empty($settings['pxl_parallax_bg_img_effect_z'])) {
                    $effects['z'] = (int) $settings['pxl_parallax_bg_img_effect_z'];
                }
                if (!empty($settings['pxl_parallax_bg_img_effect_rotate_x'])) {
                    $effects['rotateX'] = (float) $settings['pxl_parallax_bg_img_effect_rotate_x'];
                }
                if (!empty($settings['pxl_parallax_bg_img_effect_rotate_y'])) {
                    $effects['rotateY'] = (float) $settings['pxl_parallax_bg_img_effect_rotate_y'];
                }
                if (!empty($settings['pxl_parallax_bg_img_effect_rotate_z'])) {
                    $effects['rotateZ'] = (float) $settings['pxl_parallax_bg_img_effect_rotate_z'];
                }
                if (!empty($settings['pxl_parallax_bg_img_effect_scale'])) {
                    $effects['scale'] = (float) $settings['pxl_parallax_bg_img_effect_scale'];
                }
                if (!empty($settings['pxl_parallax_bg_img_effect_scale_x'])) {
                    $effects['scaleX'] = (float) $settings['pxl_parallax_bg_img_effect_scale_x'];
                }
                if (!empty($settings['pxl_parallax_bg_img_effect_scale_y'])) {
                    $effects['scaleY'] = (float) $settings['pxl_parallax_bg_img_effect_scale_y'];
                }
                if (!empty($settings['pxl_parallax_bg_from_scroll_custom'])) {
                    $effects['from-scroll-custom'] = (int) $settings['pxl_parallax_bg_from_scroll_custom'];
                }

                $data_parallax = json_encode($effects);
                $pll_ccls = 'df-prl';
                if (!empty($settings['pxl_parallax_bg_effect_other'])) {
                    if ($settings['pxl_parallax_bg_effect_other'] == 'pinned-zoom-clipped') {
                        $html .= '<div class="clipped-bg-pinned"><div class="clipped-bg">';
                    }
                    if ($settings['pxl_parallax_bg_effect_other'] == 'pinned-circle-zoom-clipped') {
                        $html .= '<div class="clipped-bg-circle-pinned">';
                    }
                    if ($settings['pxl_parallax_bg_effect_other'] == 'mask-parallax' || $settings['pxl_parallax_bg_effect_other'] == 'mask-parallax light-content') {
                        $html .= '<div class="mask-parallax">';
                        $pll_ccls = 'mask-prl';
                    }
                }
                $html .= '<div class="pxl-section-bg-parallax ' . $settings['pxl_parallax_bg_effect_other'] . '" data-parallax="' . esc_attr($data_parallax) . '"></div>';
                if (!empty($settings['pxl_parallax_bg_effect_other'])) {
                    if ($settings['pxl_parallax_bg_effect_other'] == 'pinned-zoom-clipped') {
                        $html .= '</div></div>';
                    }
                    if ($settings['pxl_parallax_bg_effect_other'] == 'pinned-circle-zoom-clipped') {
                        $html .= '<svg class="circle-zoom-mask-svg">
                <defs>
                <mask id="circle-zoom-mask">
                <rect width="100%" height="100%" fill="white"></rect>
                <circle class="circle-zoom" cx="50%" cy="50%" r="60"></circle>
                </mask>
                </defs>
                <rect class="circle-inner-layer" width="100%" height="100%" fill="white"></rect>
                <rect class="mask-bg" width="100%" height="100%" fill="#c4b5a4" mask="url(#circle-zoom-mask)"></rect>
                </svg>';
                        $html .= '</div>';
                    }
                    if ($settings['pxl_parallax_bg_effect_other'] == 'mask-parallax' || $settings['pxl_parallax_bg_effect_other'] == 'mask-parallax light-content') {
                        $html .= '</div>';
                    }

                }
            }

            if (isset($settings['row_effect_images']) && !empty($settings['row_effect_images']) && count($settings['row_effect_images'])):
                $html .= '<div class="pxl-section-effect-images">';
                foreach ($settings['row_effect_images'] as $key => $value):
                    $item_image = isset($value['item_image']) ? $value['item_image'] : '';
                    $effect_image = isset($value['effect_image']) ? $value['effect_image'] : '';
                    $image_display = isset($value['image_display']) ? $value['image_display'] : '';
                    $image_display_md = isset($value['image_display_md']) ? $value['image_display_md'] : '';
                    $image_display_sm = isset($value['image_display_sm']) ? $value['image_display_sm'] : '';
                    $parallax_scroll_type = isset($value['parallax_scroll_type']) ? $value['parallax_scroll_type'] : '';
                    $parallax_scroll_value = isset($value['parallax_scroll_value']) ? $value['parallax_scroll_value'] : '';
                    $hidde_class = '';
                    if ($image_display !== 'false') {
                        $hidde_class = 'pxl-hide-sr-lg';
                    }
                    $hidde_class_md = '';
                    if ($image_display_md !== 'false') {
                        $hidde_class_md = 'pxl-hide-sr-md';
                    }
                    $hidde_class_sm = '';
                    if ($image_display_sm !== 'false') {
                        $hidde_class_sm = 'pxl-hide-sr-sm';
                    }
                    $effects = [];
                    if ($parallax_scroll_type == 'y' && !empty($parallax_scroll_value)) {
                        $effects['y'] = (int) $parallax_scroll_value;
                    }
                    if ($parallax_scroll_type == 'x' && !empty($parallax_scroll_value)) {
                        $effects['x'] = (int) $parallax_scroll_value;
                    }
                    if ($parallax_scroll_type == 'z' && !empty($parallax_scroll_value)) {
                        $effects['z'] = (int) $parallax_scroll_value;
                    }
                    $data_parallax = json_encode($effects);

                    $parallax_hover_value = isset($value['parallax_hover_value']) ? $value['parallax_hover_value'] : '';
                    $img_alt = '';

                    if (!empty($item_image['id'])) {
                        $img_alt = get_post_meta($item_image['id'], '_wp_attachment_image_alt', true);

                        if (empty($img_alt)) {
                            $img_alt = get_the_title($item_image['id']);
                        }
                    }
                    $html .= '<img
                        data-parallax-value="' . esc_attr($parallax_hover_value) . '"
                        data-parallax="' . esc_attr($data_parallax) . '"
                        class="pxl-item--image elementor-repeater-item-' . esc_attr($value['_id']) . ' ' . esc_attr($effect_image) . ' ' . esc_attr($hidde_class) . ' ' . esc_attr($hidde_class_md) . ' ' . esc_attr($hidde_class_sm) . '"
                        src="' . esc_url($item_image['url']) . '"
                        alt="' . esc_attr($img_alt) . '"
                    />';
                endforeach;
                $html .= '</div>';
            endif;

            return $html;
        }, 10, 2);

        add_action('elementor/editor/after_enqueue_scripts', function () {
            ?>
            <script>
                jQuery(document).ready(function ($) {
                    // Chờ Elementor load xong
                    setInterval(function () {
                        $('.elementor-editor-container .elementor-editor-element-settings').each(function () {
                            // Kiểm tra nếu nút đã tồn tại, tránh thêm nhiều lần
                            if ($(this).find('.elementor-editor-element-play').length === 0) {
                                // Thêm nút vào danh sách
                                $(this).append(`
                            <li class="elementor-editor-element-setting elementor-editor-element-play" 
                                title="Play children inview animations" 
                                aria-label="Play children inview animations">
                                <i class="eicon-play"></i>
                            </li>
                        `);
                            }
                        });
                    }, 1000);

                    // Xử lý sự kiện khi click vào nút
                    $(document).on('click', '.elementor-editor-element-play', function () {
                        var $widget = $(this).closest('.elementor-editor-element');

                        // Reset animation
                        $widget.find('.wow').removeClass('animated').css('visibility', 'hidden');

                        setTimeout(function () {
                            $widget.find('.wow').addClass('animated').css('visibility', 'visible');
                            new WOW().init(); // Restart WOW.js
                        }, 100);
                    });
                });
            </script>
            <?php
        });


        function foliohub_custom_el_attributes(Element_Base $el)
        {
            $settings = $el->get_settings();

            $pxl_container_width = !empty($settings['pxl_container_width']) ? (int) $settings['pxl_container_width'] : 1200;

            if (!empty($settings['stretch_section']) && $settings['stretch_section'] === 'section-stretched') {
                $pxl_container_width = max(0, $pxl_container_width - 30);
            }

            $pxl_container_width .= 'px';

            if (!empty($settings['full_content_with_space'])) {
                if ($settings['full_content_with_space'] === 'start') {
                    $el->add_render_attribute('_wrapper', 'style', 'padding-left: max(15px, calc((100% - ' . $pxl_container_width . ') / 2));');
                } elseif ($settings['full_content_with_space'] === 'end') {
                    $el->add_render_attribute('_wrapper', 'style', 'padding-right: max(15px, calc((100% - ' . $pxl_container_width . ') / 2));');
                }
            }

            if ($el->get_name() === 'section' && !empty($settings['pxl_header_type'])) {
                $el->add_render_attribute('_wrapper', 'class', 'pxl-header-' . $settings['pxl_header_type']);
            }

            if (isset($settings['pxl_section_border_animated']) && $settings['pxl_section_border_animated'] == 'yes') {
                $el->add_render_attribute('_wrapper', 'class', 'pxl-border-section-anm');
            }
        }


        // Custom css
        add_action('elementor/element/parse_css', function ($post_css, $element) {
            if ($post_css instanceof \Elementor\Core\DynamicTags\Dynamic_CSS) {
                return;
            }

            $element_settings = $element->get_settings();

            if (empty($element_settings['pxl_custom_css'])) {
                return;
            }

            $css = trim($element_settings['pxl_custom_css']);

            if (empty($css)) {
                return;
            }

            $css = str_replace('selector', $post_css->get_element_unique_selector($element), $css);

            $post_css->get_stylesheet()->add_raw_css($css);

        }, 10, 2);

        add_action('elementor/element/after_section_end', function ($element, $section_id) {
            if (
                $section_id === 'section_layout' ||
                $section_id === 'section_advanced' ||
                $section_id === '_section_style'
            ) {

                if ($element->get_controls('pxl_custom_css_section')) {
                    return;
                }

                $element->start_controls_section(
                    'pxl_custom_css_section',
                    [
                        'label' => __('Foliohub Custom CSS 🖊', 'foliohub'),
                        'tab' => \Elementor\Controls_Manager::TAB_ADVANCED,
                    ]
                );

                $element->add_control(
                    'pxl_custom_css',
                    [
                        'type' => \Elementor\Controls_Manager::CODE,
                        'language' => 'css',
                        'render_type' => 'template',
                        'raw' => true,
                        'show_label' => false,
                        'separator' => 'none',
                        'description' => __('Add your custom CSS here. Use "selector" to target this element.', 'foliohub'),
                    ]
                );

                $element->end_controls_section();
            }
        }, 10, 3);

        add_action('elementor/widget/render_content', 'pxl_render_element_custom_css', 10, 2);
        add_action('elementor/section/render_content', 'pxl_render_element_custom_css', 10, 2);
        add_action('elementor/container/render_content', 'pxl_render_element_custom_css', 10, 2);

        function pxl_render_element_custom_css($content, $element)
        {
            $settings = $element->get_settings();

            if (empty($settings['pxl_custom_css'])) {
                return $content;
            }

            $css = trim($settings['pxl_custom_css']);

            if (empty($css)) {
                return $content;
            }

            $element_id = $element->get_id();
            $css = str_replace('selector', '.elementor-element-' . $element_id, $css);

            $style_tag = '<style id="pxl-custom-css-' . $element_id . '">' . $css . '</style>';

            return $style_tag . $content;
        }

        add_action('elementor/frontend/before_render', function ($element) {
            $settings = $element->get_settings();

            if (!empty($settings['pxl_custom_css'])) {
                $css = trim($settings['pxl_custom_css']);

                if (!empty($css)) {
                    $element_id = $element->get_id();
                    $css = str_replace('selector', '.elementor-element-' . $element_id, $css);

                    add_action('wp_head', function () use ($element_id, $css) {
                        echo '<style id="pxl-custom-css-' . $element_id . '">' . $css . '</style>';
                    }, 999);

                    if (\Elementor\Plugin::$instance->editor->is_edit_mode()) {
                        ?>
                        <style id="pxl-editor-css-<?php echo pxl_print_html($element_id); ?>">
                            <?php echo pxl_print_html($css); ?>
                        </style>
                        <?php
                    }
                }
            }
        });
    }

    public static function before_section_render(Element_Base $element)
    {
        $settings = $element->get_settings();

        if (!empty($settings['pxl_section_color_scheme'])) {
            $element->add_render_attribute('_wrapper', [
                'data-pxl-color-scheme' => $settings['pxl_section_color_scheme'],
            ]);
        }

        if (!empty($settings['pxl_sticky_show']) && $settings['pxl_sticky_show'] === 'yes') {
            $element->add_render_attribute('_wrapper', [
                'data-pxl-show-on-sticky' => 'true',
            ]);
            if ($element->get_name() !== 'container') {
                $element->add_render_attribute('_wrapper', 'class', 'hidden pxl-sticky:block');
            }
        }

        if (!empty($settings['pxl_sticky_hide']) && $settings['pxl_sticky_hide'] === 'yes') {
            $element->add_render_attribute('_wrapper', [
                'data-pxl-hide-on-sticky' => 'true',
            ]);
            if ($element->get_name() !== 'container') {
                $element->add_render_attribute('_wrapper', 'class', 'pxl-sticky:hidden');
            }
        }

        if (!empty($settings['pxl_section_border_animated']) && $settings['pxl_section_border_animated'] === 'yes') {
            $element->add_render_attribute('_wrapper', 'class', 'pxl-border-section-anm');
        }
    }




}

Hub_Elementor_Custom_Controls::init();
