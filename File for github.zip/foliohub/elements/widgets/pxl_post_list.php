<?php
$pt_supports = ['service','portfolio'];
use Elementor\Controls_Manager;
pxl_add_custom_widget(
    array(
        'name' => 'pxl_post_list',
        'title' => esc_html__('Pxl Post List', 'foliohub'),
        'icon' => 'eicon-post-list',
        'categories' => array('pxltheme-core'),
        'scripts' => [
            'pxl-post-grid',
        ],
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'layout_section',
                    'label' => esc_html__('Layout', 'foliohub'),
                    'tab' => 'layout',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'post_type',
                                'label' => esc_html__('Select Post Type', 'foliohub'),
                                'type' => 'select',
                                'multiple' => true,
                                'options' => foliohub_get_post_type_options($pt_supports),
                                'default' => 'service'
                            )
                        ),
                        foliohub_get_post_list_layout($pt_supports)
                    ),
                ),
                array(
                    'name' => 'source_section',
                    'label' => esc_html__('Source', 'foliohub'),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'select_post_by',
                                'label' => esc_html__('Select posts by', 'foliohub'),
                                'type' => 'select',
                                'multiple' => true,
                                'options' => [
                                    'term_selected' => esc_html__('Terms selected', 'foliohub'),
                                    'post_selected' => esc_html__('Posts selected ', 'foliohub'),
                                ],
                                'default' => 'term_selected'
                            )
                        ),
                        foliohub_get_term_by_post_type($pt_supports, ['custom_condition' => ['select_post_by' => 'term_selected']]),
                        foliohub_get_ids_by_post_type($pt_supports, ['custom_condition' => ['select_post_by' => 'post_selected']]),
                        foliohub_get_ids_unselected_by_post_type($pt_supports, ['custom_condition' => ['select_post_by' => 'term_selected']]),
                        array(
                            array(
                                'name' => 'orderby',
                                'label' => esc_html__('Order By', 'foliohub'),
                                'type' => \Elementor\Controls_Manager::SELECT,
                                'default' => 'date',
                                'options' => [
                                    'date' => esc_html__('Date', 'foliohub'),
                                    'ID' => esc_html__('ID', 'foliohub'),
                                    'author' => esc_html__('Author', 'foliohub'),
                                    'title' => esc_html__('Title', 'foliohub'),
                                    'rand' => esc_html__('Random', 'foliohub'),
                                ],
                            ),
                            array(
                                'name' => 'order',
                                'label' => esc_html__('Sort Order', 'foliohub'),
                                'type' => \Elementor\Controls_Manager::SELECT,
                                'default' => 'desc',
                                'options' => [
                                    'desc' => esc_html__('Descending', 'foliohub'),
                                    'asc' => esc_html__('Ascending', 'foliohub'),
                                ],
                            ),
                            array(
                                'name' => 'limit',
                                'label' => esc_html__('Total items', 'foliohub'),
                                'type' => \Elementor\Controls_Manager::NUMBER,
                                'default' => '6',
                            ),
                        )
                    ),
                ),
                array(
                    'name' => 'general_section',
                    'label' => esc_html__('General Settings', 'foliohub'),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'show_toolbar',
                                'label' => esc_html__('Show Toolbar', 'foliohub'),
                                'type' => \Elementor\Controls_Manager::SELECT,
                                'default' => 'hide',
                                'options' => [
                                    'show' => esc_html__('Show', 'foliohub'),
                                    'hide' => esc_html__('Hide', 'foliohub')
                                ],
                            ),
                            array(
                                'name' => 'scroll_effect',
                                'label' => esc_html__('Scroll Effects', 'foliohub'),
                                'type' => \Elementor\Controls_Manager::SELECT,
                                'options' => [
                                    'none' => 'None',
                                    'blinds_staggered' => 'Blinds Staggered',
                                    'zoom_in' => 'Zoom In',
                                ],
                                'default' => 'none',
                            ),
                            array(
                                'name' => 'img_size',
                                'label' => esc_html__('Image Size', 'foliohub'),
                                'type' => \Elementor\Controls_Manager::TEXT,
                                'description' => esc_html__('Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Default: full).', 'foliohub')
                            ),
                            array(
                                'name' => 'pagination_type',
                                'label' => esc_html__('Pagination Type', 'foliohub'),
                                'type' => \Elementor\Controls_Manager::SELECT,
                                'default' => 'false',
                                'options' => [
                                    'pagination' => esc_html__('Pagination', 'foliohub'),
                                    'loadmore' => esc_html__('Loadmore', 'foliohub'),
                                    'false' => esc_html__('Disable', 'foliohub'),
                                ],
                            ),
                            array(
                                'name' => 'loadmore_text',
                                'label' => esc_html__('Load More text', 'foliohub'),
                                'type' => \Elementor\Controls_Manager::TEXT,
                                'default' => esc_html__('Load More', 'foliohub'),
                                'condition' => [
                                    'pagination_type' => 'loadmore'
                                ]
                            ),
                            array(
                                'name' => 'pagination_alignment',
                                'label' => esc_html__('Pagination Alignment', 'foliohub'),
                                'type' => 'choose',
                                'control_type' => 'responsive',
                                'options' => [
                                    'start' => [
                                        'title' => esc_html__('Start', 'foliohub'),
                                        'icon' => 'eicon-text-align-left',
                                    ],
                                    'center' => [
                                        'title' => esc_html__('Center', 'foliohub'),
                                        'icon' => 'eicon-text-align-center',
                                    ],
                                    'end' => [
                                        'title' => esc_html__('End', 'foliohub'),
                                        'icon' => 'eicon-text-align-right',
                                    ]
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid-pagination, {{WRAPPER}} .pxl-load-more' => 'justify-content: {{VALUE}};'
                                ],
                                'default' => 'start',
                                'condition' => [
                                    'pagination_type' => ['pagination', 'loadmore'],
                                ],
                            ),
                        ),
                    )
                ),
                array(
                    'name' => 'display_post_section',
                    'label' => esc_html__('Display Options', 'foliohub'),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array(
                        array(
                            'name' => 'post_date',
                            'label' => esc_html__('Show Date', 'foliohub'),
                            'condition' => ['post_type' => 'post', 'layout_post' => 'post-list-1'],
                            'type' => \Elementor\Controls_Manager::SWITCHER,
                            'default' => 'true',
                        ),
                        array(
                            'name' => 'post_author',
                            'label' => esc_html__('Show Author', 'foliohub'),
                            'condition' => ['post_type' => 'post', 'layout_post' => 'post-list-1'],
                            'type' => \Elementor\Controls_Manager::SWITCHER,
                            'default' => 'true',
                        ),
                        array(
                            'name' => 'post_category',
                            'label' => esc_html__('Show Category', 'foliohub'),
                            'conditions' => [
                                'relation' => 'or',
                                'terms' => [
                                    [
                                        'terms' => [
                                            ['name' => 'post_type', 'operator' => '==', 'value' => 'post'],
                                            ['name' => 'layout_post', 'operator' => 'in', 'value' => ['post-list-1']]
                                        ]
                                    ],
                                ],
                            ],
                            'type' => \Elementor\Controls_Manager::SWITCHER,
                            'default' => 'false',
                        ),
                        array(
                            'name' => 'post_comment',
                            'label' => esc_html__('Show Comment', 'foliohub'),
                            'type' => \Elementor\Controls_Manager::SWITCHER,
                            'default' => 'true',
                            'condition' => ['post_type' => 'post', 'layout_post' => 'post-list-1'],
                        ),
                        array(
                            'name' => 'post_excerpt',
                            'label' => esc_html__('Show Excerpt', 'foliohub'),
                            'type' => \Elementor\Controls_Manager::SWITCHER,
                            'default' => 'true',
                        ),
                        array(
                            'name' => 'post_num_words',
                            'label' => esc_html__('Number of Words', 'foliohub'),
                            'type' => \Elementor\Controls_Manager::NUMBER,
                            'condition' => [
                                'post_excerpt' => 'true',
                            ],
                        ),
                        array(
                            'name' => 'post_readmore',
                            'label' => esc_html__('Show Readmore', 'foliohub'),
                            'type' => \Elementor\Controls_Manager::SWITCHER,
                            'default' => 'true',
                        ),
                        array(
                            'name' => 'post_readmore_text',
                            'label' => esc_html__('Button Text', 'foliohub'),
                            'type' => \Elementor\Controls_Manager::TEXT,
                            'condition' => [
                                'post_readmore' => 'true',
                            ],
                        ),
                    ),
                ),
                foliohub_widget_animation_settings(),
            ),
        ),
    ),
    foliohub_get_class_widget_path()
);