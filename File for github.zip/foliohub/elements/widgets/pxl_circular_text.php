<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_circular_text',
        'title' => esc_html__('Case Circular Text', 'foliohub' ),
        'icon' => 'eicon-animation-text',
        'categories' => array('pxltheme-core'),
        'scripts' => [
            'gsap',
            'circular-text',
            'scroll-trigger',
            'circletype',
        ],
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_circular_text_content',
                    'label' => esc_html__('Circular Text', 'foliohub' ),
                    'tab' => 'content',
                    'controls' => array(
                        array(
                            'name' => 'text',
                            'label' => esc_html__('Text', 'foliohub' ),
                            'type' => 'textarea',
                            'rows' => 2,
                            'default' => esc_html__('foliohub AGENCY . CREATIVE DESIGN AGENCY .', 'foliohub'),
                        ),
                        array(
                            'name' => 'pxl_icon',
                            'label' => esc_html__('Icon', 'foliohub' ),
                            'type' => \Elementor\Controls_Manager::ICONS,
                            'fa4compatibility' => 'icon',
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_circular_text_style',
                    'label' => esc_html__('Circular Text', 'foliohub' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name'    => 'background_type',
                            'label'   => esc_html__('Background Type', 'foliohub'),
                            'type'    => \Elementor\Controls_Manager::CHOOSE,
                            'options' => array(
                                'classic'  => array(
                                    'title' => esc_html__('Color', 'foliohub'),
                                    'icon'  => 'eicon-paint-brush',
                                ),
                                'gradient' => array(
                                    'title' => esc_html__('Gradient', 'foliohub'),
                                    'icon'  => 'eicon-background',
                                ),
                            ),
                            'default' => 'classic',
                            'toggle'  => false,
                        ),
                        array(
                            'name'      => 'bg_color',
                            'label'     => esc_html__('Box Color', 'foliohub'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'condition' => array(
                                'background_type' => 'classic',
                            ),
                            'selectors' => array(
                                '{{WRAPPER}} .pxl-circular-text-wrapper' => 'background-color: {{VALUE}};',
                            ),
                        ),
                        array(
                            'name'         => 'btn_gradient',
                            'label'        => esc_html__('Gradient Background', 'foliohub'),
                            'type'         => \Elementor\Group_Control_Background::get_type(),
                            'control_type' => 'group',
                            'types'        => array('gradient'),
                            'selector'     => '{{WRAPPER}} .pxl-circular-text-wrapper',
                            'condition'    => array(
                                'background_type' => 'gradient',
                            ),
                        ),
                        array(
                            'name' => 'padding',
                            'label' => esc_html__( 'Box Padding', 'foliohub' ),
                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                            'control_type' => 'responsive',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-circular-text-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'bg_text_color',
                            'label' => esc_html__('Box Icon Color', 'foliohub' ),
                            'separator' => 'before',
                            'type' => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-item' => 'background-color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'box_text_padding',
                            'label' => esc_html__( 'Box Text Padding', 'foliohub' ),
                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                            'control_type' => 'responsive',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'spin_text',
                            'label' => esc_html__('Spin', 'foliohub' ),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'default' => '0',
                            'options' => [
                                '0'    => esc_html__('None', 'foliohub'),
                                '360' => esc_html__('CW', 'foliohub'),
                                '-360' => esc_html__('CCW', 'foliohub'),
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-item div' => '--pxl-rotate: {{VALUE}}deg;',
                            ],
                            'default' => '0',
                        ),
                        [
                            'name' => 'anim_duration',
                            'label' => esc_html__('Animation Duration', 'foliohub'),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'size_units' => ['ms', 's'],
                            'range' => [
                                'ms' => [
                                    'min' => 0,
                                    'max' => 100000,
                                    'step' => 50,
                                ],
                                's' => [
                                    'min' => 0,
                                    'max' => 100,
                                    'step' => 0.05,
                                ],
                            ],
                            'default' => [
                                'size' => 15000,
                                'unit' => 'ms',
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-item div' => 'animation-duration: {{SIZE}}{{UNIT}}; --webkit-animation-duration: {{SIZE}}{{UNIT}};',
                            ],
                        ],
                        array(
                            'name' => 'circular_text_control',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'circular_text',
                                    'label' => esc_html__('Text', 'foliohub' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'text_color',
                                            'label' => esc_html__('Text Color', 'foliohub' ),
                                            'type' => \Elementor\Controls_Manager::COLOR,
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-item' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'text_typography',
                                            'type' => \Elementor\Group_Control_Typography::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-item',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'circular_text_icon',
                                    'label' => esc_html__('Icon', 'foliohub' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'img_size',
                                            'label' => esc_html__('Image Size', 'foliohub' ),
                                            'type' => \Elementor\Controls_Manager::TEXT,
                                            'description' => esc_html__('Ex: "thumbnail", "medium", "large", "full"...Alternatively enter size in pixels. Ex: 200x100 - Width x Height.', 'foliohub'),
                                        ),
                                        array(
                                            'name' => 'box_icon_color',
                                            'label' => esc_html__('Box Color', 'foliohub' ),
                                            'type' => \Elementor\Controls_Manager::COLOR,
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon' => 'background-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'svg_color',
                                            'label' => esc_html__('Icon Color', 'foliohub' ),
                                            'type' => \Elementor\Controls_Manager::COLOR,
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'img_w',
                                            'label' => esc_html__('Width', 'foliohub'),
                                            'type' => \Elementor\Controls_Manager::SLIDER,
                                            'size_units' => ['px', '%', 'custom'],
                                            'control_type' => 'responsive',
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1000,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon img, {{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon svg' => 'width: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'img_h',
                                            'label' => esc_html__('Height', 'foliohub'),
                                            'type' => \Elementor\Controls_Manager::SLIDER,
                                            'size_units' => ['px', '%', 'custom'],
                                            'control_type' => 'responsive',
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1000,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon img, {{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon svg' => 'height: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_box_sz',
                                            'label' => esc_html__('Box Size', 'foliohub'),
                                            'type' => \Elementor\Controls_Manager::SLIDER,
                                            'size_units' => ['px', '%', 'custom'],
                                            'control_type' => 'responsive',
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1000,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),

                                        array(
                                            'name' => 'box_icon_padding',
                                            'label' => esc_html__( 'Box Padding', 'foliohub' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
);