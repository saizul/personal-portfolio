(function ($) {
    var pxl_widget_counter_handler = function ($scope, $) {
        setTimeout(function () {

            // ===== Counter thường (numerator)
            elementorFrontend.waypoint($scope.find('.pxl-counter--value:not(.effect-slide)'), function () {
                var $number = $(this),
                    data = $number.data();

                var decimalDigits = data.toValue.toString().match(/\.(.*)/);
                if (decimalDigits) {
                    data.rounding = decimalDigits[1].length;
                }

                // --- GỌI NUMERATOR (JS GỐC)
                $number.numerator(data);

                // --- THÊM HIỆU ỨNG CHO .pxl-counter1
                var $counter = $number.closest('.pxl-counter1, .pxl-counter2');

                if ($counter.length) {
                    var $inner = $counter.find('.pxl-counter--inner');
                    var $bg = $inner.find('.pxl-data-background');

                    var start = parseFloat(data.startnumber || 0);
                    var end = parseFloat(data.endnumber || data.toValue || 100);
                    var duration = parseInt(data.duration || 2000);
                    var startTime = null;
                    $inner.css({ position: 'relative', overflow: 'hidden' });
                    $bg.css({
                        position: 'absolute',
                        bottom: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        zIndex: 0
                    });
                    if ($counter.hasClass('pxl-counter1')) {
                        $bg.css('height', start + '%');
                    } else if ($counter.hasClass('pxl-counter2')) {
                        $bg.css({
                            height: '100%',  
                        });
                        $bg.css('width', start + '%');
                    }

                    $inner.find('.pxl-counter--number, .pxl-content-bottom').css({
                        position: 'relative',
                        zIndex: 1
                    });
                    function animateHeightOrWidth(timestamp) {
                        if (!startTime) startTime = timestamp;
                        var progress = Math.min((timestamp - startTime) / duration, 1);
                        var current = start + (end - start) * progress;

                        if ($counter.hasClass('pxl-counter1')) {
                            $bg.css('height', current + '%');
                        } else if ($counter.hasClass('pxl-counter2')) {
                            $bg.css('width', current + '%');
                        }

                        if (progress < 1) {
                            requestAnimationFrame(animateHeightOrWidth);
                        }
                    }

                    requestAnimationFrame(animateHeightOrWidth);
                }


            }, {
                offset: '95%',
                triggerOnce: true
            });

            // ===== Counter dạng slide (odometer)
            elementorFrontend.waypoint($scope.find('.pxl-counter--value.effect-slide'), function () {
                var $number = $(this),
                    data = $number.data(),
                    el = $number[0],
                    startNumber = data['startnumber'],
                    endNumber = data['endnumber'],
                    separator = data['delimiter'],
                    duration = data['duration'];

                // --- GỌI ODOMETER (JS GỐC)
                var od = new Odometer({
                    el: el,
                    value: startNumber,
                    format: separator,
                    theme: 'default'
                });
                od.update(endNumber);

                // --- THÊM HIỆU ỨNG CHO .pxl-counter1
                var $counter = $number.closest('.pxl-counter1');
                if ($counter.length) {
                    var $inner = $counter.find('.pxl-counter--inner');
                    var $bg = $inner.find('.pxl-data-background');

                    var start = parseFloat(startNumber || 0);
                    var end = parseFloat(endNumber || 100);
                    var startTime = null;

                    $inner.css({ position: 'relative', overflow: 'hidden' });
                    $bg.css({
                        position: 'absolute',
                        bottom: 0,
                        left: 0,
                        width: '100%',
                        height: start + '%',
                        zIndex: 0
                    });

                    $inner.find('.pxl-counter--number, .pxl-content-bottom').css({
                        position: 'relative',
                        zIndex: 1
                    });

                    // Animate height đồng bộ
                    function animateHeight(timestamp) {
                        if (!startTime) startTime = timestamp;
                        var progress = Math.min((timestamp - startTime) / duration, 1);
                        var current = start + (end - start) * progress;

                        $bg.css('height', current + '%');

                        if (progress < 1) {
                            requestAnimationFrame(animateHeight);
                        }
                    }

                    requestAnimationFrame(animateHeight);
                }

            }, {
                offset: '95%',
                triggerOnce: true
            });

        }, 300);
    };


    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_counter.default', pxl_widget_counter_handler);
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_pie_chart.default', pxl_widget_counter_handler);
    });
})(jQuery);