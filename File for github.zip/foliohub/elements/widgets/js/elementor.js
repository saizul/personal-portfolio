(function ($) {

    //animation
    function foliohub_animation_handler($scope) {
        elementorFrontend.waypoint($(document).find('.pxl-animate'), function () {
            var $animate_el = $(this),
                data = $animate_el.data('settings');
            if (typeof data != 'undefined' && typeof data['animation'] != 'undefined') {
                setTimeout(function () {
                    $animate_el.removeClass('pxl-invisible').addClass('animated ' + data['animation']);
                }, data['animation_delay']);
            } else {
                setTimeout(function () {
                    $animate_el.removeClass('pxl-invisible').addClass('animated fadeInUp');
                }, 300);
            }
        });

        elementorFrontend.waypoint($scope.find('.pxl-border-animated'), function () {
            $(this).addClass('pxl-animated');
        });
        elementorFrontend.waypoint($scope.find('.PXLfadeInUp,.PXLZoom2'), function () {
            $(this).addClass('pxl-animated');
        });
    }

    function foliohub_section_start_render() {
        var _elementor = typeof elementor != 'undefined' ? elementor : elementorFrontend;

        _elementor.hooks.addFilter('pxl_element_container/before-render', function (html, settings) {
            if (typeof settings.pxl_parallax_bg_img != 'undefined' && settings.pxl_parallax_bg_img.url != '') {
                html += '<div class="pxl-section-bg-parallax"></div>';
            }

            if (typeof settings.pxl_color_offset != 'undefined' && settings.pxl_color_offset != 'none') {
                html += '<div class="pxl-section-overlay-color"></div>';
            }

            if (typeof settings.pxl_overlay_img != 'undefined' && settings.pxl_overlay_img.url != '') {
                html += '<div class="pxl-overlay--image pxl-overlay--imageLeft"><div class="bg-image"></div></div>';
            }

            if (typeof settings.pxl_overlay_img2 != 'undefined' && settings.pxl_overlay_img2.url != '') {
                html += '<div class="pxl-overlay--image pxl-overlay--imageRight"><div class="bg-image"></div></div>';
            }

            return html;
        });

        $('.pxl-section-bg-parallax').closest('.elementor-element').addClass('pxl-section-parallax-overflow');
    }

    function foliohub_css_inline_js() {
        var _inline_css = "<style>";
        $(document).find('.pxl-inline-css').each(function () {
            var _this = $(this);
            _inline_css += _this.attr("data-css") + " ";
            _this.remove();
        });
        _inline_css += "</style>";
        $('head').append(_inline_css);
    }

    function foliohub_section_before_render() {
        var _elementor = typeof elementor != 'undefined' ? elementor : elementorFrontend;
        _elementor.hooks.addFilter('pxl-custom-section/before-render', function (html, settings, el) {
            if (typeof settings['row_divider'] !== 'undefined') {
                if (settings['row_divider'] == 'angle-top' || settings['row_divider'] == 'angle-bottom' || settings['row_divider'] == 'angle-top-right' || settings['row_divider'] == 'angle-bottom-left') {
                    html = '<svg class="pxl-row-angle" style="fill:#ffffff" xmlns="http://www.w3.org/2000/svg" width="100%" viewBox="0 0 100 100" version="1.1" preserveAspectRatio="none" height="130px"><path stroke="" stroke-width="0" d="M0 100 L100 0 L200 100"></path></svg>';
                    return html;
                }
                if (settings['row_divider'] == 'angle-top-bottom' || settings['row_divider'] == 'angle-top-bottom-left') {
                    html = '<svg class="pxl-row-angle pxl-row-angle-top" style="fill:#ffffff" xmlns="http://www.w3.org/2000/svg" width="100%" viewBox="0 0 100 100" version="1.1" preserveAspectRatio="none" height="130px"><path stroke="" stroke-width="0" d="M0 100 L100 0 L200 100"></path></svg><svg class="pxl-row-angle pxl-row-angle-bottom" style="fill:#ffffff" xmlns="http://www.w3.org/2000/svg" width="100%" viewBox="0 0 100 100" version="1.1" preserveAspectRatio="none" height="130px"><path stroke="" stroke-width="0" d="M0 100 L100 0 L200 100"></path></svg>';
                    return html;
                }
                if (settings['row_divider'] == 'wave-animation-top' || settings['row_divider'] == 'wave-animation-bottom') {
                    html = '<svg class="pxl-row-angle" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 1440 150" fill="#fff"><path d="M 0 26.1978 C 275.76 83.8152 430.707 65.0509 716.279 25.6386 C 930.422 -3.86123 1210.32 -3.98357 1439 9.18045 C 2072.34 45.9691 2201.93 62.4429 2560 26.198 V 172.199 L 0 172.199 V 26.1978 Z"><animate repeatCount="indefinite" fill="freeze" attributeName="d" dur="10s" values="M0 25.9086C277 84.5821 433 65.736 720 25.9086C934.818 -3.9019 1214.06 -5.23669 1442 8.06597C2079 45.2421 2208 63.5007 2560 25.9088V171.91L0 171.91V25.9086Z; M0 86.3149C316 86.315 444 159.155 884 51.1554C1324 -56.8446 1320.29 34.1214 1538 70.4063C1814 116.407 2156 188.408 2560 86.315V232.317L0 232.316V86.3149Z; M0 53.6584C158 11.0001 213 0 363 0C513 0 855.555 115.001 1154 115.001C1440 115.001 1626 -38.0004 2560 53.6585V199.66L0 199.66V53.6584Z; M0 25.9086C277 84.5821 433 65.736 720 25.9086C934.818 -3.9019 1214.06 -5.23669 1442 8.06597C2079 45.2421 2208 63.5007 2560 25.9088V171.91L0 171.91V25.9086Z"></animate></path></svg>';
                    return html;
                }
                if (settings['row_divider'] == 'curved-top' || settings['row_divider'] == 'curved-bottom') {
                    html = '<svg class="pxl-row-angle" xmlns="http://www.w3.org/2000/svg" width="100%" viewBox="0 0 1920 128" version="1.1" preserveAspectRatio="none" style="fill:#ffffff"><path stroke-width="0" d="M-1,126a3693.886,3693.886,0,0,1,1921,2.125V-192H-7Z"></path></svg>';
                    return html;
                }
            }
        });
    }

    var PXL_Icon_Contact_Form = function ($scope, $) {

        setTimeout(function () {
            $('.pxl--item').each(function () {
                var icon_input = $(this).find(".pxl--form-icon"),
                    control_wrap = $(this).find('.wpcf7-form-control');
                control_wrap.before(icon_input.clone());
                icon_input.remove();
            });
        }, 10);

    };


    function foliohub_split_text($scope) {
        var st = $scope.find(".pxl-split-text");
        if (st.length == 0) return;
        gsap.registerPlugin(SplitText);

        st.each(function (index, el) {
            var els = $(el).find('p').length > 0 ? $(el).find('p')[0] : el;
            const pxl_split = new SplitText(els, {
                type: "lines, words, chars",
                lineThreshold: 0.5,
                linesClass: "split-line"
            });
            var split_type_set = pxl_split.chars;

            gsap.set(els, { perspective: 400 });

            var delayAttr = $(el).attr('data-wow-delay');
            var delayValue = 0;

            if (delayAttr) {
                delayValue = parseFloat(delayAttr) / (delayAttr.includes('ms') ? 1000 : 1);
            }

            var settings = {
                scrollTrigger: {
                    trigger: els,
                    toggleActions: "play none none none",
                    start: "top 86%",
                    once: true
                },
                duration: 0.35,
                stagger: 0.02,
                ease: "Expo.out",
                delay: delayValue
            };
            if ($(el).hasClass('split-in-fade')) {
                settings.opacity = 0;
            }
            if ($(el).hasClass('split-in-right')) {
                settings.opacity = 0;
                settings.x = "50";
            }
            if ($(el).hasClass('split-in-left')) {
                settings.opacity = 0;
                settings.x = "-50";
            }
            if ($(el).hasClass('split-in-up')) {
                settings.opacity = 0;
                settings.y = "80";
            }
            if ($(el).hasClass('split-in-down')) {
                settings.opacity = 0;
                settings.y = "-80";
            }
            if ($(el).hasClass('split-in-rotate')) {
                settings.opacity = 0;
                settings.rotateX = "50deg";
            }
            if ($(el).hasClass('split-in-scale')) {
                settings.opacity = 0;
                settings.scale = "0.5";
            }

            if ($(el).hasClass('split-up')) {
                pxl_split.split({ type: "words" });
                split_type_set = pxl_split.words;

                $(split_type_set).each(function (index, elw) {
                    gsap.from(elw, {
                        opacity: 0,
                        duration: 0.65,
                        y: 60,
                        delay: 0.25 + index * 0.065,
                        ease: "expo.out",
                        scrollTrigger: {
                            trigger: el,
                            start: "top 86%",
                            toggleActions: "play none none none",
                        },
                    });
                });
            }

            if ($(el).hasClass('split-words-scale')) {
                pxl_split.split({ type: "words" });
                split_type_set = pxl_split.words;

                $(split_type_set).each(function (index, elw) {
                    gsap.set(elw, {
                        opacity: 0,
                        scale: index % 2 == 0 ? 0 : 2,
                        force3D: true,
                        duration: 0.1,
                        ease: "Linear.easeNone",
                        stagger: 0.02,
                    }, index * 0.01);
                });

                var pxl_anim = gsap.to(split_type_set, {
                    scrollTrigger: {
                        trigger: el,
                        toggleActions: "play none none none",
                        start: "top 86%",
                    },
                    rotateX: "0",
                    scale: 1,
                    opacity: 1,
                });

            } else {
                var pxl_anim = gsap.from(split_type_set, settings);
            }

            if ($(el).hasClass('hover-split-text')) {
                $(el).mouseenter(function (e) {
                    pxl_anim.restart();
                });
            }
        });
    }

    function foliohub_scroll_trigger($scope) {
        ScrollTrigger.matchMedia({
            "(min-width: 1401px)": function () {
                let t2 = gsap.timeline({
                    scrollTrigger: {
                        trigger: ".pxl-section-scale",
                        scrub: true,
                        start: "top top",
                        end: "bottom bottom",
                        pin: ".pxl-section-sticky",
                    },
                });
                t2.to(".pxl-section-slide", {
                    padding: "7.5rem"
                }, ">");
                t2.to(".pxl-sticky-mask", {
                    borderRadius: "2rem"
                }, "<");
                t2.from(".is-shape-1", {
                    right: "-10%"
                }, "<");
                t2.from(".is-shape-2", {
                    left: "-10%"
                }, "<");
            },
            "(max-width: 1400px)": function () {
                let t2 = gsap.timeline({
                    scrollTrigger: {
                        trigger: ".pxl-section-scale",
                        scrub: true,
                        start: "top top",
                        end: "bottom bottom",
                        pin: ".pxl-section-sticky",
                    },
                });
                t2.to(".pxl-section-slide", {
                    padding: "4.8rem"
                }, ">");
                t2.to(".pxl-sticky-mask", {
                    borderRadius: "1.6rem"
                }, "<");
                t2.from(".is-shape-1", {
                    right: "-10%"
                }, "<");
                t2.from(".is-shape-2", {
                    left: "-10%"
                }, "<");
            },
            "(max-width: 991px)": function () {
                let t2 = gsap.timeline({
                    scrollTrigger: {
                        trigger: ".pxl-section-scale",
                        scrub: true,
                        start: "top bottom",
                        end: "bottom top",
                    },
                });
                t2.to(".pxl-section-slide", {
                    padding: "2rem"
                }, ">");
                t2.to(".pxl-sticky-mask", {
                    borderRadius: "2rem"
                }, "<");
                t2.from(".is-shape-1", {
                    right: "-10%"
                }, "<");
                t2.from(".is-shape-2", {
                    left: "-10%"
                }, "<");

            },
        });
        gsap.to(".pxl-sticker-shape.is-rotate", {
            rotation: "800",
            scrollTrigger: {
                trigger: "#pxl-content-main",
                scrub: true,
                start: "top top",
                end: "bottom bottom",
            },
        });
    }

    function foliohub_zoom_point() {
        elementorFrontend.waypoint($(document).find('.pxl-zoom-point'), function () {
            var offset = $(this).offset();
            var offset_top = offset.top;
            var scroll_top = $(window).scrollTop();
        }, {
            offset: -100,
            triggerOnce: true
        });
    }


    function foliohub_logo_marquee($scope) {
        const logos = $scope.find('.pxl-item--marquee');
        gsap.set(logos, { autoAlpha: 1 })

        logos.each(function (index, el) {
            gsap.set(el, { xPercent: 100 * index });
        });

        if (logos.length > 2) {
            const logosWrap = gsap.utils.wrap(-100, ((logos.length - 1) * 100));
            const durationNumber = logos.data('duration');
            const slipType = logos.data('slip-type');
            var slipResult = `-=${logos.length * 100}`;
            if (slipType == 'right') {
                slipResult = `+=${logos.length * 100}`;
            }
            gsap.to(logos, {
                xPercent: slipResult,
                duration: durationNumber,
                repeat: -1,
                ease: 'none',
                modifiers: {
                    xPercent: xPercent => logosWrap(parseFloat(xPercent))
                }
            });
        }
    }

    function foliohub_scroll_fixed_section() {
        const fixed_section_top = $('.pxl-section-fix-top');
        if (fixed_section_top.length > 0) {
            ScrollTrigger.matchMedia({
                "(min-width: 991px)": function () {
                    const pinnedSections = ['.pxl-section-fix-top'];
                    pinnedSections.forEach(className => {
                        gsap.to(".pxl-section-fix-bottom", {
                            scrollTrigger: {
                                trigger: ".pxl-section-fix-bottom",
                                scrub: true,
                                pin: className,
                                pinSpacing: false,
                                start: 'top bottom',
                                end: "bottom top",
                            },
                        });
                        gsap.to(".pxl-section-fix-bottom .pxl-section-overlay-color", {
                            scrollTrigger: {
                                trigger: ".pxl-section-fix-bottom",
                                scrub: true,
                                pin: className,
                                pinSpacing: false,
                                start: 'top bottom',
                                end: "bottom top",
                            },
                        });
                    });
                }
            });
        }

        const section_overlay_color = $('.pxl-section-overlay-color');
        if (section_overlay_color.length > 0) {
            const space_top = section_overlay_color.data('space-top');
            const space_left = section_overlay_color.data('space-left');
            const space_right = section_overlay_color.data('space-right');
            const space_bottom = section_overlay_color.data('space-bottom');

            const radius_top = section_overlay_color.data('radius-top');
            const radius_left = section_overlay_color.data('radius-left');
            const radius_right = section_overlay_color.data('radius-right');
            const radius_bottom = section_overlay_color.data('radius-bottom');

            const overlay_radius = radius_top + 'px ' + radius_right + 'px ' + radius_bottom + 'px ' + radius_left + 'px ';

            ScrollTrigger.matchMedia({
                "(min-width: 991px)": function () {
                    const pinnedSections = ['.pxl-bg-color-scroll'];
                    pinnedSections.forEach(className => {
                        gsap.to(".overlay-type-scroll", {
                            scrollTrigger: {
                                trigger: ".pxl-bg-color-scroll",
                                scrub: true,
                                pinSpacing: false,
                                start: 'top bottom',
                                end: "bottom top",
                            },
                            left: space_left + "px",
                            right: space_right + "px",
                            top: space_top + "px",
                            bottom: space_bottom + "px",
                            borderRadius: overlay_radius,
                        });
                    });
                }
            });
        }
    }
    function foliohub_scroll_checkp($scope) {
        $scope.find('.pxl-el-divider').each(function () {
            var wcont1 = $(this);


            function checkScrollPosition() {
                var pxl_scroll_top = $(window).scrollTop(),
                    viewportBottom = pxl_scroll_top + $(window).height(),
                    elementTop = wcont1.offset().top,
                    elementBottom = elementTop + wcont1.outerHeight();

                if (elementTop < viewportBottom && elementBottom > pxl_scroll_top) {
                    wcont1.addClass('visible');
                }
            }

            checkScrollPosition();

            $(window).on('scroll', function () {
                checkScrollPosition();
            });

        });
    }

    function foliohub_section_start_render2() {

        var _elementor = typeof elementor != 'undefined' ? elementor : elementorFrontend;

        _elementor.hooks.addFilter('pxl_element_container/before-render', function (html, settings, el) {

            if (typeof settings.pxl_parallax_bg_img != 'undefined' && settings.pxl_parallax_bg_img.url != '') {

                html += '<div class="pxl-section-bg-parallax"></div>';

            }

            return html;

        });

    }

    function pxl_widget_sphere_handler($scope) {
        const canvas = $scope.find(".pxl-sphere canvas");
        if (!canvas.length) return;

        const sphereEl = $scope.find(".pxl-sphere");
        const size = parseInt(sphereEl.data("size")) || 950;
        const radius = parseInt(sphereEl.data("radius")) || size * 0.5;
        const sphereColor = sphereEl.data("color") || "rgba(255, 255, 255, 0.15)";
        const rotationType = sphereEl.data("rotation") || "y_axis";
        const rotationSpeed = parseFloat(sphereEl.data("speed")) || 0.005;
        const customXSpeed = parseFloat(sphereEl.data("xspeed")) || 0.003;
        const customYSpeed = parseFloat(sphereEl.data("yspeed")) || 0.005;
        const tiltAngle =
            ((parseFloat(sphereEl.data("tilt")) || -30) * Math.PI) / 180;

        const ctx = canvas[0].getContext("2d");

        canvas[0].width = size;
        canvas[0].height = size;

        let angleX = tiltAngle;
        let angleY = 0;

        function rotate(point, angleX, angleY) {
            let cosX = Math.cos(angleX),
                sinX = Math.sin(angleX);
            let cosY = Math.cos(angleY),
                sinY = Math.sin(angleY);

            let y = point.y * cosX - point.z * sinX;
            let z = point.y * sinX + point.z * cosX;
            let x = point.x * cosY - z * sinY;
            z = point.x * sinY + z * cosY;
            return { x, y, z };
        }

        function drawSphere() {
            ctx.clearRect(0, 0, canvas[0].width, canvas[0].height);
            ctx.strokeStyle = sphereColor;
            ctx.lineWidth = 1;
            const cx = canvas[0].width / 2;
            const cy = canvas[0].height / 2;

            for (
                let lat = -Math.PI / 2;
                lat <= Math.PI / 2;
                lat += Math.PI / 10
            ) {
                let circlePoints = [];
                for (let lon = 0; lon < 2 * Math.PI; lon += Math.PI / 20) {
                    let x = Math.cos(lat) * Math.cos(lon);
                    let y = Math.sin(lat);
                    let z = Math.cos(lat) * Math.sin(lon);
                    let rotatedPoint = rotate({ x, y, z }, angleX, angleY);
                    circlePoints.push(rotatedPoint);
                }
                ctx.beginPath();
                circlePoints.forEach((p, i) => {
                    if (i === 0) {
                        ctx.moveTo(cx + p.x * radius, cy + p.y * radius);
                    } else {
                        ctx.lineTo(cx + p.x * radius, cy + p.y * radius);
                    }
                });
                ctx.closePath();
                ctx.stroke();
            }

            for (let lon = 0; lon < 2 * Math.PI; lon += Math.PI / 10) {
                let circlePoints = [];
                for (
                    let lat = -Math.PI / 2;
                    lat <= Math.PI / 2;
                    lat += Math.PI / 20
                ) {
                    let x = Math.cos(lat) * Math.cos(lon);
                    let y = Math.sin(lat);
                    let z = Math.cos(lat) * Math.sin(lon);
                    let rotatedPoint = rotate({ x, y, z }, angleX, angleY);
                    circlePoints.push(rotatedPoint);
                }
                ctx.beginPath();
                circlePoints.forEach((p, i) => {
                    if (i === 0) {
                        ctx.moveTo(cx + p.x * radius, cy + p.y * radius);
                    } else {
                        ctx.lineTo(cx + p.x * radius, cy + p.y * radius);
                    }
                });
                ctx.stroke();
            }
        }

        function updateRotation() {
            switch (rotationType) {
                case "y_axis":
                    angleY += rotationSpeed;
                    break;
                case "x_axis":
                    angleX += rotationSpeed;
                    break;
                case "both_axis":
                    angleX += rotationSpeed;
                    angleY += rotationSpeed;
                    break;
                case "custom":
                    angleX += customXSpeed;
                    angleY += customYSpeed;
                    break;
            }
        }

        function animate() {
            updateRotation();
            drawSphere();
            requestAnimationFrame(animate);
        }

        animate();
    };

    function foliohub_parallax_bg() {
        // Đăng ký plugin nếu chưa có
        gsap.registerPlugin(ScrollTrigger);

        ScrollTrigger.matchMedia({
            // Chỉ chạy khi màn hình > 1024px (Desktop)
            "(min-width: 1025px)": function () {

                // Tìm tất cả các phần tử
                $('.pxl-bg-prx-effect-pinned-circle-zoom-clipped').each(function (_, el) {
                    const $el = $(el);
                    const circle = el.querySelector('.circle-zoom');
                    const img = el.querySelector('.clipped-bg-circle-pinned');
                    const innerLayer = el.querySelector('.circle-inner-layer');

                    // Hàm tính radius trực tiếp
                    const getRadius = () => {
                        const rect = el.getBoundingClientRect();
                        return Math.sqrt(
                            Math.pow(rect.width / 2, 2) +
                            Math.pow(rect.height / 2, 2)
                        );
                    };

                    let tl = gsap.timeline({
                        scrollTrigger: {
                            trigger: el,
                            start: "top 10%",
                            end: "bottom 80%",
                            scrub: 2, // Tăng scrub lên xíu cho mượt
                            invalidateOnRefresh: true, // Quan trọng: Bắt buộc tính lại giá trị khi resize
                        }
                    })
                        .fromTo(circle,
                            { attr: { r: 0 } },
                            { attr: { r: getRadius } }, // Gọi hàm getRadius mỗi khi refresh
                            0)
                        .fromTo(img,
                            { scale: 2 },
                            { scale: 1 },
                            0)
                        .to(innerLayer, {
                            autoAlpha: 0, // Dùng autoAlpha tốt hơn opacity (ẩn luôn visibility)
                            duration: 0.75
                        }, 0.25);
                });
            },

            // Mobile (nhỏ hơn hoặc bằng 1024px) - Clean up tự động
            "(max-width: 1024px)": function () {
                // Không cần làm gì, GSAP tự kill các animation ở trên
            }
        });

        // Ép buộc refresh sau khi load xong mọi thứ
        window.addEventListener("load", () => {
            // Đợi thêm 1 chút để chắc chắn layout ổn định (đặc biệt nếu có custom font)
            setTimeout(() => ScrollTrigger.refresh(), 500);
        });
    }


    function foliohub_text_marquee($scope) {
        const $target = $scope.find('.pxl-text-marquee1, .pxl-text-marquee2');
        if (!$target.length) return;

        $target.each(function () {
            const $this = $(this);
            const $items = $this.find('.pxl-text--marquee, .pxl-item--content');
            if (!$items.length) return;

            const boxes = gsap.utils.toArray($items);
            const isLTR = $this.hasClass('ltr');

            text_horizontalLoop(boxes, {
                paused: false,
                repeat: -1,
                reversed: isLTR
            });
        });

        function text_horizontalLoop(items, config) {
            items = gsap.utils.toArray(items);
            config = config || {};
            let tl = gsap.timeline({
                repeat: config.repeat,
                paused: config.paused,
                defaults: { ease: "none" },
                onReverseComplete: () => tl.totalTime(tl.rawTime() + tl.duration() * 100)
            }),
                length = items.length,
                startX = items[0].offsetLeft,
                times = [],
                widths = [],
                xPercents = [],
                curIndex = 0,
                pixelsPerSecond = (config.speed || 1) * 100,
                snap = config.snap === false ? v => v : gsap.utils.snap(config.snap || 1),
                totalWidth, curX, distanceToStart, distanceToLoop, item, i;

            gsap.set(items, {
                xPercent: (i, el) => {
                    let w = widths[i] = parseFloat(gsap.getProperty(el, "width", "px"));
                    xPercents[i] = snap(parseFloat(gsap.getProperty(el, "x", "px")) / w * 100 + gsap.getProperty(el, "xPercent"));
                    return xPercents[i];
                }
            });
            gsap.set(items, { x: 0 });

            totalWidth = items[length - 1].offsetLeft + xPercents[length - 1] / 100 * widths[length - 1] - startX + items[length - 1].offsetWidth * gsap.getProperty(items[length - 1], "scaleX") + (parseFloat(config.paddingRight) || 0);

            for (i = 0; i < length; i++) {
                item = items[i];
                curX = xPercents[i] / 100 * widths[i];
                distanceToStart = item.offsetLeft + curX - startX;
                distanceToLoop = distanceToStart + widths[i] * gsap.getProperty(item, "scaleX");
                tl.to(item, { xPercent: snap((curX - distanceToLoop) / widths[i] * 100), duration: distanceToLoop / pixelsPerSecond }, 0)
                    .fromTo(item, { xPercent: snap((curX - distanceToLoop + totalWidth) / widths[i] * 100) }, { xPercent: xPercents[i], duration: (curX - distanceToLoop + totalWidth - curX) / pixelsPerSecond, immediateRender: false }, distanceToLoop / pixelsPerSecond)
                    .add("label" + i, distanceToStart / pixelsPerSecond);
                times[i] = distanceToStart / pixelsPerSecond;
            }

            function toIndex(index, vars) {
                vars = vars || {};
                (Math.abs(index - curIndex) > length / 2) && (index += index > curIndex ? -length : length);
                let newIndex = gsap.utils.wrap(0, length, index),
                    time = times[newIndex];
                if (time > tl.time() !== index > curIndex) {
                    vars.modifiers = { time: gsap.utils.wrap(0, tl.duration()) };
                    time += tl.duration() * (index > curIndex ? 1 : -1);
                }
                curIndex = newIndex;
                vars.overwrite = true;
                return tl.tweenTo(time, vars);
            }

            tl.next = vars => toIndex(curIndex + 1, vars);
            tl.previous = vars => toIndex(curIndex - 1, vars);
            tl.current = () => curIndex;
            tl.toIndex = (index, vars) => toIndex(index, vars);
            tl.times = times;
            tl.progress(1, true).progress(0, true);
            if (config.reversed) {
                tl.vars.onReverseComplete();
                tl.reverse();
            }
            return tl;
        }
    }

    function foliohub_hover_img_inside($scope) {
        const scopeEl = $scope[0];
        const svg = scopeEl.querySelector(".pxl-svg-image-inside svg");
        const hoverImages = scopeEl.querySelectorAll(".svg-hover-img");

        if (!svg || hoverImages.length === 0) return;

        // Set style transition một lần
        hoverImages.forEach(img => {
            img.style.transition = "opacity 0.3s ease";
            img.style.opacity = "0";
        });

        function resetImages() {
            hoverImages.forEach(img => {
                img.style.opacity = "0";
            });
        }

        const paths = svg.querySelectorAll(".svg-path");
        paths.forEach((path, index) => {
            path.addEventListener("mouseenter", function () {
                if (window.innerWidth <= 767) return;

                resetImages();
                const img = scopeEl.querySelector(".svg-hover-img.img-" + (index + 1));
                if (img) {
                    img.style.opacity = "1";
                }
            });

            path.addEventListener("mouseleave", function () {
                if (window.innerWidth <= 767) return;

                resetImages();
            });
        });
    }


    function foliohub_image_effect($scope) {
        setTimeout(function () {
            const links = $scope.find('.pxl-image-effect .hover-images');
            if (!links.length) return;

            links.each(function (index, el) {
                let img1 = $(el).find('.img-1 img').attr('src');
                let img2 = $(el).find('.img-2 img').attr('src') || img1;

                let displacementImageEl = $scope.find('.pxl-image-webgl');
                let displacementImage = displacementImageEl.length ? displacementImageEl.attr("src") : '';

                if (!img1 || !displacementImage) return;

                new hoverEffect({
                    parent: el,
                    intensity: 0.3,
                    image1: img1,
                    image2: img2,
                    displacementImage: displacementImage,
                });

            });
        }, 300);
    }


    function foliohubWidgetTextImage($scope) {
        if (window.innerWidth <= 767) return;
        if ($scope.find('.pxl-text-img-wrap').length <= 0) return;
        var mouseX = 0,
            mouseY = 0;

        $scope.find('.pxl-text-img-wrap .pxl-item--inner').mousemove(function (e) {
            var offset = $(this).offset();
            mouseX = (e.pageX - offset.left);
            mouseY = (e.pageY - offset.top);
        });

        $scope.find('.pxl-text-img-wrap ul>li').on("mouseenter", function () {
            $(this).removeClass('deactive').addClass('active');
            var target = $(this).attr('data-target');
            $(this).closest('.pxl-item--inner').find(target).removeClass('deactive').addClass('active');
        });
        $scope.find('.pxl-text-img-wrap ul>li').on("mouseleave", function () {
            $(this).addClass('deactive').removeClass('active');
            var target = $(this).attr('data-target');
            $(this).closest('.pxl-item--inner').find(target).addClass('deactive').removeClass('active');
        });
        const s = {
            x: window.innerWidth / 2,
            y: window.innerHeight / 2
        },
            t = gsap.quickSetter($scope.find('.pxl-text-img-wrap .pxl-item--inner'), "css"),
            e = gsap.quickSetter($scope.find('.pxl-text-img-wrap .pxl-item--inner'), "css");

        gsap.ticker.add((() => {
            const o = .15,
                i = 1 - Math.pow(.85, gsap.ticker.deltaRatio());
            s.x += (mouseX - s.x) * i,
                s.y += (mouseY - s.y) * i,
                t({
                    "--pxl-mouse-x": `${s.x}px`
                }), e({
                    "--pxl-mouse-y": `${s.y}px`
                })
        }))
    }


    function foliohub_animation_btn($scope) {
        const $items = $scope.find('.pxl-post-carousel .pxl-post--featured');
        if (!$items) return;
        $items.each(function () {
            const $section = $(this);
            const $cursor = $section.find('.btn--readmore');

            if ($cursor.length) {
                mouseFollower($section, $cursor);
            }
        });
        function mouseFollower($section, $target) {
            const cursor = $target[0];
            if (!cursor) return;

            const cursorWidth = cursor.offsetWidth / 2;
            const cursorHeight = cursor.offsetHeight / 2;

            let mouseX = 0;
            let mouseY = -10;
            let isMouseOver = false;

            $section.on('mousemove', function (e) {
                mouseX = e.pageX;
                mouseY = e.pageY;
            });

            $section.on('mouseenter', function () {
                isMouseOver = true;
                gsap.to(cursor, {
                    scale: 1,
                    opacity: 1,
                    duration: 0.3,
                    ease: "power2.out"
                });

                animate();
            });


            $section.on('mouseleave', function () {
                isMouseOver = false;

                gsap.to(cursor, {
                    scale: 0.3,
                    opacity: 0,
                    duration: 0.3,
                    ease: "power2.out"
                });
            });


            function animate() {
                if (isMouseOver) {
                    const sectionOffset = $section.offset();

                    gsap.to(cursor, {
                        x: mouseX - sectionOffset.left - cursorWidth,
                        y: mouseY - sectionOffset.top - cursorHeight,
                        ease: "linear",
                        duration: 0
                    });

                    requestAnimationFrame(animate);
                }
            }
        }
    }

    ///folio hub js
    function initToggleActive($scope, selector = '.layout-service-list-1 .list-item-inner', activeClass = 'active') {
        if (window.matchMedia('(max-width: 959px)').matches) return;

        const $elements = $scope.find(selector);
        if (!$elements.length) return;

        if (!$elements.filter(`.${activeClass}`).length) {
            $elements.first().addClass(activeClass);
        }

        $elements.each(function () {
            const $item = $(this);
            const $top = $item.find('.pxl-item--top');
            const $bottom = $item.find('.pxl-item--bottom');

            if ($item.hasClass(activeClass)) {
                const bottomHeight = $bottom.prop('scrollHeight');
                $top.css('max-height', 0);
                $bottom.css('max-height', bottomHeight);
            } else {
                $top.css('max-height', '');
                $bottom.css('max-height', 0);
            }
        });
        $elements.on('click', function (e) {
            const $item = $(this);
            if ($item.is('a') && $item.attr('href') === '#') {
                e.preventDefault();
            }
            const $top = $item.find('.pxl-item--top');
            const $bottom = $item.find('.pxl-item--bottom');
            const bottomHeight = $bottom.prop('scrollHeight');
            $elements.removeClass(activeClass)
                .find('.pxl-item--bottom').css('max-height', 0)
                .end().find('.pxl-item--top').css('max-height', '');

            $item.addClass(activeClass);
            $top.css('max-height', 0);
            $bottom.css('max-height', bottomHeight);
            ScrollTrigger.getAll().forEach(trigger => {
                if ($scope[0].contains(trigger.trigger)) {
                    trigger.refresh();
                }
            });
        });
    }
    function initOpacityOnScroll($scope, selector = ".pxl-column-opacity", distance = 1000, start = "top 100%", end = "bottom 0%") {
        const elements = $scope.find(selector);
        if (!elements.length) return;
        if (window.innerWidth <= 767) return;
        gsap.registerPlugin(ScrollTrigger);

        elements.each(function () {
            const el = this;
            el.style.willChange = "opacity, transform";

            gsap.fromTo(
                el,
                { opacity: 0, y: 50 },
                {
                    opacity: 0,
                    y: -50,
                    ease: "none",
                    scrollTrigger: {
                        trigger: el,
                        start: start,
                        end: end,
                        scrub: true,
                        onUpdate: self => {
                            const progress = self.progress;
                            const fade = 1 - Math.abs(0.5 - progress) * 2;
                            const translate = 50 - progress * 100;
                            el.style.opacity = fade;
                            el.style.transform = `translateY(${translate}px)`;
                        },
                    },
                }
            );
        });
    }
    function pxl_transition_transform_service($scope) {
        gsap.registerPlugin(ScrollTrigger);

        const selector = '.layout-service-list-2 .list-item-inner, .layout-service-list-4 .list-item-inner';
        const items = $scope.find(selector);
        if (!items.length) return;

        let isDesktop = window.innerWidth > 1025;

        function killTriggers() {
            items.each(function () {
                ScrollTrigger.getAll().forEach(st => {
                    if (st.trigger === this) st.kill();
                });

                gsap.set(this, {
                    clearProps: "all"
                });
            });
        }

        function init() {
            if (!isDesktop) return;

            items.each(function () {
                const item = this;

                gsap.set(item, {
                    y: '50%',
                    opacity: 0
                });

                gsap.to(item, {
                    y: '0%',
                    opacity: 1,
                    duration: 1,
                    ease: "power3.out",
                    scrollTrigger: {
                        trigger: item,
                        start: "top 70%",
                        end: "top 60%",
                        toggleActions: "play none none reverse"
                    }
                });
            });

            ScrollTrigger.refresh();
        }

        init();

        // 🔁 resize handler
        let resizeTimeout;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(() => {
                const nowDesktop = window.innerWidth > 1025;

                if (nowDesktop !== isDesktop) {
                    isDesktop = nowDesktop;
                    killTriggers();
                    init();
                }
            }, 200);
        });
    }
    function initToggleActivesv3($scope, selector = '.layout-service-list-3 .list-item-inner', activeClass = 'active') {
        if (window.matchMedia('(max-width: 959px)').matches) return;

        const $elements = $scope.find(selector);
        if (!$elements.length) return;

        if (!$elements.filter(`.${activeClass}`).length) {
            $elements.first().addClass(activeClass);
        }
        $elements.each(function () {
            const $item = $(this);
            const $footer = $item.find('.pxl-footer-item');

            if ($item.hasClass(activeClass)) {
                const footerHeight = $footer.prop('scrollHeight');
                $footer.css('max-height', footerHeight);
            } else {
                $footer.css('max-height', 0);
            }
        });

        // Click event
        $elements.on('click', function (e) {
            const $item = $(this);
            if ($item.is('a') && $item.attr('href') === '#') {
                e.preventDefault();
            }
            const $footer = $item.find('.pxl-footer-item');
            const footerHeight = $footer.prop('scrollHeight');
            $elements.removeClass(activeClass)
                .find('.pxl-footer-item').css('max-height', 0);
            $item.addClass(activeClass);
            $footer.css('max-height', footerHeight);

            ScrollTrigger.getAll().forEach(trigger => {
                if ($scope[0].contains(trigger.trigger)) {
                    trigger.refresh();
                }
            });
        });
    }
    function initTestimonialScrollLoop($scope) {
        gsap.registerPlugin(ScrollTrigger);

        const wrap = $scope.find('.pxl-testimonial-list1');
        if (!wrap.length) return;

        const items = wrap.find('.pxl-item');
        const total = items.length;
        const windowWidth = window.innerWidth;

        if (total <= 1 || windowWidth <= 1200) return;

        const container = wrap[0];

        // Tạo scroll space
        gsap.set(container, {
            height: window.innerHeight * (total + 1)
        });

        // Pattern xoay
        const rotatePattern = [0, 7.12, -6.8];

        // Set trạng thái ban đầu
        items.each(function (i) {

            const rotateValue = rotatePattern[i % 3]; // Lặp chu kỳ 3

            gsap.set(this, {
                yPercent: 150,
                opacity: 0,
                scale: 0.8,
                rotate: rotateValue,
                zIndex: total + i
            });
        });

        // Timeline scroll
        const tl = gsap.timeline({
            scrollTrigger: {
                trigger: container,
                start: "top 30%",
                end: "bottom bottom",
                scrub: true
            }
        });

        items.each(function (index) {
            const rotateValue = rotatePattern[index % 3];

            tl.to({}, { duration: 1 }); // marker

            tl.to(this, {
                yPercent: 0,
                opacity: 1,
                scale: 1,
                rotate: rotateValue,
                duration: 0.5,
                ease: "power2.out"
            }, index);

            if (index > 0) {
                tl.to(items[index - 1], {
                    opacity: 1,
                    scale: 1,
                    duration: 0.4,
                    ease: "power2.out"
                }, index);
            }
        });
    }
    function foliohub_progressbar_handler($scope) {
        elementorFrontend.waypoint(
            $scope.find('.pxl-counter3'),
            function () {

                var $counterWrap = $(this);
                var $counterValue = $counterWrap.find('.pxl-counter--value');
                var $holder = $counterWrap.find('.pxl-counter--holder');

                if (!$counterValue.length) return;

                var start = parseFloat($counterValue.data('startnumber')) || 0;
                var end = parseFloat($counterValue.data('endnumber')) || 0;
                var speed = parseInt($counterValue.data('duration')) || 1500;

                if (end > 100) end = 100;
                if (end < 0) end = 0;

                // Progress bar animation
                $counterWrap.prop({ percent: start }).animate(
                    { percent: end },
                    {
                        duration: speed,
                        easing: 'linear',
                        step: function (percent) {
                            var offsetMain = 100 - percent;
                            var offsetSub = percent + 8;

                            $counterWrap.find('.js-progress-bar')
                                .css('stroke-dashoffset', offsetMain);

                            $counterWrap.find('.js-progress-bar1')
                                .css('stroke-dashoffset', offsetSub);
                        }
                    }
                );

                // Number animation
                $holder.prop({ counter: start }).animate(
                    { counter: end },
                    {
                        duration: speed,
                        easing: 'linear',
                        step: function (value) {
                            $counterValue.text(Math.ceil(value));
                        }
                    }
                );

            },
            { offset: '80%', triggerOnce: true }
        );
    }










    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/global', function ($scope) {
            foliohub_scroll_checkp($scope);
            foliohub_animation_handler($scope);
            foliohub_animation_btn($scope);
            initOpacityOnScroll($scope);
            pxl_transition_transform_service($scope);
            initToggleActivesv3($scope);
            initTestimonialScrollLoop($scope);
            foliohub_progressbar_handler($scope);

        });
        foliohub_section_start_render();
        foliohub_section_start_render2();
        foliohub_parallax_bg();
        foliohub_css_inline_js();
        foliohub_section_before_render();
        foliohub_zoom_point();
        foliohub_scroll_fixed_section();
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_contact_form.default', PXL_Icon_Contact_Form);
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_heading.default', function ($scope) {
            foliohub_split_text($scope);
        });
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_sphere.default', function ($scope) {
            pxl_widget_sphere_handler($scope);
        });
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_post_slip.default', function ($scope) {
            foliohub_split_text($scope);
        });
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_section_scale.default', function ($scope) {
            foliohub_scroll_trigger($scope);
        });
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_logo_marquee.default', function ($scope) {
            foliohub_logo_marquee($scope);
        });
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_text_marquee.default', function ($scope) {
            foliohub_text_marquee($scope);
        });
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_service_box.default', function ($scope) {
            foliohub_text_marquee($scope);
        });
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_image_inside.default', function ($scope) {
            foliohub_hover_img_inside($scope);
        });
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_history.default', function ($scope) {
            foliohubWidgetTextImage($scope);
        });
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_post_list.default', function ($scope) {
            initToggleActive($scope);
        });
        ['pxl_image_effect.default', 'pxl_post_grid.default'].forEach(function (widget) {
            elementorFrontend.hooks.addAction('frontend/element_ready/' + widget, function ($scope) {
                foliohub_image_effect($scope);
            });
        });

    });
})(jQuery);
