(function ($) {
    var pxl_widget_accordion_handler = function ($scope, $) {
        // Accordion gốc
        $scope.find(".pxl-accordion .pxl-accordion--title").on("click", function (e) {
            e.preventDefault();
            var pxl_target = $(this).data("target");
            var pxl_parent = $(this).closest(".pxl-accordion");
            var pxl_active = pxl_parent.find(".pxl-accordion--title");

            pxl_active.each(function () {
                var pxl_item_target = $(this).data("target");
                if (pxl_item_target != pxl_target) {
                    $(this).removeClass("active");
                    $(this).parent().removeClass("active");
                    $(pxl_item_target).slideUp(400);
                }
            });

            $(this).parent().toggleClass("active");
            $(this).toggleClass("active");
            $(pxl_target).slideToggle(400);
        });

        // Accordion team-grid
        $scope.find(".pxl-team-grid1 .pxl-title-classify").on("click", function (e) {
            e.preventDefault();
            var $clickedTitle = $(this);
            var $parent = $clickedTitle.closest(".pxl-team-grid1");

            var $allTitles = $parent.find(".pxl-title-classify");
            var $allContents = $parent.find(".pxl-grid-inner");

            var $targetContent = $clickedTitle.next(".pxl-grid-inner");

            $allTitles.not($clickedTitle).removeClass("active");
            $allContents.not($targetContent).slideUp(400);

            $clickedTitle.toggleClass("active");
            $targetContent.slideToggle(400);
        });
    };

    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_accordion.default', pxl_widget_accordion_handler);
    });
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/pxl_team_grid.default', pxl_widget_accordion_handler);
    });
})(jQuery);