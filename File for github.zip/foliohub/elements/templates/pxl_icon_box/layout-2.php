<div class="pxl-icon-box pxl-icon-box2 <?php echo esc_attr($settings['style'].' '.$settings['animate_hover'].' '.$settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <div class="pxl-item--inner">
        <?php
            if ( ! empty( $settings['item_link']['url'] ) ) {
                $widget->add_render_attribute( 'item_link', 'href', $settings['item_link']['url'] );

                if ( $settings['item_link']['is_external'] ) {
                    $widget->add_render_attribute( 'item_link', 'target', '_blank' );
                }

                if ( $settings['item_link']['nofollow'] ) {
                    $widget->add_render_attribute( 'item_link', 'rel', 'nofollow' );
                }
            }
        ?>
        <div class="pxl-item--meta">
            <a <?php pxl_print_html($widget->get_render_attribute_string( 'item_link' )); ?>></a>
            <<?php echo esc_attr($settings['title_tag']); ?> class="pxl-item--title el-empty">
                <?php echo pxl_print_html($settings['title']); ?>
            </<?php echo esc_attr($settings['title_tag']); ?>>
            <div class="pxl-item--description el-empty"><?php echo pxl_print_html($settings['desc']); ?></div>
            <div class="pxl-year"><?php echo pxl_print_html($settings['year']); ?></div>
        </div>
    </div>
</div>