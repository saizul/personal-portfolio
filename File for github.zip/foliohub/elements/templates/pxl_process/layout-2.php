<div class="pxl-process pxl-process2">
    <div class="pxl-process-wrapper">
        <?php 
        $i = 1;
        $is_new = \Elementor\Icons_Manager::is_migration_allowed();
       
        foreach ($settings['process'] as $key => $value):
            $year = isset($value['year']) ? $value['year'] : '';
            $title = isset($value['title']) ? $value['title'] : '';
            $desc = isset($value['desc']) ? $value['desc'] : '';
            $icon_key = $widget->get_repeater_setting_key( 'pxl_icon', 'icons', $key );
            $widget->add_render_attribute( $icon_key, [
                'class' => $value['pxl_icon'],
                'aria-hidden' => 'true',
            ] );
            $delay = ($settings['pxl_animate_delay']) + (($i - 1) * 100);
            ?>
            <div class="pxl-process-item <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($delay); ?>ms">
                <div class="pxl-item">
                    <div class="pxl-item--top">
                        <?php if (!empty($i)): ?>
                            <h2 class="pxl-item--count">
                                <?php echo str_pad($i, 2, '0', STR_PAD_LEFT); ?>
                            </h2>
                        <?php endif; ?>
                    </div>
                    <div class="pxl-item--bottom">
                        <?php if (!empty($title)): ?>
                            <<?php echo esc_attr($settings['title_tag']); ?> class="pxl-item--title">
                                <?php echo pxl_print_html($title); ?>
                            </<?php echo esc_attr($settings['title_tag']); ?>>
                        <?php endif; ?>
                        <?php if (!empty($desc)): ?>
                            <div class="pxl-item--description">
                                <?php echo pxl_print_html($desc); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <svg xmlns="http://www.w3.org/2000/svg" width="240" height="240" viewBox="0 0 240 240" fill="white">
                        <path d="M131.15 190.08C137.88 160.77 160.76 137.88 190.07 131.16L239.58 119.8L190.08 108.44C160.76 101.71 137.88 78.82 131.15 49.51L119.79 0L108.43 49.51C101.7 78.82 78.82 101.71 49.5 108.44L0 119.8L49.51 131.16C78.82 137.89 101.7 160.77 108.43 190.08L119.79 239.58L131.15 190.08Z" />
                    </svg>
                </div> 
            </div>
            <?php
            $i++;
        endforeach; ?>
    </div>
</div>