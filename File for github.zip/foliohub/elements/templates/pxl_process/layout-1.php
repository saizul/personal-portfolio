<div class="pxl-process pxl-process1 ">
    <div class="pxl-process-wrapper">
        <?php 
        $i = 1;
        $is_new = \Elementor\Icons_Manager::is_migration_allowed();
        foreach ($settings['process'] as $key => $value):
            $year = isset($value['year']) ? $value['year'] : '';
            $title = isset($value['title']) ? $value['title'] : '';
            $desc = isset($value['desc']) ? $value['desc'] : '';
            $icon_key = $widget->get_repeater_setting_key( 'pxl_icon', 'icons', $key );
            $widget->add_render_attribute( $icon_key, [
                'class' => $value['pxl_icon'],
                'aria-hidden' => 'true',
            ] );
            $delay = ($settings['pxl_animate_delay']) + (($i - 1) * 100);
            ?>
            <div class="pxl-process-item <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($delay); ?>ms">
                <div class="pxl-item">
                    <div class="pxl-item--top">
                        <?php if (!empty($title)): ?>
                            <div class="pxl-item--year">
                                <?php echo pxl_print_html($year); ?>
                            </div>
                            <<?php echo esc_attr($settings['title_tag']); ?> class="pxl-item--title">
                                <?php echo pxl_print_html($title); ?>
                            </<?php echo esc_attr($settings['title_tag']); ?>>
                        <?php endif; ?>
                    </div>

                    <div class="pxl-item--bottom">
                        <?php if (!empty($desc)): ?>
                            <div class="pxl-item--description">
                                <?php echo pxl_print_html($desc); ?>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($i)): ?>
                            <div class="pxl-item--count">
                                <?php echo str_pad($i, 2, '0', STR_PAD_LEFT); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <span class="icon-box">
                    <?php if ( $is_new ):
                        \Elementor\Icons_Manager::render_icon( $value['pxl_icon'], [ 'aria-hidden' => 'true' ] );
                    elseif(!empty($value['pxl_icon'])): ?>
                        <i class="<?php echo esc_attr( $value['pxl_icon'] ); ?>" aria-hidden="true"></i>
                    <?php endif; ?>
                </span>   
            </div>
            <?php
            $i++;
        endforeach; ?>
    </div>
</div>