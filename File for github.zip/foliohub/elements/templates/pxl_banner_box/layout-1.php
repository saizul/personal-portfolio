<?php
$html_id = pxl_get_element_id($settings);
if (!empty($settings['link']['url'])) {
	$widget->add_render_attribute('button', 'href', $settings['link']['url']);

	if ($settings['link']['is_external']) {
		$widget->add_render_attribute('button', 'target', '_blank');
	}

	if ($settings['link']['nofollow']) {
		$widget->add_render_attribute('button', 'rel', 'nofollow');
	}
}
?>
<div class="pxl-banner pxl-banner1 <?php echo esc_attr($settings['style'] . ' ' . $settings['pxl_animate']); ?>"
	data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
	<div class="pxl-banner-inner">
		<?php foreach ($settings['item'] as $key => $value):
			$content = isset($value['content']) ? $value['content'] : '';
			$title = isset($value['title']) ? $value['title'] : '';
			$number = isset($value['number']) ? $value['number'] : '';
			$style_active = isset($value['style_active']) ? $value['style_active'] : '';
			$link_key = $widget->get_repeater_setting_key('icon_link', 'value', $key);

			if (!empty($value['icon_link']['url'])) {
				$widget->add_render_attribute($link_key, 'href', $value['icon_link']['url']);

				if (!empty($value['icon_link']['is_external'])) {
					$widget->add_render_attribute($link_key, 'target', '_blank');
				}

				if (!empty($value['icon_link']['nofollow'])) {
					$widget->add_render_attribute($link_key, 'rel', 'nofollow');
				}
			}
			$link_attributes = $widget->get_render_attribute_string($link_key);
			?>
			<div class="pxl-item-content <?php echo pxl_print_html($style_active); ?>">
				<div class="pxl-content">
					<?php if (!empty($title)): ?>
						<h5 class="pxl-item--title">
							<a class=" wow zoomIn" <?php echo wp_kses_post($link_attributes); ?>>
								<?php echo pxl_print_html($title); ?>
							</a>
						</h5>
					<?php endif; ?>
					<?php if (!empty($content)): ?>
						<div class="pxl-counter--content">
							<?php echo pxl_print_html($content); ?>
						</div>
					<?php endif; ?>
				</div>
				<?php if (!empty($number)): ?>
					<div class="pxl-item--number">
						<?php echo pxl_print_html($number); ?>
					</div>
				<?php endif; ?>
				<div class="pxl-icon">
					<svg xmlns="http://www.w3.org/2000/svg" width="136" height="136" viewBox="0 0 136 136" fill="#EB5838">
						<path
							d="M76.7817 76.7817L136 68L76.7817 59.2183L68 0L59.2183 59.2183L0 68L59.2183 76.7817L68 136L76.7817 76.7817Z" />
						<path
							d="M67.9999 76.6679L101.554 101.554L76.6681 67.9997L101.554 34.4453L67.9999 59.3316L34.4456 34.4453L59.3318 67.9997L34.4456 101.554L67.9999 76.6679Z" />
					</svg>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
</div>

