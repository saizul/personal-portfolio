<?php
$html_id = pxl_get_element_id($settings);
if (!empty($settings['link']['url'])) {
	$widget->add_render_attribute('button', 'href', $settings['link']['url']);

	if ($settings['link']['is_external']) {
		$widget->add_render_attribute('button', 'target', '_blank');
	}

	if ($settings['link']['nofollow']) {
		$widget->add_render_attribute('button', 'rel', 'nofollow');
	}
}
?>
<div class="pxl-banner pxl-banner2 <?php echo esc_attr($settings['style'] . ' ' . $settings['pxl_animate']); ?>"
	data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
	<div class="pxl-banner-inner">
		<div class="pxl-item-border">
			<div class="pxl-list">
				<?php foreach ($settings['item'] as $key => $value):
					$content = isset($value['content']) ? $value['content'] : '';
					$title = isset($value['title']) ? $value['title'] : '';
					$number = isset($value['number']) ? $value['number'] : '';
					$style_active = isset($value['style_active']) ? $value['style_active'] : '';
					$link_key = $widget->get_repeater_setting_key('icon_link', 'value', $key);

					if (!empty($value['icon_link']['url'])) {
						$widget->add_render_attribute($link_key, 'href', $value['icon_link']['url']);

						if (!empty($value['icon_link']['is_external'])) {
							$widget->add_render_attribute($link_key, 'target', '_blank');
						}

						if (!empty($value['icon_link']['nofollow'])) {
							$widget->add_render_attribute($link_key, 'rel', 'nofollow');
						}
					}
					$link_attributes = $widget->get_render_attribute_string($link_key);
					?>
					<div class="pxl-item-content <?php echo pxl_print_html($style_active); ?>">
						<?php if (!empty($number)): ?>
							<h1 class="pxl-item--number">
								<?php echo pxl_print_html($number); ?>
							</h1>
						<?php endif; ?>
						<div class="pxl-content">
							<?php if (!empty($title)): ?>
								<h3 class="pxl-item--title">
									<a class=" wow zoomIn" <?php echo wp_kses_post($link_attributes); ?>>
										<?php echo pxl_print_html($title); ?>
									</a>
								</h3>
							<?php endif; ?>
							<?php if (!empty($content)): ?>
								<div class="pxl-counter--content">
									<?php echo pxl_print_html($content); ?>
								</div>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</div>

