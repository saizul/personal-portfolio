<?php
$active = intval($settings['active']);
$accordion = $widget->get_settings('accordion');
$wg_id = pxl_get_element_id($settings);
$image_size = !empty($settings['img_size']) ? $settings['img_size'] : '826x657';
?>
<div class="pxl-accordion pxl-accordion2 <?php echo esc_attr($settings['style'] . ' ' . $settings['pxl_animate']); ?>"
    data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <?php $i = 1;
    foreach ($accordion as $key => $value):
        $is_active = ($key + 1) == $active;
        $pxl_id = isset($value['_id']) ? $value['_id'] : '';
        $title = isset($value['title']) ? $value['title'] : '';
        $desc = isset($value['desc']) ? $value['desc'] : '';
        ?>
        <div class="pxl--item <?php if ($settings['style'] != 'style2'): ?> <?php echo esc_attr($is_active ? 'active' : ''); ?> <?php endif; ?>">
            <<?php pxl_print_html($settings['title_tag']); ?> class="pxl-accordion--title"
                data-target="<?php echo esc_attr('#' . $wg_id . '-' . $pxl_id); ?>">
                <div class="pxl-item--count">
                    <?php echo esc_html( $i ); ?>
                </div>
                <span class="pxl-title--text"><?php echo wp_kses_post($title); ?></span>
                <div class="pxl-icon--plus"></div>
            </<?php pxl_print_html($settings['title_tag']); ?>>
            <div id="<?php echo esc_attr($wg_id . '-' . $pxl_id); ?>" class="pxl-accordion--content" <?php if ($is_active) { ?>style="display: block;" <?php } ?>>
                <div class="pxl-content">
                    <div class="pxl-item--content">
                        </<?php pxl_print_html($settings['title_tag']); ?>>
                        <div class="pxl-item-desc">
                            <?php echo wp_kses_post(nl2br($desc)); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $i++; endforeach; ?>
</div>



