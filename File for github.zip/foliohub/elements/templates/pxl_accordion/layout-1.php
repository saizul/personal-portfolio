<?php
$active = intval($settings['active']);
$accordion = $widget->get_settings('accordion');
$wg_id = pxl_get_element_id($settings);
$image_size = !empty($settings['img_size']) ? $settings['img_size'] : '826x657';
?>
<div class="pxl-accordion pxl-accordion1 <?php echo esc_attr($settings['style'] . ' ' . $settings['pxl_animate']); ?>"
    data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <?php $i = 1;
    foreach ($accordion as $key => $value):
        $is_active = ($key + 1) == $active;
        $pxl_id = isset($value['_id']) ? $value['_id'] : '';
        $title = isset($value['title']) ? $value['title'] : '';
        $number = isset($value['number']) ? $value['number'] : '';
        $desc = isset($value['desc']) ? $value['desc'] : '';
        $text_link = isset($value['text_link']) ? $value['text_link'] : '';
        $image = isset($value['image']) ? $value['image'] : '';
        $link_key = $widget->get_repeater_setting_key('link', 'value', $key);
        if (!empty($value['link']['url'])) {
            $widget->add_render_attribute($link_key, 'href', $value['link']['url']);

            if ($value['link']['is_external']) {
                $widget->add_render_attribute($link_key, 'target', '_blank');
            }

            if ($value['link']['nofollow']) {
                $widget->add_render_attribute($link_key, 'rel', 'nofollow');
            }
        }
        $link_attributes = $widget->get_render_attribute_string($link_key);
        ?>
        <div class="pxl--item <?php if ($settings['style'] != 'style2'): ?> <?php echo esc_attr($is_active ? 'active' : ''); ?> <?php endif; ?>">
            <<?php pxl_print_html($settings['title_tag']); ?> class="pxl-accordion--title"
                data-target="<?php echo esc_attr('#' . $wg_id . '-' . $pxl_id); ?>">
                <div class="pxl-item--count">
                    <?php echo ($i < 10 ? '0' . $i : $i) . '.';?>
                </div>
                <span class="pxl-title--text"><?php echo wp_kses_post($title); ?></span>
            </<?php pxl_print_html($settings['title_tag']); ?>>
            <div id="<?php echo esc_attr($wg_id . '-' . $pxl_id); ?>" class="pxl-accordion--content" <?php if ($is_active) { ?>style="display: block;" <?php } ?>>
                <div class="pxl-content">
                    <div class="pxl-item--count">
                        <?php echo ($i < 10 ? '0' . $i : $i) . '.';?>
                    </div>
                    <?php if (!empty($image['id'])) {
                        $img = pxl_get_image_by_size(array(
                            'attach_id' => $image['id'],
                            'thumb_size' => '172x134',
                            'class' => '',
                        ));
                        $thumbnail = $img['thumbnail'];
                        $thumbnail_url = $img['url'];
                        ?>
                        <div class="pxl-item--image">
                            <?php echo wp_kses_post($thumbnail); ?>
                        </div>
                    <?php } ?>
                    <div class="pxl-item--content">
                        <<?php pxl_print_html($settings['title_tag']); ?> class="pxl-accordion--title"
                            data-target="<?php echo esc_attr('#' . $wg_id . '-' . $pxl_id); ?>">
                            <span class="pxl-title--text"><?php echo wp_kses_post($title); ?></span>
                        </<?php pxl_print_html($settings['title_tag']); ?>>
                        <div class="pxl-item-desc">
                            <?php echo wp_kses_post(nl2br($desc)); ?>
                        </div>
                        <a class="pxl-link" <?php echo implode(' ', [$link_attributes]); ?>>
                            <?php echo pxl_print_html($text_link); ?>
                        </a>
                    </div>
                </div>
            </div>
            <div class="pxl-icon--plus"></div>
        </div>
        <?php $i++; endforeach; ?>
</div>