<?php
$active = intval($settings['active']);
$accordion = $widget->get_settings('accordion');
$wg_id = pxl_get_element_id($settings);
$html_id = pxl_get_element_id($settings);
?>
<div class="pxl-menu-hidden <?php echo esc_attr($settings['style'] . ' ' . $settings['pxl_animate']); ?>"
    data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <?php foreach ($accordion as $key => $value):
        $is_active = ($key + 1) == $active;
        $pxl_id = isset($value['_id']) ? $value['_id'] : '';
        $title = isset($value['title']) ? $value['title'] : '';
        $link_key = $widget->get_repeater_setting_key('link', 'value', $key);
        if (!empty($value['link']['url'])) {
            $widget->add_render_attribute($link_key, 'href', $value['link']['url']);

            if ($value['link']['is_external']) {
                $widget->add_render_attribute($link_key, 'target', '_blank');
            }

            if ($value['link']['nofollow']) {
                $widget->add_render_attribute($link_key, 'rel', 'nofollow');
            }
        }
        $link_attributes = $widget->get_render_attribute_string($link_key);
        ?>
        <div class="pxl--item <?php echo esc_attr($is_active ? 'active' : ''); ?>">
            <<?php pxl_print_html($settings['title_tag']); ?> class="pxl-accordion--title"
                data-target="<?php echo esc_attr('#' . $wg_id . '-' . $pxl_id); ?>">
                <a <?php echo implode(' ', [$link_attributes]); ?> class="pxl-title--text"><?php echo wp_kses_post($title); ?></a>
            </<?php pxl_print_html($settings['title_tag']); ?>>
            <div id="<?php echo esc_attr($wg_id . '-' . $pxl_id); ?>" class="pxl-accordion--content">
                <div class="pxl-content">
                    <?php if (!empty($value['content_template'])): ?>
                        <div id="<?php echo esc_attr($html_id . '-' . $value['_id']); ?>" class="pxl-item--content">
                            <?php
                            $tab_content = Elementor\Plugin::$instance->frontend->get_builder_content_for_display((int) $value['content_template']);
                            pxl_print_html($tab_content);
                            ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>