<div class="pxl-breadcrumb-wrap <?php echo esc_attr($settings['style']); ?>">
	<?php foliohub()->page->get_breadcrumb(); ?>
</div>