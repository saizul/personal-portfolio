<div class="pxl-client-review pxl-client-review2 <?php echo esc_attr($settings['pxl_animate']); ?> <?php echo esc_attr($settings['style']) ?>"
    data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">

    <div class="pxl-item--inner">

        <div class="pxl-item--meta">
            <div class="pxl-item--title">

                <?php {
                    // Set link attributes
                    if (!empty($settings['link']['url'])) {
                        $widget->add_render_attribute('link', 'href', $settings['link']['url']);

                        if (!empty($settings['link']['is_external'])) {
                            $widget->add_render_attribute('link', 'target', '_blank');
                        }
                        if (!empty($settings['link']['nofollow'])) {
                            $widget->add_render_attribute('link', 'rel', 'nofollow');
                        }
                    }
                    ?>

                    <?php $has_title_content = false;
                    if ($settings['style'] === 'style-2') {
                        $has_title_content = true;
                    } else {
                        if (!empty($settings['title1'])) {
                            $has_title_content = true;
                        }
                    }

                    if ($has_title_content):
                        ?>
                        <div class="pxl-item-title">
                            <?php
                            if ($settings['style'] === 'style-2') {
                                for ($i = 0; $i < 5; $i++) {
                                    echo '<span></span>';
                                }
                            } else {
                                echo pxl_print_html($settings['title1']);
                            }
                            ?>
                        </div>
                    <?php endif; ?>


                    <?php if (!empty($settings['title'])): ?>
                        <a class="pxl-item--link" <?php pxl_print_html($widget->get_render_attribute_string('link')); ?>>
                            <?php echo pxl_print_html($settings['title']); ?>
                        </a>
                    <?php endif; ?>

                <?php } // end block ?>
            </div>
        </div>

        <div class="pxl-item--images el-empty">

            <?php if (!empty($settings['images'])): ?>
                <?php foreach ($settings['images'] as $key => $value):
                    $img = pxl_get_image_by_size(array(
                        'attach_id' => $value['id'],
                        'thumb_size' => 'full',
                    ));
                    $thumbnail = $img['thumbnail'];
                    ?>
                    <div class="pxl-item--img">
                        <?php echo wp_kses_post($thumbnail); ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <?php if (!empty($settings['text'])): ?>
                <div class="pxl-item--text">
                    <?php echo pxl_print_html($settings['text']); ?>
                </div>
            <?php endif; ?>

        </div>

    </div>
</div>