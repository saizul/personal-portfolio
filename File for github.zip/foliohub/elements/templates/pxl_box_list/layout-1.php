<?php
$image_size = !empty($settings['img_size']) ? $settings['img_size'] : '200x200';
if (isset($settings['testimonial']) && !empty($settings['testimonial']) && count($settings['testimonial'])): ?>
    <div class="pxl-box-list pxl-box-list1">
        <?php foreach ($settings['testimonial'] as $key => $value):
            $text1 = isset($value['text1']) ? $value['text1'] : '';
            $text2 = isset($value['text2']) ? $value['text2'] : '';
            $title = isset($value['title']) ? $value['title'] : '';
            $image1 = isset($value['image1']) ? $value['image1'] : '';
            $image2 = isset($value['image2']) ? $value['image2'] : '';
            $desc = isset($value['desc']) ? $value['desc'] : '';
            $link_key = $widget->get_repeater_setting_key('link', 'value', $key);
            if (!empty($value['link']['url'])) {
                $widget->add_render_attribute($link_key, 'href', $value['link']['url']);

                if ($value['link']['is_external']) {
                    $widget->add_render_attribute($link_key, 'target', '_blank');
                }

                if ($value['link']['nofollow']) {
                    $widget->add_render_attribute($link_key, 'rel', 'nofollow');
                }
            }
            $link_attributes = $widget->get_render_attribute_string($link_key);
            $i = 1;
            $delay = ($settings['pxl_animate_delay']) + (($i - 1) * 100);
            ?>
            <div class="pxl-item">
                <div class="pxl-item--inner <?php echo esc_attr($settings['pxl_animate']); ?>"data-wow-delay="<?php echo esc_attr($delay); ?>ms">
                    <a <?php echo implode(' ', [$link_attributes]); ?>></a>
                    <div class="pxl-item--text1 el-empty"><?php echo pxl_print_html($text1); ?></div>
                    <div class="pxl-item--holder pxl-flex-middle">
                        <?php if (!empty($image1['id'])) {
                            $img = pxl_get_image_by_size(array(
                                'attach_id' => $image1['id'],
                                'thumb_size' => $image_size,
                                'class' => 'no-lazyload',
                            ));
                            $thumbnail = $img['thumbnail'];
                            ?>
                            <div class="pxl-item--image">
                                <?php echo wp_kses_post($thumbnail); ?>
                            </div>
                        <?php } ?>
                        <h5 class="pxl-item--title">
                            <?php echo pxl_print_html($title); ?>
                        </h5>
                        <?php if (!empty($image2['id'])) {
                            $img1 = pxl_get_image_by_size(array(
                                'attach_id' => $image2['id'],
                                'thumb_size' => $image_size,
                                'class' => 'no-lazyload',
                            ));
                            $thumbnail1 = $img1['thumbnail'];
                            ?>
                            <div class="pxl-item--image">
                                <?php echo wp_kses_post($thumbnail1); ?>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="pxl-item--text2 el-empty"><?php echo pxl_print_html($text2); ?></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>