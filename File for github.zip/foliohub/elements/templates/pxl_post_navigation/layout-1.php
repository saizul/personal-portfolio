<?php
if($settings['type'] === 'navigation') :
    global $post;
    $previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
    $next     = get_adjacent_post( false, '', false );
    if ( ! $next && ! $previous ) {
        return;
    }
    $next_post = get_next_post();
    $previous_post = get_previous_post();
    if( !empty($next_post) || !empty($previous_post) ) { ?>
        <div class="pxl-post-navigation">
            <div class="pxl--item item--prev pxl-navigation-btn--wrap pxl-navigation--prev">
                <?php if ( is_a( $previous_post , 'WP_Post' ) && get_the_title( $previous_post->ID ) != '') { ?>
                    <a class="pxl-icon-link pxl-arrow--prev" href="<?php echo esc_url(get_permalink( $previous_post->ID )); ?>">
                        <?php echo esc_html( !empty($settings['post_name']) ? 'Previous ' . $settings['post_name'] : 'Previous Project' ); ?>
                        <h3 class="project-title">
                            <?php echo esc_html( get_the_title( $previous_post->ID ) ); ?>
                        </h3>
                    </a>
                <?php } ?>
            </div>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="black" xmlns="http://www.w3.org/2000/svg">
                <rect width="4" height="4" rx="2"/>
                <rect y="10" width="4" height="4" rx="2"/>
                <rect x="10" width="4" height="4" rx="2"/>
                <rect x="10" y="10" width="4" height="4" rx="2"/>
            </svg>        
            <?php if ( is_a( $next_post , 'WP_Post' ) && get_the_title( $next_post->ID ) != '') { ?>
                <div class="pxl--item item--next pxl-navigation-btn--wrap pxl-navigation--next ">
                    <a class="pxl-icon-link pxl-arrow--next" href="<?php echo esc_url(get_permalink( $next_post->ID )); ?>">
                        <?php echo esc_html( !empty($settings['post_name']) ? 'Next ' . $settings['post_name'] : 'Next Project' ); ?>
                        <h3 class="project-title">
                            <?php echo esc_html( get_the_title( $next_post->ID ) ); ?>
                        </h3>
                    </a>
                </div>
            <?php } ?>
        </div>
<?php } 
endif; ?>
