<?php 
$template = (int)$widget->get_setting('content_template','0');
if($template > 0 ){
	if ( !has_action( 'pxl_anchor_target_hidden_panel_'.$template) ){
		add_action( 'pxl_anchor_target_hidden_panel_'.$template, 'foliohub_hook_anchor_hidden_panel' );
	} 
}
?>
<div class="pxl-anchor-button pxl-cursor--cta <?php echo esc_attr($settings['style'].' '.$settings['pxl_animate']); ?> <?php if($template == '1') { echo 'pxl-anchor-mobile-menu'; } ?>" data-target=".pxl-hidden-template-<?php echo esc_attr($template); ?>" data-delay-hover="<?php echo esc_attr($settings['pxl_close_animate_delay']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
	<?php if($settings['icon_type'] == 'default') { ?>
		<div class="dot-loader">
			<span class="dot"></span>
			<span class="dot"></span>
			<span class="dot"></span>
		</div>
	<?php } elseif(!empty($settings['pxl_icon']['value'])) { ?>
		<?php \Elementor\Icons_Manager::render_icon( $settings['pxl_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
	<?php } ?>
	<?php if ( ! empty( $settings['text'] ) ) : ?> 
		<div class="pxl-text"><?php echo esc_html( $settings['text'] ); ?></div>
	<?php endif; ?>
</div>