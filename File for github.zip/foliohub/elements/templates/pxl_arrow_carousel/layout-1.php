<div class="pxl-navigation-carousel <?php echo esc_attr($settings['style']); ?>">
  <div class="pxl-navigation-arrow pxl-navigation-arrow-prev"><i aria-hidden="true" class="bootstrap-icons bi-arrow-left"></i></div>
  <div class="pxl-navigation-arrow pxl-navigation-arrow-next"><i aria-hidden="true" class="bootstrap-icons bi-arrow-right"></i></div>
</div>