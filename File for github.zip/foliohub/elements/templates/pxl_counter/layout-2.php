<?php
$widget->add_render_attribute('counter', [
    'class' => 'pxl-counter--value ' . $settings['effect'] . '',
    'data-duration' => $settings['duration'],
    'data-startnumber' => $settings['starting_number'],
    'data-endnumber' => $settings['ending_number'],
    'data-to-value' => $settings['ending_number'],
    'data-delimiter' => $settings['thousand_separator_char'],
]); ?>
<div class="pxl-counter pxl-counter2 <?php echo esc_attr($settings['pxl_animate'] . $settings['style']); ?>"
    data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <div class="pxl-counter--inner">
        <div class="pxl-content">
            <div class="pxl-item--content">
                <?php if (!empty($settings['title'])): ?>
                    <h4 class="pxl-counter--title <?php echo esc_attr($settings['title_w']); ?>">
                        <?php echo pxl_print_html($settings['title']); ?>
                    </h4>
                <?php endif; ?>
                <?php if (!empty($settings['desc'])): ?>
                    <h3 class="pxl-counter--desc">
                        <?php echo pxl_print_html($settings['desc']); ?>
                    </h3>
                <?php endif; ?>
            </div>
        </div>
        <div class="pxl-counter-data">
            <div class="pxl-data-background">
                <h5 class="pxl-counter--number ">
                    <span class="pxl-counter--prefix el-empty"><?php echo pxl_print_html($settings['prefix']); ?></span>
                    <span <?php pxl_print_html($widget->get_render_attribute_string('counter')); ?>><?php echo esc_html($settings['starting_number']); ?></span>
                    <?php if (!empty($settings['suffix'])): ?>
                        <span class="pxl-counter--suffix"><?php echo pxl_print_html($settings['suffix']); ?></span>
                    <?php endif; ?>
                </h5>
            </div>
        </div>
    </div>
</div>