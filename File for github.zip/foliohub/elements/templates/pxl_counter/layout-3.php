<?php
$widget->add_render_attribute('counter', [
    'class' => 'pxl-counter--value ' . $settings['effect'] . '',
    'data-duration' => $settings['duration'],
    'data-startnumber' => $settings['starting_number'],
    'data-endnumber' => $settings['ending_number'],
    'data-to-value' => $settings['ending_number'],
    'data-delimiter' => $settings['thousand_separator_char'],
]);
$html_id = pxl_get_element_id($settings); 
$ids = esc_attr('grad-' . $html_id);
?>
<div class="pxl-counter pxl-counter3 <?php echo esc_attr($settings['pxl_animate'] . $settings['style']); ?>"
    data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <div class="pxl-counter--inner">
        <div class="pxl-data-background"></div>
        <div class="pxl-counter--holder">
            <div class="pxl-progressbar-circle">
                <svg class="svg2" xmlns="http://www.w3.org/2000/svg" viewBox="-1 -1 34 34">
                    <defs>
                        <linearGradient id="<?php echo esc_attr($ids); ?>" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop class="stop1" offset="0%" />
                            <stop class="stop2" offset="100%" />
                        </linearGradient>
                    </defs>
                    <circle cx="16" cy="16" r="15.9155" class="progress-bar__background js-progress-bar1" />

                    <circle cx="16" cy="16" r="15.9155" class="progress-bar__progress js-progress-bar" stroke="url(#<?php echo esc_attr($ids); ?>)" />
                </svg>
            </div>
            <div class="pxl-counter--number ">
                <span class="pxl-counter--prefix el-empty"><?php echo pxl_print_html($settings['prefix']); ?></span>
                <span <?php pxl_print_html($widget->get_render_attribute_string('counter')); ?>><?php echo esc_html($settings['starting_number']); ?></span>
                <?php if (!empty($settings['suffix'])): ?>
                    <span class="pxl-counter--suffix"><?php echo pxl_print_html($settings['suffix']); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="pxl-content-bottom">
            <div class="pxl-item--content">
                <?php if (!empty($settings['title'])): ?>
                    <div class="pxl-counter--title <?php echo esc_attr($settings['title_w']); ?>">
                        <?php echo pxl_print_html($settings['title']); ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($settings['desc'])): ?>
                    <div class="pxl-counter--desc">
                        <?php echo pxl_print_html($settings['desc']); ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php if ($settings['icon_type'] == 'icon' && !empty($settings['pxl_icon']['value'])): ?>
                <div class="pxl-counter--icon">
                    <?php \Elementor\Icons_Manager::render_icon($settings['pxl_icon'], ['aria-hidden' => 'true', 'class' => ''], 'i'); ?>
                </div>
            <?php endif; ?>
            <?php if ($settings['icon_type'] == 'image' && !empty($settings['icon_image']['id'])): ?>
                <div class="pxl-counter--icon">
                    <?php $img_icon = pxl_get_image_by_size(array(
                        'attach_id' => $settings['icon_image']['id'],
                        'thumb_size' => 'full',
                    ));
                    $thumbnail_icon = $img_icon['thumbnail'];
                    echo pxl_print_html($thumbnail_icon); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>