<?php 

$styleMappings = array(
    'style1' => 'displacements-01.jpg',
    'style2' => 'displacements-02.jpg',
    'style3' => 'displacements-03.jpg',
    'style4' => 'displacements-04.jpg',
    'style5' => 'displacements-05.jpg',
    'style6' => 'displacements-06.jpg',
    'style6' => 'displacements-06.jpg',
    'style7' => 'displacements-07.jpg',
    'style8' => 'displacements-08.jpg',
    'style9' => 'displacements-09.jpg',
    'style10' => 'displacements-10.jpg',
    'style11' => 'displacements-11.jpg',
    'style12' => 'displacements-12.jpg',
    'style' => 'webgl-01.jpg',
);
$imgds = isset($styleMappings[$settings['effect_style']]) ? $styleMappings[$settings['effect_style']] : '';
$drap = $widget->get_setting('drap', false);  
?>
<div class="pxl-image-effect  <?php echo esc_attr($settings['pxl_animate']); ?>" <?php if($drap !== false) : ?>data-cursor-drap="<?php echo esc_html('DRAG', 'foliohub'); ?>"<?php endif; ?> data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <div class="pxl-svg-image-inside">
        <?php ?>
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/' . sanitize_file_name( $imgds ) ); ?>" class="pxl-image-webgl">    
        <?php ?>
        <?php
            $image_size = !empty($settings['img_size']) ? $settings['img_size'] : 'full';

            $img_id_1 = !empty($settings['image_inside1']['id']) ? $settings['image_inside1']['id'] : '';
            $thumbnail_1 = '';
            if ($img_id_1) {
                $img_1 = pxl_get_image_by_size(array(
                    'attach_id'  => $img_id_1,
                    'thumb_size' => $image_size,
                    'class'      => 'no-lazyload'
                ));
                $thumbnail_1 = $img_1['thumbnail'];
            }

            $img_id_2 = !empty($settings['image_inside2']['id']) ? $settings['image_inside2']['id'] : '';
            $thumbnail_2 = '';
            if ($img_id_2) {
                $img_2 = pxl_get_image_by_size(array(
                    'attach_id'  => $img_id_2,
                    'thumb_size' => $image_size,
                    'class'      => 'no-lazyload'
                ));
                $thumbnail_2 = $img_2['thumbnail'];
            }
        ?>
        <div class="hover-images">
            <div class="img-1">
                <?php echo wp_kses_post($thumbnail_1); ?>
            </div>
            <div class="img-2">
                <?php echo wp_kses_post($thumbnail_2); ?>
            </div>
        </div>
    </div>
</div>