<?php
$image_size = !empty($settings['img_size']) ? $settings['img_size'] : 'full';
if (isset($settings['testimonial']) && !empty($settings['testimonial']) && count($settings['testimonial'])): ?>
    <div class="pxl-testimonial-list pxl-testimonial-list1">
        <?php foreach ($settings['testimonial'] as $key => $value):
            $title = isset($value['title']) ? $value['title'] : '';
            $position = isset($value['position']) ? $value['position'] : '';
            $image = isset($value['avatar']) ? $value['avatar'] : '';
            $desc = isset($value['desc']) ? $value['desc'] : '';
            ?>
            <div class="pxl-item">
                <div class="pxl-item--inner <?php echo esc_attr($settings['pxl_animate']); ?>"
                    data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
                    <h5 class="pxl-item--desc">
                        <?php echo pxl_print_html($desc); ?>
                    </h5>
                    <div class="pxl-item--holder pxl-flex-middle">
                        <?php if (!empty($image['id'])) {
                            $img = pxl_get_image_by_size(array(
                                'attach_id' => $image['id'],
                                'thumb_size' => $image_size,
                                'class' => 'no-lazyload',
                            ));
                            $thumbnail = $img['thumbnail'];
                            ?>
                            <div class="pxl-item--image">
                                <?php echo wp_kses_post($thumbnail); ?>
                            </div>
                        <?php } ?>
                        <div class="pxl-item--meta">
                            <h6 class="pxl-item--title el-empty"><?php echo pxl_print_html($title); ?></h6>
                            <div class="pxl-item--position el-empty"><?php echo pxl_print_html($position); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>