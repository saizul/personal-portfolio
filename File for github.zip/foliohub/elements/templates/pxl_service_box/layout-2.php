<?php
if (!empty($settings['link_l2']['url'])) {
    $widget->add_render_attribute('button', 'href', $settings['link_l2']['url']);

    if ($settings['link_l2']['is_external']) {
        $widget->add_render_attribute('button', 'target', '_blank');
    }

    if ($settings['link_l2']['nofollow']) {
        $widget->add_render_attribute('button', 'rel', 'nofollow');
    }
}
$is_new = \Elementor\Icons_Manager::is_migration_allowed(); ?>
<div class="pxl-service-box pxl-service-box2 <?php echo esc_attr($settings['pxl_animate']); ?> <?php echo esc_attr($settings['ative_item']); ?>"
    data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <a <?php pxl_print_html($widget->get_render_attribute_string('button')); ?>></a>
    <div class="pxl-item--content pxl-item--content1">
        <div class="pxl-item--image">
            <?php $img = pxl_get_image_by_size(array(
                'attach_id' => $settings['image']['id'],
                'thumb_size' => '360x210',
            ));
            $thumbnail = $img['thumbnail'];
            echo pxl_print_html($thumbnail); ?>
        </div>
        <?php if (!empty($settings['title_l2'])): ?>
            <h4 class="pxl-item--title"><?php echo pxl_print_html($settings['title_l2']); ?></h4>
        <?php endif; ?>
    </div>

    <div class="pxl-item--content pxl-item--content2">
        <?php if (!empty($settings['desc_l2'])): ?>
            <div class="pxl-item--desc"><?php echo pxl_print_html($settings['desc_l2']); ?></div>
        <?php endif; ?>
        <div class="pxl-item--icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50" fill="black">
                <path
                    d="M39.6 12.5C39.35 12.5 39.15 12.5 38.95 12.55C36.9 14.9 35.15 17.45 33.8 20.3C33.1 21.75 30.85 20.7 31.55 19.25C32.65 17 33.95 14.9 35.4 12.95C20.95 15.6 13.1 30.15 11.05 44C10.8 45.6 8.35003 45.15 8.60003 43.6C10.7 29.35 18.85 14.55 33.1 10.9C30.1 10.35 27.2 9.44997 24.4 8.19997C23.7 7.89997 23.45 6.84997 24 6.24997C25 5.19997 25.8 4.89997 27.25 4.99997C28.35 5.04997 28.5 6.19997 27.95 6.89997C31.45 8.14997 35.1 8.84998 38.85 8.94997C38.95 8.84998 39.05 8.74997 39.15 8.69997C40.3 7.59998 42.2 9.19997 41.05 10.3L41 10.35C41 10.65 40.9 10.95 40.7 11.15C40.75 11.85 40.4 12.5 39.6 12.5Z" />
            </svg>
        </div>
    </div>
</div>