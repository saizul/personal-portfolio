<?php
if (!empty($settings['link']['url'])) {
    $widget->add_render_attribute('button', 'href', $settings['link']['url']);

    if ($settings['link']['is_external']) {
        $widget->add_render_attribute('button', 'target', '_blank');
    }

    if ($settings['link']['nofollow']) {
        $widget->add_render_attribute('button', 'rel', 'nofollow');
    }
}
$is_new = \Elementor\Icons_Manager::is_migration_allowed(); ?>
<?php if (isset($settings['item_content']) && !empty($settings['item_content']) && count($settings['item_content'])): ?>
    <div class="pxl-service-box pxl-service-box1 <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms" >
        <?php if (isset($settings['item_content']) && !empty($settings['item_content']) && count($settings['item_content'])): ?>
            <div class="pxl-text-marquee pxl-text-marquee1">
                <?php foreach ($settings['item_content'] as $key => $value):
                    $stroke_item = isset($value['stroke_item']) ? $value['stroke_item'] : '';
                    $editor_title = isset($value['text']) ? $value['text'] : '';
                    if (!empty($editor_title)) {
                        $editor_title = $widget->parse_text_editor($editor_title);
                    }
                    ?>
                    <div class="pxl-text--marquee">
                        <div class="pxl-item--inner" >
                            <h3 class="<?php echo esc_attr($stroke_item); ?> pxl-item--text pxl-empty elementor-repeater-item-<?php echo esc_attr($value['_id']); ?>">
                                <?php echo wp_kses_post($editor_title); ?>
                            </h3>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <a <?php pxl_print_html($widget->get_render_attribute_string('button')); ?>></a>
        <div class="pxl-item--content">
            <?php if (!empty($settings['title'])): ?>
                <h5 class="pxl-item--title"><?php echo pxl_print_html($settings['title']); ?></h5>
            <?php endif; ?>
            <?php if (!empty($settings['number'])): ?>
                <h1 class="pxl-item--number"><?php echo pxl_print_html($settings['number']); ?></h1>
            <?php endif; ?>
            <?php if (!empty($settings['desc'])): ?>
                <div class="pxl-item--desc"><?php echo pxl_print_html($settings['desc']); ?></div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>


