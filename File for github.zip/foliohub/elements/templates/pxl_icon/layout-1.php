<?php
$is_new = \Elementor\Icons_Manager::is_migration_allowed();

if ( ! empty( $settings['icons'] ) ) : ?>
    <div class="pxl-icon-list pxl-icon1 <?php echo esc_attr($settings['style'].' '.$settings['animate_hover'].' '.$settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
        <?php foreach ( $settings['icons'] as $key => $value ) :
            $label = $value['label'] ?? '';
            $label_position = $value['label_position'] ?? '';
            $icon = $value['pxl_icon'] ?? '';
            $link = $value['icon_link']['url'] ?? '';

            // Link attributes
            $link_key = $widget->get_repeater_setting_key('icon_link', 'value', $key);
            if ( ! empty( $link ) ) {
                $widget->add_render_attribute( $link_key, 'href', $link );
                if ( ! empty( $value['icon_link']['is_external'] ) ) $widget->add_render_attribute( $link_key, 'target', '_blank' );
                if ( ! empty( $value['icon_link']['nofollow'] ) ) $widget->add_render_attribute( $link_key, 'rel', 'nofollow' );
            }
            $link_attributes = $widget->get_render_attribute_string( $link_key );
        ?>

            <?php if ( ! empty( $icon ) ) : ?>
                <a class="elementor-repeater-item-<?php echo esc_attr($value['_id']); ?> <?php echo esc_attr($label_position); ?>"
                   <?php echo wp_kses_post($link_attributes); ?>>

                    <?php if ( in_array($settings['style'], ['style-4', 'style-7']) ) : ?>
                        <span class="icon-box">
                    <?php endif; ?>

                    <?php
                    if ( $is_new ) {
                        \Elementor\Icons_Manager::render_icon( $icon, [ 'aria-hidden' => 'true' ] );
                    } else {
                        echo '<i class="' . esc_attr($icon) . '" aria-hidden="true"></i>';
                    }
                    ?>

                    <?php if ( in_array($settings['style'], ['style-4', 'style-7']) ) : ?>
                        </span>
                    <?php endif; ?>

                    <?php if ( ! empty( $label ) ) : ?>
                        <span class="<?php echo esc_attr($settings['style_t']); ?>">
                            <?php echo pxl_print_html($label); ?>
                        </span>
                    <?php endif; ?>
                </a>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
