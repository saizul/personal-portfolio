<?php
$html_id = pxl_get_element_id($settings);
if (isset($settings['tabs']) && !empty($settings['tabs']) && count($settings['tabs'])):
    $tab_bd_ids = [];
    ?>

    <?php if (isset($settings['tabs']) && !empty($settings['tabs']) && count($settings['tabs'])): ?>
        <div class="pxl-text-marquee pxl-text-marquee2 <?php echo esc_attr($settings['style']); ?>">
           <?php foreach ($settings['tabs'] as $key => $content): ?>
                <?php if (!empty($content['content_template'])): ?>
                    <div id="<?php echo esc_attr($html_id . '-' . $content['_id']); ?>" class="pxl-item--content">
                            <?php
                            $tab_content = Elementor\Plugin::$instance->frontend->get_builder_content_for_display((int) $content['content_template']);
                            pxl_print_html($tab_content);
                            ?>
                        </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>