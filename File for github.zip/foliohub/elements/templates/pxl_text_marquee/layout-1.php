<?php
$is_new = \Elementor\Icons_Manager::is_migration_allowed(); 
?>

<?php if (!empty($settings['item_content'])): ?>
    <div class="pxl-text-marquee pxl-text-marquee1 <?php echo esc_attr($settings['style']); ?>">

        <?php foreach ($settings['item_content'] as $key => $value):
            $stroke_item   = $value['stroke_item'] ?? '';
            $editor_title  = $value['text'] ?? '';
            if (!empty($editor_title)) {
                $editor_title = $widget->parse_text_editor($editor_title);
            }
            $icon_type = $value['icon_type'] ?? 'icon';
            $icon      = $value['pxl_icon'] ?? '';
            $image     = $value['icon_image'] ?? [];
            $text1     = $value['text1'] ?? '';
        ?>  

        <div class="pxl-text--marquee">
            <div class="pxl-item--inner <?php echo esc_attr($settings['pxl_animate']); ?>" 
                 data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
                <?php if ($icon_type === 'icon' && !empty($icon)) : ?>

                    <div class="pxl-item--icon">
                        <?php if ($is_new):
                            \Elementor\Icons_Manager::render_icon($icon, [ 'aria-hidden' => 'true' ]);
                        else: ?>
                            <i class="<?php echo esc_attr($icon); ?>" aria-hidden="true"></i>
                        <?php endif; ?>
                    </div>

                <?php elseif ($icon_type === 'image' && !empty($image['id'])) : ?>

                    <?php 
                    $img_image = pxl_get_image_by_size([
                        'attach_id'  => $image['id'],
                        'thumb_size' => 'full',
                        'class'      => 'no-lazyload',
                    ]);
                    $thumbnail_image = $img_image['thumbnail'];
                    ?>

                    <div class="pxl-item--icon">
                        <?php echo wp_kses_post($thumbnail_image); ?>
                    </div>

                <?php endif; ?>
                <div class="pxl-item--title pxl-flex">
                    <div class="<?php echo esc_attr($stroke_item); ?> pxl-item--text pxl-empty elementor-repeater-item-<?php echo esc_attr($value['_id']); ?>">
                        <?php echo wp_kses_post($editor_title); ?>
                    </div>
                    <?php if ( isset($settings['style']) && $settings['style'] === 'style-client' ) : ?>
                        <div class="pxl-text2">
                            <?php echo wp_kses_post($text1); ?>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>

        <?php endforeach; ?>

    </div>
<?php endif; ?>
