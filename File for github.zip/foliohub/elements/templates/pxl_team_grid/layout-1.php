<?php
$col_xs = $widget->get_setting('col_xs', '');
$col_sm = $widget->get_setting('col_sm', '');
$col_md = $widget->get_setting('col_md', '');
$col_lg = $widget->get_setting('col_lg', '');
$col_xl = $widget->get_setting('col_xl', '');

$col_xl = 12 / intval($col_xl);
$col_lg = 12 / intval($col_lg);
$col_md = 12 / intval($col_md);
$col_sm = 12 / intval($col_sm);
$col_xs = 12 / intval($col_xs);

$grid_sizer = "col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col_xs}";
$item_class = "pxl-grid-item col-xl-{$col_xl} col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-{$col_xs}";
$image_size = !empty($settings['img_size']) ? $settings['img_size'] : 'full';

?>
<?php if(isset($settings['team']) && !empty($settings['team']) && count($settings['team'])): ?>
<div class="pxl-grid pxl-team-grid pxl-team-grid1 pxl-team-layout1 " data-layout="<?php echo esc_attr($settings['layout_mode']); ?>">
    <?php if (!empty($settings['classify'])): ?>
        <div class="pxl-title-classify">
            <?php echo pxl_print_html($settings['classify']); ?>
        </div>
    <?php endif; ?>
    <div class="pxl-grid-inner pxl-grid-masonry row" data-gutter="15">
        <?php foreach ($settings['team'] as $key => $value):
            $title = isset($value['title']) ? $value['title'] : '';
            $position = isset($value['position']) ? $value['position'] : '';
            $popup_template = isset($value['popup_template']) ? $value['popup_template'] : '';
            $image = isset($value['image']) ? $value['image'] : '';
            $social_left = isset($value['social_left']) ? $value['social_left'] : '';
            $social_top = isset($value['social_top']) ? $value['social_top'] : '';
            $link_key = $widget->get_repeater_setting_key( 'link', 'value', $key );
            if ( ! empty( $value['link']['url'] ) ) {
                $widget->add_render_attribute( $link_key, 'href', $value['link']['url'] );

                if ( $value['link']['is_external'] ) {
                    $widget->add_render_attribute( $link_key, 'target', '_blank' );
                }

                if ( $value['link']['nofollow'] ) {
                    $widget->add_render_attribute( $link_key, 'rel', 'nofollow' );
                }
            }
            $link_attributes = $widget->get_render_attribute_string( $link_key );
            ?>
            <div class="<?php echo esc_attr($item_class); ?>">
                <div class="pxl-item--inner <?php echo esc_attr($settings['pxl_animate']); ?>">
                    <?php if(!empty($image['id'])) { 
                        $img = pxl_get_image_by_size( array(
                            'attach_id'  => $image['id'],
                            'thumb_size' => $image_size,
                            'class' => 'no-lazyload',
                        ));
                        $thumbnail = $img['thumbnail'];
                        ?>
                        <div class="pxl-item--image">
                            <a <?php echo implode( ' ', [ $link_attributes ] ); ?>>
                                <?php echo wp_kses_post($thumbnail); ?>
                            </a>
                            <?php if(!empty($social_left)): ?>
                                <div class="pxl-social pxl-social-left">
                                    <?php  $team_social_left = json_decode($social_left, true); ?>
                                    <?php foreach ($team_social_left as $value): ?>
                                        <a class="pxl-flex-center" href="<?php echo esc_url($value['url']); ?>" target="_blank"><i class="<?php echo esc_attr($value['icon']); ?>"></i></a>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                            <div class="pxl-minus"></div>
                            <?php if(!empty($social_top)): ?>
                                <div class="pxl-social pxl-social-top">
                                    <?php  $team_social_top = json_decode($social_top, true); ?>
                                    <?php foreach ($team_social_top as $value): ?>
                                        <a class="pxl-flex-center" href="<?php echo esc_url($value['url']); ?>" target="_blank"><i class="<?php echo esc_attr($value['icon']); ?>"></i></a>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                <?php } ?>
                <div class="pxl-item--holder ">
                  <a <?php echo implode( ' ', [ $link_attributes ] ); ?>></a>
                  <div class="pxl-item--meta pxl-flex-grow ">
                    <h4 class="pxl-item--title">    
                        <a <?php echo implode( ' ', [ $link_attributes ] ); ?>><?php echo pxl_print_html($title); ?></a>
                    </h4>
                    <div class="pxl-item--position"><?php echo pxl_print_html($position); ?></div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>
<div class="grid-sizer <?php echo esc_attr($grid_sizer); ?>"></div>
</div>
</div>
<?php endif; ?>
