<div class="pxl-close-popup  pxl-cursor--cta <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <?php if($settings['icon_type'] == 'default') { ?>
		x
	<?php } elseif(!empty($settings['pxl_icon']['value'])) { ?>
		<?php \Elementor\Icons_Manager::render_icon( $settings['pxl_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
	<?php } ?>
	<?php if ( ! empty( $settings['text'] ) ) : ?> 
		<div class="pxl-text"><?php echo esc_html( $settings['text'] ); ?></div>
	<?php endif; ?>
</div>