<div class="pxl-marquee pxl-marquee__style-3 <?php echo esc_attr($settings['style']); ?> pxl-marquee__<?php echo esc_attr($settings['direction'].' pxl-marquee__'.esc_attr($settings['pause_on_hover'])); ?>" data-show="<?php echo esc_attr($settings['item_to_show']); ?>">
    <ul style="animation-duration: <?php echo esc_attr($settings['time_run']) ?>s;">
        <?php foreach ($settings['item1'] as $key => $value):
            $image = isset($value['image_avatar']) ? $value['image_avatar'] : '';
            $link_key = $widget->get_repeater_setting_key( 'link', 'value', $key );
            if ( ! empty( $value['link']['url'] ) ) {
                $widget->add_render_attribute( $link_key, 'href', $value['link']['url'] );

                if ( $value['link']['is_external'] ) {
                    $widget->add_render_attribute( $link_key, 'target', '_blank' );
                }

                if ( $value['link']['nofollow'] ) {
                    $widget->add_render_attribute( $link_key, 'rel', 'nofollow' );
                }
            }
            $link_attributes = $widget->get_render_attribute_string( $link_key );
            $desc = $widget->parse_text_editor($value['desc']);
            $title = $widget->parse_text_editor($value['title']);
            $position = $widget->parse_text_editor($value['position']);
            $icon_key = $widget->get_repeater_setting_key( 'pxl_icon', 'icons', $key );
            $widget->add_render_attribute( $icon_key, [
                'class' => $value['pxl_icon'],
                'aria-hidden' => 'true',
            ] );
            ?>
            <li class="pxl-marquee__item pxl-anm-border">
                <h6 class="pxl-item--desc">
                    <?php echo esc_html($desc); ?>   
                </h6>
                <div class="pxl-item--client pxl-anm-border">
                    <div class="pxl-client">
                        <?php if(!empty($image['id'])) { 
                            $img_image = pxl_get_image_by_size( array(
                                'attach_id'  => $image['id'],
                                'thumb_size' => 'full',
                                'class' => 'no-lazyload',
                            ));
                            $thumbnail_image = $img_image['thumbnail'];?>
                            <div class="pxl-avatar">
                                <?php echo wp_kses_post($thumbnail_image); ?>
                            </div>
                        <?php } ?>
                        <div class="pxl-content">
                            <h5 class="pxl-name">
                                <?php echo pxl_print_html($title); ?>
                            </h5>
                            <div class="pxl-position">
                                <?php echo pxl_print_html($position); ?>
                            </div>
                        </div>
                    </div>
                    <div class="pxl-item--icon">
                        <?php if(!empty($value['pxl_icon'])){
                            \Elementor\Icons_Manager::render_icon( $value['pxl_icon'], [ 'aria-hidden' => 'true' ], 'i' );
                        } ?>
                    </div>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>
</div>
