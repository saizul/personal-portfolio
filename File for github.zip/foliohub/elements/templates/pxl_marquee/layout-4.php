<div class="pxl-marquee pxl-marquee__style-4 <?php echo esc_attr($settings['style']); ?> pxl-marquee__<?php echo esc_attr($settings['direction'] . ' pxl-marquee__' . esc_attr($settings['pause_on_hover']) . ' pxl-marquee__play-' . esc_attr($settings['play_on_hover'])); ?>">
    <ul style="animation-duration: <?php echo esc_attr($settings['time_run']) ?>s;">
        <?php for ($loop_count = 0; $loop_count < 2; $loop_count++) : $i = 1; foreach ($settings['item2'] as $key => $value):
                $image = isset($value['image_avatar2']) ? $value['image_avatar2'] : '';
                $desc = $widget->parse_text_editor($value['desc2']);
                $title = $widget->parse_text_editor($value['title2']);
                ?>
                <li class="pxl-marquee__item">
                    <div class="pxl-item--client">
                        <div class="pxl-item--top">
                            <div class="pxl-item--count">
                                <?php echo str_pad($i, 2, '0', STR_PAD_LEFT); ?>
                            </div>
                            <?php if (!empty($image['id'])) {
                                $img_image = pxl_get_image_by_size(array(
                                    'attach_id' => $image['id'],
                                    'thumb_size' => '150x180',
                                    'class' => 'no-lazyload',
                                ));
                                $thumbnail_image = $img_image['thumbnail']; ?>
                                <div class="pxl-avatar">
                                    <?php echo wp_kses_post($thumbnail_image); ?>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="pxl-content">
                            <h6 class="pxl-name">
                                <?php echo pxl_print_html($title); ?>
                            </h6>
                            <div class="pxl-item--desc">
                                <?php echo esc_html($desc); ?>
                            </div>
                        </div>
                    </div>
                </li>
            <?php $i++; endforeach; 
        endfor;?>
    </ul>
</div>